// @ts-check
/**
 * linksDb.js
 * ──────────
 * SQLite-backed store for Discord ↔ Uma.moe trainer ID links.
 *
 * Replaces links.json as the source of truth.
 * On first init, existing links.json data is automatically imported
 * so no manual migration is needed. The JSON file is kept as a backup.
 *
 * All operations are synchronous (better-sqlite3).
 */
import Database from 'better-sqlite3';
import path from 'node:path';
import { readFileSync } from 'node:fs';
import { config } from '../core/config.js';
import { log } from '../core/log.js';
import { runMigrations } from './migrations.js';

/** @type {import('better-sqlite3').Database | null} */
let db = null;

export function initLinksDb() {
  const dbPath = path.join(config.dataDir, 'links.db');
  db = new Database(dbPath);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  db.exec(`
    CREATE TABLE IF NOT EXISTS links (
      discord_id  TEXT PRIMARY KEY,
      viewer_id   TEXT NOT NULL,
      linked_at   TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_links_viewer ON links(viewer_id);
  `);

  runMigrations(db, []);

  // One-time import from links.json (only when table is empty)
  const count = db.prepare('SELECT COUNT(*) AS c FROM links').get()?.c ?? 0;
  if (count === 0) {
    const jsonPath = path.join(config.dataDir, 'links.json');
    try {
      const raw = readFileSync(jsonPath, 'utf8');
      const data = JSON.parse(raw);
      const insert = db.prepare(
        'INSERT OR IGNORE INTO links (discord_id, viewer_id) VALUES (?, ?)'
      );
      const importAll = db.transaction(entries => {
        let n = 0;
        for (const [discordId, trainerId] of entries) {
          insert.run(String(discordId), String(trainerId));
          n++;
        }
        return n;
      });
      const imported = importAll(Object.entries(data));
      if (imported > 0) log.info(`linksDb: imported ${imported} link(s) from links.json`);
    } catch (err) {
      if (err.code !== 'ENOENT') log.warn('linksDb: failed to import links.json:', err.message);
    }
  }

  log.info('linksDb: initialized');
  return db;
}

/** @returns {boolean} */
export function isLinksDbInitialized() {
  return db !== null;
}

function getDb() {
  if (!db) throw new Error('linksDb: not initialized — call initLinksDb() first');
  return db;
}

/**
 * Insert or update a Discord ↔ viewer link.
 * @param {string} discordId
 * @param {string} trainerId
 */
export function setLink(discordId, trainerId) {
  getDb()
    .prepare(
      `INSERT INTO links (discord_id, viewer_id) VALUES (?, ?)
       ON CONFLICT(discord_id) DO UPDATE SET viewer_id = excluded.viewer_id,
                                             linked_at = datetime('now')`
    )
    .run(String(discordId), String(trainerId));
}

/**
 * Remove a link by Discord ID.
 * @param {string} discordId
 */
export function removeLink(discordId) {
  getDb().prepare('DELETE FROM links WHERE discord_id = ?').run(String(discordId));
}

/**
 * Look up the uma.moe viewer ID for a Discord user.
 * @param {string} discordId
 * @returns {string | null}
 */
export function getLinkedViewerId(discordId) {
  const row = getDb()
    .prepare('SELECT viewer_id FROM links WHERE discord_id = ?')
    .get(String(discordId));
  return row?.viewer_id ?? null;
}

/**
 * Returns all links as a plain object { discordId: trainerId }.
 * @returns {Record<string, string>}
 */
export function getAllLinks() {
  const rows = getDb().prepare('SELECT discord_id, viewer_id FROM links').all();
  return Object.fromEntries(rows.map(r => [r.discord_id, r.viewer_id]));
}
