// @ts-check
/**
 * storeDb.js
 * ──────────
 * SQLite-backed storage for all data previously held in JSON flat-files.
 *
 * Tables:
 *   members         — circle member records  (was members.json / members_CIRCLEID.json)
 *   daily_gains     — daily fan gain history (was dailyGains.json / dailyGains_CIRCLEID.json)
 *   guild_config    — per-guild settings     (was guildConfig.json)
 *   bot_state       — generic key/value flags(was state.json)
 *   timezones       — per-user tz prefs      (was timezones.json)
 *   command_messages— bot reply tracking     (was commandMessages.json)
 *
 * On first init, any existing JSON files are automatically imported so no
 * data is lost. The JSON files are kept as backups but are no longer written.
 */
import Database from 'better-sqlite3';
import path from 'node:path';
import { mkdirSync, readFileSync, readdirSync } from 'node:fs';
import { config } from '../core/config.js';
import { log } from '../core/log.js';
import { runMigrations } from './migrations.js';

/** @type {import('better-sqlite3').Database | null} */
let db = null;

function getDb() {
  if (!db) throw new Error('storeDb: not initialized — call initStoreDb() first');
  return db;
}

export function initStoreDb() {
  mkdirSync(config.dataDir, { recursive: true });
  const dbPath = path.join(config.dataDir, 'store.db');
  db = new Database(dbPath);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  db.exec(`
    CREATE TABLE IF NOT EXISTS members (
      circle_id     TEXT NOT NULL,
      viewer_id     TEXT NOT NULL,
      trainer_name  TEXT,
      joined_at     TEXT,
      first_seen_at TEXT,
      last_seen     TEXT,
      left_at       TEXT,
      PRIMARY KEY (circle_id, viewer_id)
    );

    CREATE TABLE IF NOT EXISTS daily_gains (
      circle_id   TEXT NOT NULL,
      viewer_id   TEXT NOT NULL,
      date        TEXT NOT NULL,
      gain        REAL NOT NULL DEFAULT 0,
      total_fans  REAL NOT NULL DEFAULT 0,
      created_at  TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at  TEXT,
      PRIMARY KEY (circle_id, viewer_id, date)
    );
    CREATE INDEX IF NOT EXISTS idx_daily_gains_lookup ON daily_gains(circle_id, date);

    CREATE TABLE IF NOT EXISTS guild_config (
      guild_id    TEXT PRIMARY KEY,
      config_json TEXT NOT NULL DEFAULT '{}'
    );

    CREATE TABLE IF NOT EXISTS bot_state (
      key        TEXT PRIMARY KEY,
      value_json TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS timezones (
      discord_id TEXT PRIMARY KEY,
      timezone   TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS command_messages (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      channel_id TEXT    NOT NULL,
      message_id TEXT    NOT NULL,
      created_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_cmd_msgs_created ON command_messages(created_at);
  `);

  runMigrations(db, []);
  _importFromJson();
  log.info('storeDb: initialized');
  return db;
}

// ── One-time JSON import ──────────────────────────────────────────────────────

function _readJson(filePath, fallback) {
  try {
    return JSON.parse(readFileSync(filePath, 'utf8'));
  } catch {
    return fallback;
  }
}

function _importFromJson() {
  const d = config.dataDir;

  // Members: members.json (main circle) + members_CIRCLEID.json (secondary circles)
  if (db.prepare('SELECT COUNT(*) AS c FROM members').get().c === 0) {
    const insertMember = db.prepare(`
      INSERT OR IGNORE INTO members
        (circle_id, viewer_id, trainer_name, joined_at, first_seen_at, last_seen, left_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    const importBatch = db.transaction((circleId, map) => {
      for (const [trainerId, m] of Object.entries(map)) {
        insertMember.run(
          String(circleId), String(trainerId),
          m.trainerName ?? null, m.joinedAt ?? null,
          m.firstSeenAt ?? null, m.lastSeen ?? null,
          m.leftAt ?? null
        );
      }
    });

    let total = 0;
    // members.json was the legacy flat-file for the primary circle (CIRCLE_ID env var).
    // config.circleId is intentional here — this is a one-time legacy JSON migration that
    // runs before the circle registry is used, and members.json always belonged to circle 1.
    const mainData = _readJson(path.join(d, 'members.json'), {});
    const mainEntries = Object.keys(mainData).length;
    if (mainEntries) { importBatch(config.circleId, mainData); total += mainEntries; }

    try {
      for (const f of readdirSync(d)) {
        const match = f.match(/^members_(.+)\.json$/);
        if (match) {
          const data = _readJson(path.join(d, f), {});
          const n = Object.keys(data).length;
          if (n) { importBatch(match[1], data); total += n; }
        }
      }
    } catch { /* dataDir may be empty on first run */ }

    if (total > 0) log.info(`storeDb: imported ${total} member record(s) from JSON`);
  }

  // Daily gains: dailyGains.json + dailyGains_CIRCLEID.json
  if (db.prepare('SELECT COUNT(*) AS c FROM daily_gains').get().c === 0) {
    const insertGain = db.prepare(`
      INSERT OR IGNORE INTO daily_gains
        (circle_id, viewer_id, date, gain, total_fans, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    const importBatch = db.transaction((circleId, table) => {
      for (const rec of Object.values(table)) {
        insertGain.run(
          String(circleId), String(rec.trainerId), rec.date,
          rec.gain ?? 0, rec.totalFans ?? 0,
          rec.createdAt ?? new Date().toISOString(),
          rec.updatedAt ?? null
        );
      }
    });

    let total = 0;
    // dailyGains.json was the legacy flat-file for the primary circle (CIRCLE_ID env var).
    // config.circleId is intentional here — same reasoning as the members.json import above.
    const mainGains = _readJson(path.join(d, 'dailyGains.json'), {});
    const mainCount = Object.keys(mainGains).length;
    if (mainCount) { importBatch(config.circleId, mainGains); total += mainCount; }

    try {
      for (const f of readdirSync(d)) {
        const match = f.match(/^dailyGains_(.+)\.json$/);
        if (match) {
          const data = _readJson(path.join(d, f), {});
          const n = Object.keys(data).length;
          if (n) { importBatch(match[1], data); total += n; }
        }
      }
    } catch { /* ok */ }

    if (total > 0) log.info(`storeDb: imported ${total} daily gain record(s) from JSON`);
  }

  // Guild config
  if (db.prepare('SELECT COUNT(*) AS c FROM guild_config').get().c === 0) {
    const data = _readJson(path.join(d, 'guildConfig.json'), {});
    const insert = db.prepare(
      'INSERT OR IGNORE INTO guild_config (guild_id, config_json) VALUES (?, ?)'
    );
    const importAll = db.transaction(obj => {
      let n = 0;
      for (const [guildId, cfg] of Object.entries(obj)) {
        insert.run(String(guildId), JSON.stringify(cfg));
        n++;
      }
      return n;
    });
    const n = importAll(data);
    if (n > 0) log.info(`storeDb: imported ${n} guild config(s) from JSON`);
  }

  // Bot state
  if (db.prepare('SELECT COUNT(*) AS c FROM bot_state').get().c === 0) {
    const data = _readJson(path.join(d, 'state.json'), {});
    const insert = db.prepare(
      'INSERT OR IGNORE INTO bot_state (key, value_json) VALUES (?, ?)'
    );
    const importAll = db.transaction(obj => {
      let n = 0;
      for (const [key, val] of Object.entries(obj)) {
        insert.run(String(key), JSON.stringify(val));
        n++;
      }
      return n;
    });
    const n = importAll(data);
    if (n > 0) log.info(`storeDb: imported ${n} state entry/entries from JSON`);
  }

  // Timezones
  if (db.prepare('SELECT COUNT(*) AS c FROM timezones').get().c === 0) {
    const data = _readJson(path.join(d, 'timezones.json'), {});
    const insert = db.prepare(
      'INSERT OR IGNORE INTO timezones (discord_id, timezone) VALUES (?, ?)'
    );
    const importAll = db.transaction(obj => {
      let n = 0;
      for (const [discordId, tz] of Object.entries(obj)) {
        insert.run(String(discordId), String(tz));
        n++;
      }
      return n;
    });
    const n = importAll(data);
    if (n > 0) log.info(`storeDb: imported ${n} timezone(s) from JSON`);
  }

  // Command messages
  if (db.prepare('SELECT COUNT(*) AS c FROM command_messages').get().c === 0) {
    const data = _readJson(path.join(d, 'commandMessages.json'), []);
    if (Array.isArray(data) && data.length > 0) {
      const insert = db.prepare(
        'INSERT OR IGNORE INTO command_messages (channel_id, message_id, created_at) VALUES (?, ?, ?)'
      );
      const importAll = db.transaction(arr => {
        for (const e of arr) {
          insert.run(String(e.channelId), String(e.messageId), Number(e.createdAt));
        }
      });
      importAll(data);
      log.info(`storeDb: imported ${data.length} command message(s) from JSON`);
    }
  }
}

// ── Members ───────────────────────────────────────────────────────────────────

/** @param {object} r @returns {object} */
function _rowToMember(r) {
  return {
    trainerName: r.trainer_name,
    joinedAt: r.joined_at,
    firstSeenAt: r.first_seen_at,
    lastSeen: r.last_seen,
    leftAt: r.left_at,
  };
}

/**
 * @param {string} circleId
 * @returns {Record<string, object>}
 */
export function getMembers(circleId) {
  const rows = getDb()
    .prepare('SELECT * FROM members WHERE circle_id = ?')
    .all(String(circleId));
  return Object.fromEntries(rows.map(r => [r.viewer_id, _rowToMember(r)]));
}

/**
 * @param {string} circleId
 * @param {string} trainerId
 * @param {object} patch
 * @returns {object}
 */
export function upsertMember(circleId, trainerId, patch) {
  const existing = getDb()
    .prepare('SELECT * FROM members WHERE circle_id = ? AND viewer_id = ?')
    .get(String(circleId), String(trainerId));
  const base = existing ? _rowToMember(existing) : {};
  const merged = { ...base, ...patch };

  getDb().prepare(`
    INSERT INTO members (circle_id, viewer_id, trainer_name, joined_at, first_seen_at, last_seen, left_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(circle_id, viewer_id) DO UPDATE SET
      trainer_name  = excluded.trainer_name,
      joined_at     = excluded.joined_at,
      first_seen_at = excluded.first_seen_at,
      last_seen     = excluded.last_seen,
      left_at       = excluded.left_at
  `).run(
    String(circleId), String(trainerId),
    merged.trainerName ?? null,
    merged.joinedAt ?? null,
    merged.firstSeenAt ?? null,
    merged.lastSeen ?? null,
    merged.leftAt ?? null
  );
  return merged;
}

/**
 * Replace the full member map for a circle atomically.
 * @param {string} circleId
 * @param {Record<string, object>} map
 */
export function setMembers(circleId, map) {
  const d = getDb();
  const upsert = d.prepare(`
    INSERT INTO members (circle_id, viewer_id, trainer_name, joined_at, first_seen_at, last_seen, left_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(circle_id, viewer_id) DO UPDATE SET
      trainer_name  = excluded.trainer_name,
      joined_at     = COALESCE(members.joined_at, excluded.joined_at),
      first_seen_at = COALESCE(members.first_seen_at, excluded.first_seen_at),
      last_seen     = excluded.last_seen,
      left_at       = excluded.left_at
  `);
  const prune = d.prepare(
    `DELETE FROM members WHERE circle_id = ? AND viewer_id NOT IN (SELECT value FROM json_each(?))`
  );
  d.transaction((cid, m) => {
    const trainerIds = JSON.stringify(Object.keys(m));
    for (const [trainerId, data] of Object.entries(m)) {
      upsert.run(
        cid, String(trainerId),
        data.trainerName ?? null,
        data.joinedAt ?? null,
        data.firstSeenAt ?? null,
        data.lastSeen ?? null,
        data.leftAt ?? null
      );
    }
    prune.run(cid, trainerIds);
  })(String(circleId), map);
}

// ── Daily gains ───────────────────────────────────────────────────────────────

/** @param {object} r @returns {object} */
function _rowToGain(r) {
  return {
    trainerId: r.viewer_id,
    date: r.date,
    gain: r.gain,
    totalFans: r.total_fans,
    createdAt: r.created_at,
  };
}

/**
 * @param {string} circleId
 * @param {string} trainerId
 * @param {string} dateStr  YYYY-MM-DD
 * @param {number} gain
 * @param {number} totalFans
 */
export function storeDailyGain(circleId, trainerId, dateStr, gain, totalFans) {
  const now = new Date().toISOString();
  getDb().prepare(`
    INSERT INTO daily_gains (circle_id, viewer_id, date, gain, total_fans, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, NULL)
    ON CONFLICT(circle_id, viewer_id, date) DO UPDATE SET
      gain       = excluded.gain,
      total_fans = excluded.total_fans,
      updated_at = ?
  `).run(String(circleId), String(trainerId), dateStr, gain, totalFans, now, now);
}

/**
 * @param {string} circleId
 * @param {string} dateStr
 * @returns {object[]}
 */
export function getDailyGainsForDate(circleId, dateStr) {
  return getDb()
    .prepare('SELECT * FROM daily_gains WHERE circle_id = ? AND date = ?')
    .all(String(circleId), dateStr)
    .map(_rowToGain);
}

/**
 * @param {string} circleId
 * @param {string} trainerId
 * @param {string | null} fromDate
 * @param {string | null} toDate
 * @returns {object[]}
 */
export function getMemberDailyGains(circleId, trainerId, fromDate = null, toDate = null) {
  let sql = 'SELECT * FROM daily_gains WHERE circle_id = ? AND viewer_id = ?';
  const params = [String(circleId), String(trainerId)];
  if (fromDate) { sql += ' AND date >= ?'; params.push(fromDate); }
  if (toDate)   { sql += ' AND date <= ?'; params.push(toDate); }
  sql += ' ORDER BY date ASC';
  return getDb().prepare(sql).all(...params).map(_rowToGain);
}

/**
 * @param {string} circleId
 * @param {number} retentionDays
 */
export function pruneDailyGains(circleId, retentionDays = 90) {
  const cutoff = new Date(Date.now() - retentionDays * 24 * 60 * 60 * 1000)
    .toISOString()
    .slice(0, 10);
  const result = getDb()
    .prepare('DELETE FROM daily_gains WHERE circle_id = ? AND date < ?')
    .run(String(circleId), cutoff);
  if (result.changes > 0) {
    log.debug(`storeDb.pruneDailyGains(${circleId}): removed ${result.changes} old record(s)`);
  }
}

// ── Guild config ──────────────────────────────────────────────────────────────

/**
 * @param {string} guildId
 * @returns {object}
 */
export function getGuildConfig(guildId) {
  const row = getDb()
    .prepare('SELECT config_json FROM guild_config WHERE guild_id = ?')
    .get(String(guildId));
  return row ? JSON.parse(row.config_json) : {};
}

/**
 * @param {string} guildId
 * @param {object} patch
 * @returns {object}
 */
export function setGuildConfig(guildId, patch) {
  const existing = getGuildConfig(guildId);
  const merged = { ...existing, ...patch };
  getDb().prepare(`
    INSERT INTO guild_config (guild_id, config_json) VALUES (?, ?)
    ON CONFLICT(guild_id) DO UPDATE SET config_json = excluded.config_json
  `).run(String(guildId), JSON.stringify(merged));
  return merged;
}

/** @returns {Record<string, object>} */
export function getAllGuildConfigs() {
  const rows = getDb().prepare('SELECT guild_id, config_json FROM guild_config').all();
  return Object.fromEntries(rows.map(r => [r.guild_id, JSON.parse(r.config_json)]));
}

/**
 * Run multiple DB writes atomically inside a SQLite transaction.
 * If `fn` throws, the entire transaction is rolled back automatically.
 *
 * Usage:
 *   runInTransaction(() => {
 *     upsertMember(circleId, trainerId, data);
 *     writeDailyGain(circleId, trainerId, date, gain, total);
 *   });
 *
 * @param {() => void} fn - Synchronous function containing DB writes.
 * @returns {void}
 */
export function runInTransaction(fn) {
  getDb().transaction(fn)();
}

// ── Bot state ─────────────────────────────────────────────────────────────────

/**
 * @template T
 * @param {string} key
 * @param {T} [defaultValue]
 * @returns {T}
 */
export function getBotState(key, defaultValue = null) {
  const row = getDb()
    .prepare('SELECT value_json FROM bot_state WHERE key = ?')
    .get(String(key));
  return row ? JSON.parse(row.value_json) : defaultValue;
}

/**
 * @param {string} key
 * @param {*} value
 */
export function setBotState(key, value) {
  getDb().prepare(`
    INSERT INTO bot_state (key, value_json) VALUES (?, ?)
    ON CONFLICT(key) DO UPDATE SET value_json = excluded.value_json
  `).run(String(key), JSON.stringify(value));
}

// ── Timezones ─────────────────────────────────────────────────────────────────

/**
 * @param {string} discordId
 * @returns {string | null}
 */
export function getTimezone(discordId) {
  const row = getDb()
    .prepare('SELECT timezone FROM timezones WHERE discord_id = ?')
    .get(String(discordId));
  return row?.timezone ?? null;
}

/**
 * @param {string} discordId
 * @param {string} tz
 */
export function setTimezone(discordId, tz) {
  getDb().prepare(`
    INSERT INTO timezones (discord_id, timezone) VALUES (?, ?)
    ON CONFLICT(discord_id) DO UPDATE SET timezone = excluded.timezone
  `).run(String(discordId), String(tz));
}

// ── Command messages ──────────────────────────────────────────────────────────

/**
 * @param {string} channelId
 * @param {string} messageId
 */
export function recordCommandMessage(channelId, messageId) {
  const now = Date.now();
  const cutoff = now - 14 * 24 * 60 * 60 * 1000;
  const d = getDb();
  d.prepare('DELETE FROM command_messages WHERE created_at < ?').run(cutoff);
  d.prepare(
    'INSERT INTO command_messages (channel_id, message_id, created_at) VALUES (?, ?, ?)'
  ).run(String(channelId), String(messageId), now);
}

/**
 * Atomically fetch and remove all command messages older than ageMs.
 * @param {number} ageMs
 * @returns {{ channelId: string, messageId: string, createdAt: number }[]}
 */
export function takeCommandMessagesOlderThan(ageMs) {
  const cutoff = Date.now() - ageMs;
  const d = getDb();
  const select = d.prepare(
    'SELECT id, channel_id, message_id, created_at FROM command_messages WHERE created_at < ?'
  );
  const del = d.prepare('DELETE FROM command_messages WHERE id = ?');

  let rows = [];
  d.transaction(() => {
    rows = select.all(cutoff);
    for (const r of rows) del.run(r.id);
  })();

  return rows.map(r => ({
    channelId: r.channel_id,
    messageId: r.message_id,
    createdAt: r.created_at,
  }));
}
