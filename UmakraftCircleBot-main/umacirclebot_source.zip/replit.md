# Uma Circle Bot — Repository Core

> **This file is the heart, mind, and core of this repository.**
> Every agent session reads this first. Every decision made must align with what is written here.
> If this file becomes stale, the repository becomes unreliable. Keep it updated.

---

## ⚠️ Agent Permission Protocol

**The agent MUST NOT make any changes, edits, deletions, or additions to this project without explicit user permission.**

Permission is granted ONLY when the user says one of:
- `yes`
- `granted`
- `permission granted`

Until one of those phrases is given, the agent may only **read, analyze, explain, and plan**.
When something looks broken, outdated, or improvable — post a **NOTICE** and wait.

**NOTICE format:**
```
🔔 NOTICE: [What was found] — [What would be done] — Awaiting permission.
```

---

## 🚫 Agent Hard Rules (Read Before Touching Anything)

These are non-negotiable. No exceptions.

### 1. NEVER request `DISCORD_TOKEN` as a secret
The bot loads its own token automatically via `core/tokenLoader.js`:
`secrets/token_enc.key` (in repo) → GitHub Gist → Google Drive → Fernet decrypt → `process.env.DISCORD_TOKEN`

**Do NOT call `requestEnvVar` for `DISCORD_TOKEN`. Do NOT ask the user to paste it. Do NOT suggest storing it as a plain secret.**
If the bot needs to start, just run `node start.js` — the chain runs automatically.
If `DISCORD_TOKEN` or `DISCORD_BOT_TOKEN` is already set in the environment, the chain skips itself safely.

### 2. SQLite only — no external databases
All persistence uses `better-sqlite3`. Never suggest Postgres, Firebase, or any other DB.

### 3. No code changes without permission
See Agent Permission Protocol above.

---

## Project Identity

**Bot name:** UmadolProject#4037
**Purpose:** Discord bot managing the UmaKraft Uma Musume circles on uma.moe (circle IDs: `974470619` and `325938032`).
**Platform:** Replit (primary), Railway (secondary)
**Repo:** Private GitHub — only owner has access

---

## Stack

| Layer | Technology |
|---|---|
| Runtime | Node.js 20+ (ES Modules) |
| Discord | discord.js v14 |
| Database | SQLite via better-sqlite3 |
| Scheduling | node-cron (Asia/Tokyo timezone) |
| HTTP scraping | axios + cheerio |
| Headless browser | playwright-core + chromium |
| Package manager | npm |

---

## Startup & Entry Points

### `start.js` — THE REAL ENTRY POINT
The Replit workflow runs `node start.js`, NOT `node index.js`.

**Why:** `core/config.js` throws at import time if `DISCORD_TOKEN` is missing. The token must be injected into `process.env` before any other module loads. `start.js` does this by calling `loadToken()` first, then dynamically importing `index.js`.

```
node start.js
  └─ core/tokenLoader.js → loadToken()
       └─ [see Token Loading Chain below]
  └─ index.js (dynamic import, after token is set)
       └─ All databases initialized
       └─ Discord client created
       └─ Event handlers registered
       └─ Health server started (port 8080)
       └─ Bot logs in → ready event fires
            └─ Slash commands registered
            └─ Scheduled tasks started
            └─ Startup tasks run
```

### `index.js` — Main Application
Initializes everything after the token is loaded. Never run directly — always via `start.js`.

---

## Token Loading Chain (Zero-Setup on Fresh Import)

**No manual secrets needed on any fresh GitHub import.**

```
secrets/token_enc.key  (committed to repo — Fernet key)
    ↓
Fetch service_account.enc from GitHub Gist (encrypted)
    ↓ Fernet decrypt
Google Service Account credentials
    ↓
Fetch token.enc from Google Drive (restricted file)
    ↓ Fernet decrypt
DISCORD_TOKEN → injected into process.env
    ↓
Bot starts
```

**Key resources:**
- Fernet key file: `secrets/token_enc.key`
- Gist URL: `https://gist.githubusercontent.com/Falco-chan/185c218af472a35832a7f8299f47527d/raw/5691d9e3b783bb4dfbea6bef36c3d2fc26ee6340/service_account.enc`
- Google Drive file ID: `13DHdZoXRJgTlz4PCaVo7g5SBsV-H_NzE`
- Service account: `umadolproject@replitbot-498005.iam.gserviceaccount.com`
- Implemented in: `core/tokenLoader.js`

**Security model:**
- Fernet key alone → useless (can't reach Drive without service account)
- Gist alone → useless (encrypted, can't decrypt without Fernet key)
- Drive file alone → useless (restricted to service account only)
- All three must be compromised simultaneously to expose the token

**DO NOT** ask the user to paste `DISCORD_TOKEN` as a secret. The chain handles it automatically.

---

## Project Layout

```
/
├── start.js                  ← Workflow entry point (node start.js)
├── index.js                  ← Main app (loaded by start.js)
├── secrets/
│   └── token_enc.key         ← Fernet decryption key (committed to repo)
├── core/
│   ├── config.js             ← Frozen config object from env vars. Throws if DISCORD_TOKEN missing.
│   ├── log.js                ← Leveled logger (debug/info/warn/error) with timestamps
│   ├── store.js              ← Public persistence API — facade over storeDb + linksDb
│   ├── uma.js                ← uma.moe API client. Member stats, gain classification, snapshot cache
│   ├── channels.js           ← High-level channel management (ensureGuildChannels, getLeaderboardChannel)
│   ├── channel-utils.js      ← Low-level find/create channel helpers
│   ├── deploy-commands.js    ← Slash command registration (runs on boot + manually)
│   ├── errors.js             ← safeRun(), withRetry() async error utilities
│   ├── format.js             ← JST time formatting, fan count localization
│   ├── health.js             ← HTTP server on port 8080 for health checks (/health, /ready)
│   ├── milestoneImages.js    ← Scans /milestone_images/ for local image assets
│   ├── tally.js              ← Monthly/weekly boundary date logic
│   ├── taskRegistry.js       ← In-memory registry tracking cron task status/errors
│   ├── tokenLoader.js        ← Gist → Drive → Fernet decryption chain
│   └── busyLock.js           ← Global lock preventing message collisions in bulk ops
├── db/
│   ├── storeDb.js            ← Members, daily gains, guild configs, bot state
│   ├── linksDb.js            ← Discord User ID ↔ Uma.moe Viewer ID mapping
│   ├── trainerDb.js          ← Trainer profiles and skills (/search_trainer, /store)
│   ├── milestoneDb.js        ← Fired milestones with send-state flags (exactly-once delivery)
│   ├── onboardingDb.js       ← New member onboarding and trainer card submission tracking
│   ├── attendanceDb.js       ← Daily logins and consecutive streak tracking
│   ├── timelineCache.js      ← Deduplication + message tracking for the news feed
│   ├── imageArchiveDb.js     ← Cursors and SHA-256 hashes for the media archiver
│   └── migrations.js         ← Minimalist migration runner used by all DB modules
├── commands/                 ← 21 slash command implementations
│   ├── fan_gain.js           ← /fan_gain — personal gain card image (Daily/Weekly/Monthly + rank)
│   ├── leaderboard.js        ← /leaderboard — circle-wide top rankings image
│   ├── link.js               ← /link — connect Discord account to trainer ID
│   ├── unlink.js             ← /unlink — disconnect trainer ID
│   ├── store.js              ← /store — manually save trainer ID (only in #uma-store)
│   ├── search_trainer.js     ← /search_trainer — query trainer database with filters
│   ├── set_fans.js           ← /set_fans — user fan count configuration
│   ├── set_quota.js          ← /set_quota — quota configuration
│   ├── set_timezone.js       ← /set_timezone — user timezone setting
│   ├── circle_master.js      ← /circle_master — leader-only admin tools
│   ├── timeline_setup.js     ← /timeline_setup — configure timeline channel
│   ├── timeline_post.js      ← /timeline_post — manual timeline post trigger
│   └── help.js               ← /help — interactive command guide
├── handlers/
│   ├── ready.js              ← Post-login: channel verification, task initiation
│   ├── interactionCreate.js  ← Routes slash commands + autocomplete, detects locale/timezone
│   ├── messageCreate.js      ← Text interface: trainer ID pastes, media notifications, hype reactions (🏇)
│   ├── guildMemberAdd.js     ← Welcomes new members, initiates onboarding
│   └── presenceUpdate.js     ← Tracks online status, sends Morning Greetings
├── tasks/
│   ├── index.js              ← Orchestrates all cron jobs via node-cron
│   ├── dataSync.js           ← Every 30min: fetch uma.moe data, calculate gains, update storeDb
│   ├── milestones.js         ← Monitors gains, fires milestone announcements/DMs
│   ├── milestone-tiers.js    ← Milestone tier definitions (10M/20M/30M/40M/60M/80M/100M)
│   ├── leaderboardAnnouncements.js ← Posts Daily/Weekly/Monthly top-3 summaries
│   ├── attendanceCheck.js    ← Daily 6AM: report who logged into Discord
│   ├── onboardingReminder.js ← DMs members who haven't submitted a trainer card
│   ├── chatArchiver.js       ← Moves messages to history channel
│   ├── imageArchive.js       ← Preserves media from channels
│   ├── sqliteBackup.js       ← Daily rotation of database backups
│   └── updateGameData.js     ← Refreshes character data from Gametora
├── timeline/
│   ├── timeline.js           ← Uma.moe timeline scraper orchestrator + status tracking
│   ├── timelineScheduler.js  ← Cron-based scheduling for timeline updates
│   └── timelineScraper.js    ← Playwright-based scraper for uma.moe/timeline
├── trainer/
│   ├── screenshotter.js      ← Playwright headless browser — captures trainer profile screenshots
│   └── trainerLeaderboard.js ← Manages the #result-contribution leaderboard channel
├── utils/
│   ├── imageReport.js        ← [Pipeline 1] Image generation — structured data → PNG via Chromium
│   ├── imageReport-browser.js← [Pipeline 1] Headless Chromium lifecycle for imageReport.js
│   ├── imageClassifier.js    ← [Pipeline 2] Image analysis — GPT-4o Vision, extracts trainer ID
│   ├── cardCache.js          ← In-memory cache for game support card data (534 cards)
│   ├── characterData.js      ← Game ID → English character name mapping
│   ├── autoDelete.js         ← Queues bot replies for timed deletion
│   ├── embeds.js             ← Discord embed builders
│   └── dmHelpers.js          ← DM sending utilities
├── scrapers/
│   └── [race/racetrack data scrapers]
├── data/                     ← Runtime SQLite databases (gitignored)
├── attached_assets/          ← Milestone image assets: Falco pool + FalcoA pool (gitignored)
└── milestone_images/         ← Dedicated milestone images (e.g. Lovely_SmartFalcon for 60M)
```

---

## Image System Architecture

Two completely separate pipelines. Never merge them.

### Pipeline 1 — Image Generation (active)
| Property | Value |
|---|---|
| Files | `utils/imageReport.js`, `utils/imageReport-browser.js` |
| Input | Structured game data (leaderboard rows, fan gains, stats, profiles) |
| Output | PNG buffer sent as Discord attachment |
| Engine | Headless Chromium via Playwright — renders HTML/CSS templates |
| Nature | **Deterministic** — same data always produces the same image |
| OpenAI | ❌ NOT used. NOT required. Do not introduce it here. |

### Pipeline 2 — Image Analysis (active)
| Property | Value |
|---|---|
| File | `utils/imageClassifier.js` |
| Input | Image URL (user-uploaded Uma Musume screenshot) |
| Output | Structured JSON: `screen_type`, `trainer_id`, `trainer_name`, `rank`, `confidence` |
| Engine | GPT-4o Vision (OpenAI) |
| Nature | **Probabilistic** — AI inference, not deterministic rendering |
| Chromium | ❌ NOT used here. Chromium is for rendering only (Pipeline 1). |

**Hard rules:**
- Do NOT route `imageReport.js` output through OpenAI Vision
- Do NOT use Chromium as a fallback inside `imageClassifier.js`
- Do NOT mix rendering logic with analysis logic under any circumstances

---

## Milestone Tiers

| Tier | Type | Gate | Content |
|---|---|---|---|
| 10M / 20M / 30M / 40M | Standard | All qualifying members | 7 random message variants each |
| 60M | Special | Top 3 per circle per month | 1 message + dedicated image from `/milestone_images/` |
| 80M | Special | Top 3 per circle per month | 1 message + image from FalcoA pool |
| 100M | Special | Top 3 per circle per month | 1 message + image from FalcoA pool |

Both circles have independent 3-slot pools for special tiers (up to 6 recipients total per tier per month).
If more than 3 qualify, winners are chosen by random draw.

---

## Environment Variables

Set in `.replit` `[userenv.shared]` — no manual entry needed:

| Variable | Value | Purpose |
|---|---|---|
| `CIRCLE_ID` | `974470619` | Primary circle (UmaKraft) |
| `CIRCLE_2_ID` | `325938032` | Secondary circle (UmaKraft 2) |
| `CIRCLE_2_NAME` | `UmaKraft 2` | Secondary circle display name |
| `DATA_DIR` | `./data` | SQLite database directory |
| `TIMEZONE` | `Asia/Tokyo` | All cron scheduling |
| `LOG_LEVEL` | `info` | Log verbosity |
| `DISCORD_CLIENT_ID` | `1499028508007989288` | Application ID |
| `GUILD_ID` | `1489093959044173935` | Target guild for command registration |

**DISCORD_TOKEN is never manually set.** It is loaded automatically via `core/tokenLoader.js`.

---

## Key Commands

| Command | What it does |
|---|---|
| `node start.js` | Start the bot (correct entry point) |
| `node index.js` | ❌ Do not run directly — token won't be loaded |
| `npm start` | Runs `node index.js` — ❌ outdated, use workflow instead |
| `npm run dev` | `node --watch index.js` — ❌ use `node --watch start.js` for dev |
| `npm run deploy-commands` | Manually register slash commands |

---

## Persistence Rules

- **All persistence MUST use SQLite via better-sqlite3**
- Never use JSON files for state
- Never use in-memory state that doesn't survive restarts
- Never use any external database (Postgres, Firebase, etc.)
- Database files live in `DATA_DIR` (`./data/` locally, `/data/` on Railway)

---

## Circle Expansion Roadmap (3–10 Circles)

> Full plan documented in `replitprojectnotes.md` → *Circle Expansion Roadmap* section.

- **Current state:** 2 circles fully operational (UmaKraft + UmaKraft 2)
- **Target:** Up to 10 circles using a SQLite-backed circle registry
- **Status:** 🗓️ Planning only — no code changes started
- **Approach:** 5 sequential phases (Registry → Commands → Tasks → Storage → Observability)
- **Key rule:** Each phase requires explicit user permission before any code is written
- **Do not** add `CIRCLE_3_ID` env vars — the new architecture uses a DB registry, not more env vars

---

## Deployment

### Replit (primary)
- Workflow: `Discord Bot` → `node start.js`
- Output type: console (not webview)
- Health check: port 8080
- Token: loaded automatically via Gist → Drive chain
- No secrets need to be set manually on fresh import

### Railway (secondary)
- Uses `Dockerfile` + `railway.json`
- Set `DISCORD_TOKEN` or `DISCORD_BOT_TOKEN` as an environment variable
- Attach a Volume at `/data` with `DATA_DIR=/data` for database persistence
- Health check: GET `/health` on port 8080

---

## User Preferences

- **Secure token method is intentional** — never suggest simplifying it or moving the token to a plain secret
- **SQLite only** — never suggest switching to Postgres or any other database
- **No manual secret entry on fresh imports** — the token chain must always be fully automatic
- **Agent must not act without permission** — always plan first, wait for "yes" / "granted" / "permission granted"
- **replit.md is authoritative** — if code contradicts this file, flag it as a NOTICE before touching anything
