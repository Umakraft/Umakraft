import { SlashCommandBuilder } from 'discord.js';
import { getCircleSnapshot } from '../core/uma.js';
import { store } from '../core/store.js';
import { formatGain } from '../core/format.js';
import { daysRemainingInMonth } from '../core/tally.js';
import { config, getConfiguredCircles } from '../core/config.js';
import { resolveQuota } from '../core/quotaKeys.js';
import { deleteAfter } from '../utils/autoDelete.js';
import { renderFanGain, bufferToAttachment } from '../utils/imageReport.js';

function resolveCircle(circleId) {
  const circles = getConfiguredCircles();
  if (!circleId) return circles[0];
  return circles.find(c => c.id === circleId) ?? circles[0];
}

async function getMonthlyReq(guildId, circleId) {
  if (!guildId) return config.monthlyRequirement;
  const cfg = await store.getGuildConfig(guildId).catch(() => ({}));
  return resolveQuota(cfg, circleId, 'monthly', config.monthlyRequirement);
}

export function buildData() {
  const circles = getConfiguredCircles();
  return new SlashCommandBuilder()
    .setName('fan_gain')
    .setDescription('Show your daily, weekly, and monthly fan gain plus your daily ranking')
    .addUserOption(opt =>
      opt
        .setName('member')
        .setDescription('Look up another circle member instead of yourself')
        .setRequired(false)
    )
    .addStringOption(opt =>
      opt.setName('trainer').setDescription('Look up by Uma.moe trainer name').setRequired(false)
    )
    .addStringOption(opt =>
      opt
        .setName('circle')
        .setDescription('Which circle to look up in (default: first circle)')
        .setRequired(false)
        .addChoices(...circles.map(c => ({ name: c.name, value: c.id })))
    );
}

export const data = buildData();

export async function execute(interaction) {
  await interaction.deferReply();

  const targetUser = interaction.options.getUser('member') ?? interaction.user;
  const trainerOption = interaction.options.getString('trainer');
  const circleVal = interaction.options.getString('circle');
  const circle = resolveCircle(circleVal);

  const snapshot = await getCircleSnapshot(circle.id);
  let member = null;
  let lookupLabel;

  if (trainerOption) {
    const needle = trainerOption.toLowerCase();
    member =
      snapshot.members.find(m => m.trainerName.toLowerCase() === needle) ||
      snapshot.members.find(m => m.trainerName.toLowerCase().includes(needle));
    lookupLabel = `trainer "${trainerOption}"`;
  } else {
    const trainerId = await store.getLinkedViewerId(targetUser.id);
    if (trainerId) member = snapshot.members.find(m => m.trainerId === trainerId);
    if (!member) {
      const guildMember = await interaction.guild?.members.fetch(targetUser.id).catch(() => null);
      const candidates = [guildMember?.nickname, targetUser.globalName, targetUser.username]
        .filter(Boolean)
        .map(s => s.toLowerCase());
      member = snapshot.members.find(m => candidates.includes(m.trainerName.toLowerCase()));
    }
    lookupLabel = `<@${targetUser.id}>`;
  }

  if (!member) {
    const errReply = await interaction.editReply(
      `Could not find ${lookupLabel} in the active ${circle.name} circle members. ` +
        `Use \`/link\` to connect your Discord account to your Uma.moe trainer name.`
    );
    deleteAfter(errReply);
    return;
  }

  const { tallyStarted } = snapshot;
  const today = new Date();
  const dateLabel = today.toISOString().slice(0, 10);
  const daysLeft = daysRemainingInMonth(today);

  const todayDow = today.getUTCDay();
  const daysSinceMon = (todayDow + 6) % 7;
  const monDate = new Date(today);
  monDate.setUTCDate(today.getUTCDate() - daysSinceMon);
  const weekLabel = `${monDate.toISOString().slice(0, 10)} – ${dateLabel}`;

  let rankStr;
  if (!tallyStarted) {
    rankStr = 'Not Started';
  } else if (!member.hasData || member.joinDay) {
    rankStr = 'Pending';
  } else {
    const ranked = [...snapshot.members]
      .filter(m => m.hasData && !m.joinDay)
      .sort((a, b) => b.todayGain - a.todayGain);
    const rank = ranked.findIndex(m => m.trainerId === member.trainerId) + 1;
    const total = ranked.length;
    rankStr = `Daily Rank: #${rank} of ${total} active`;
  }

  const monthlyReq = await getMonthlyReq(interaction.guildId, circle.id);

  const buf = await renderFanGain({
    trainerName: member.trainerName,
    circleName: snapshot.circle.name,
    daily: formatGain(member.todayGain, member, tallyStarted, 'daily'),
    weekly: formatGain(member.weeklyGain, member, tallyStarted, 'weekly'),
    monthly: formatGain(member.monthlyGain, member, tallyStarted, 'monthly'),
    dailyRaw: member.hasData ? member.todayGain : 0,
    weeklyRaw: member.hasData ? member.weeklyGain : 0,
    monthlyRaw: member.hasData ? member.monthlyGain : 0,
    rank: rankStr,
    weekLabel,
    date: dateLabel,
    daysLeft,
    monthlyReq,
  });

  const reply = await interaction.editReply({
    files: [bufferToAttachment(buf, 'fan-gain.png')],
  });
  deleteAfter(reply);
}
