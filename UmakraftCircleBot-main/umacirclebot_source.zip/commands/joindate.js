import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';
import { getCircleSnapshot } from '../core/uma.js';
import { getConfiguredCircles } from '../core/config.js';
import { store } from '../core/store.js';
import { formatDateLong } from '../core/format.js';

export const data = new SlashCommandBuilder()
  .setName('joindate')
  .setDescription('Show when a member joined the Uma.moe circle')
  .addUserOption(opt =>
    opt
      .setName('member')
      .setDescription('Look up another circle member instead of yourself')
      .setRequired(false)
  )
  .addStringOption(opt =>
    opt.setName('trainer').setDescription('Look up by Uma.moe trainer name').setRequired(false)
  );

export async function execute(interaction) {
  await interaction.deferReply({ ephemeral: true });

  const targetUser = interaction.options.getUser('member') ?? interaction.user;
  const trainerOption = interaction.options.getString('trainer');

  const circles = getConfiguredCircles();

  let member = null;
  let foundCircleId = null;
  let foundCircleName = null;
  let lookupLabel;

  for (const circle of circles) {
    let snapshot;
    try {
      snapshot = await getCircleSnapshot(circle.id);
    } catch {
      continue;
    }

    if (trainerOption) {
      const needle = trainerOption.toLowerCase();
      member =
        snapshot.allMembers.find(m => m.trainerName.toLowerCase() === needle) ||
        snapshot.allMembers.find(m => m.trainerName.toLowerCase().includes(needle));
      lookupLabel = `trainer "${trainerOption}"`;
    } else {
      const trainerId = await store.getLinkedViewerId(targetUser.id);
      if (trainerId) {
        member = snapshot.allMembers.find(m => m.trainerId === trainerId);
      }
      if (!member) {
        const guildMember = await interaction.guild?.members.fetch(targetUser.id).catch(() => null);
        const candidates = [guildMember?.nickname, targetUser.globalName, targetUser.username]
          .filter(Boolean)
          .map(s => s.toLowerCase());
        member = snapshot.allMembers.find(m => candidates.includes(m.trainerName.toLowerCase()));
      }
      lookupLabel = `<@${targetUser.id}>`;
    }

    if (member) {
      foundCircleId = circle.id;
      foundCircleName = circle.name;
      break;
    }
  }

  if (!member) {
    await interaction.editReply(
      `Could not find ${lookupLabel} in the circle data. ` +
        `Use \`/link\` to connect your Discord account to your Uma.moe trainer name.`
    );
    return;
  }

  const storedMembers = await store.getMembersForCircle(foundCircleId);
  const stored = storedMembers[member.trainerId];
  const joinedAt = stored?.joinedAt ?? member.joinedAt ?? null;

  let joinLine;
  if (joinedAt) {
    const joinedDate = new Date(joinedAt);
    joinLine = `**Circle join date:** ${formatDateLong(joinedDate)}`;
  } else {
    joinLine = '**Circle join date:** Unknown — data sync pending';
  }

  const leftLine = stored?.leftAt
    ? `**Left circle:** ${formatDateLong(new Date(stored.leftAt))}`
    : null;

  const statusLine = stored?.leftAt ? '**Status:** Left the circle' : '**Status:** Active member';

  const lines = [joinLine, statusLine, leftLine].filter(Boolean);

  const embed = new EmbedBuilder()
    .setTitle(member.trainerName)
    .setColor(stored?.leftAt ? 0x90a4ae : 0x81c784)
    .setDescription(lines.join('\n'))
    .setFooter({ text: `Circle: ${foundCircleName ?? foundCircleId}` });

  await interaction.editReply({ embeds: [embed] });
}
