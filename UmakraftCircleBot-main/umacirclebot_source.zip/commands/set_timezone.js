import { SlashCommandBuilder } from 'discord.js';
import { store } from '../core/store.js';

/**
 * Map Discord locale codes → best-guess IANA timezone.
 * Used for automatic detection on first interaction.
 */
export const LOCALE_TO_TZ = {
  ja: 'Asia/Tokyo',
  ko: 'Asia/Seoul',
  'zh-CN': 'Asia/Shanghai',
  'zh-TW': 'Asia/Taipei',
  vi: 'Asia/Ho_Chi_Minh',
  th: 'Asia/Bangkok',
  hi: 'Asia/Kolkata',
  id: 'Asia/Jakarta',
  tr: 'Europe/Istanbul',
  ru: 'Europe/Moscow',
  uk: 'Europe/Kiev',
  pl: 'Europe/Warsaw',
  cs: 'Europe/Prague',
  hu: 'Europe/Budapest',
  ro: 'Europe/Bucharest',
  bg: 'Europe/Sofia',
  el: 'Europe/Athens',
  lt: 'Europe/Vilnius',
  hr: 'Europe/Zagreb',
  fi: 'Europe/Helsinki',
  'sv-SE': 'Europe/Stockholm',
  no: 'Europe/Oslo',
  da: 'Europe/Copenhagen',
  nl: 'Europe/Amsterdam',
  de: 'Europe/Berlin',
  fr: 'Europe/Paris',
  it: 'Europe/Rome',
  'es-ES': 'Europe/Madrid',
  'en-GB': 'Europe/London',
  'pt-BR': 'America/Sao_Paulo',
  'en-US': 'America/New_York',
};

const COMMON_TIMEZONES = [
  'Asia/Tokyo',
  'Asia/Seoul',
  'Asia/Shanghai',
  'Asia/Taipei',
  'Asia/Singapore',
  'Asia/Manila',
  'Asia/Jakarta',
  'Asia/Bangkok',
  'Asia/Ho_Chi_Minh',
  'Asia/Kolkata',
  'Asia/Dubai',
  'Asia/Riyadh',
  'Asia/Karachi',
  'Europe/London',
  'Europe/Paris',
  'Europe/Berlin',
  'Europe/Madrid',
  'Europe/Rome',
  'Europe/Amsterdam',
  'Europe/Warsaw',
  'Europe/Moscow',
  'Europe/Istanbul',
  'Europe/Athens',
  'Europe/Helsinki',
  'Europe/Stockholm',
  'America/New_York',
  'America/Chicago',
  'America/Denver',
  'America/Los_Angeles',
  'America/Toronto',
  'America/Vancouver',
  'America/Sao_Paulo',
  'America/Mexico_City',
  'Australia/Sydney',
  'Australia/Melbourne',
  'Australia/Perth',
  'Pacific/Auckland',
  'Pacific/Honolulu',
  'UTC',
];

export const data = new SlashCommandBuilder()
  .setName('set_timezone')
  .setDescription(
    'Override your timezone for greeting messages (auto-detected from your Discord locale by default)'
  )
  .addStringOption(opt =>
    opt
      .setName('timezone')
      .setDescription('Your IANA timezone, e.g. Asia/Tokyo or America/New_York')
      .setRequired(true)
      .setAutocomplete(true)
  );

export async function autocomplete(interaction) {
  const focused = interaction.options.getFocused().toLowerCase();
  const results = COMMON_TIMEZONES.filter(tz => tz.toLowerCase().includes(focused))
    .slice(0, 25)
    .map(tz => {
      const localTime = new Date().toLocaleString('en-US', {
        timeZone: tz,
        hour: '2-digit',
        minute: '2-digit',
        hour12: false,
      });
      return { name: `${tz}  (now ${localTime})`, value: tz };
    });
  await interaction.respond(results);
}

export async function execute(interaction) {
  await interaction.deferReply({ ephemeral: true });

  const tz = interaction.options.getString('timezone', true).trim();

  try {
    new Intl.DateTimeFormat('en', { timeZone: tz }).format();
  } catch {
    await interaction.editReply(
      `❌ **"${tz}"** is not a valid timezone. Please choose one from the suggestions.`
    );
    return;
  }

  await store.setTimezone(interaction.user.id, tz);

  const localTime = new Date().toLocaleString('en-US', {
    timeZone: tz,
    weekday: 'short',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });

  await interaction.editReply(
    `✅ Timezone set to **${tz}**.\n` +
      `Your current local time: **${localTime}**\n\n` +
      `Greetings (noon, night, midnight) will now arrive at the right time for you.`
  );
}
