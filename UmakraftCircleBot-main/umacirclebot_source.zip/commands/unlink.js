import { SlashCommandBuilder } from 'discord.js';
import { store } from '../core/store.js';

export const data = new SlashCommandBuilder()
  .setName('unlink')
  .setDescription('Remove the link between your Discord account and your Uma.moe trainer name')
  .addUserOption(opt =>
    opt
      .setName('member')
      .setDescription('(Admin) Unlink this Discord member instead of yourself')
      .setRequired(false)
  );

export async function execute(interaction) {
  await interaction.deferReply({ ephemeral: true });
  const targetUser = interaction.options.getUser('member') ?? interaction.user;

  if (targetUser.id !== interaction.user.id) {
    const member = await interaction.guild?.members.fetch(interaction.user.id).catch(() => null);
    if (!member?.permissions.has('ManageGuild')) {
      await interaction.editReply('Only server admins can unlink other members.');
      return;
    }
  }

  await store.removeLink(targetUser.id);
  await interaction.editReply(`Removed link for <@${targetUser.id}>.`);
}
