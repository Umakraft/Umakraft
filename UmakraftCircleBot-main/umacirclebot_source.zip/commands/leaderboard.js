import { SlashCommandBuilder } from 'discord.js';
import { getCircleSnapshot } from '../core/uma.js';
import { store } from '../core/store.js';
import { formatNumber, formatGain } from '../core/format.js';
import { config, getConfiguredCircles } from '../core/config.js';
import { resolveQuota } from '../core/quotaKeys.js';
import { deleteAfter } from '../utils/autoDelete.js';
import { renderLeaderboard, renderInfoCard, bufferToAttachment } from '../utils/imageReport.js';

const SCOPES = [
  { name: 'Daily', value: 'daily' },
  { name: 'Weekly', value: 'weekly' },
  { name: 'Monthly', value: 'monthly' },
];

function resolveCircle(circleId) {
  const circles = getConfiguredCircles();
  if (!circleId) return circles[0];
  return circles.find(c => c.id === circleId) ?? circles[0];
}

export function buildData() {
  const circles = getConfiguredCircles();
  return new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('Circle fan-gain rankings (daily / weekly / monthly)')
    .addStringOption(opt =>
      opt
        .setName('scope')
        .setDescription('Which gain to rank by')
        .setRequired(false)
        .addChoices(...SCOPES)
    )
    .addIntegerOption(opt =>
      opt
        .setName('top')
        .setDescription('How many members to show (10–30, default 10)')
        .setMinValue(10)
        .setMaxValue(30)
        .setRequired(false)
    )
    .addStringOption(opt =>
      opt
        .setName('circle')
        .setDescription('Which circle to show (default: first circle)')
        .setRequired(false)
        .addChoices(...circles.map(c => ({ name: c.name, value: c.id })))
    );
}

export const data = buildData();

function pickValue(member, scope) {
  if (scope === 'daily') return member.todayGain;
  if (scope === 'weekly') return member.weeklyGain;
  return member.monthlyGain;
}

function isNewMember(member) {
  if (!member.joinedAt) return false;
  const joined = new Date(member.joinedAt);
  const now = new Date();
  return (
    joined.getUTCFullYear() === now.getUTCFullYear() && joined.getUTCMonth() === now.getUTCMonth()
  );
}

async function getQuota(guildId, circleId, scope) {
  const cfg = await store.getGuildConfig(guildId).catch(() => ({}));
  if (scope === 'daily') return resolveQuota(cfg, circleId, 'daily', config.dailyRequirement);
  if (scope === 'weekly') return resolveQuota(cfg, circleId, 'weekly', config.weeklyRequirement);
  return resolveQuota(cfg, circleId, 'monthly', config.monthlyRequirement);
}

export async function execute(interaction) {
  await interaction.deferReply();

  const scope = interaction.options.getString('scope') ?? 'daily';
  const top = interaction.options.getInteger('top') ?? 10;
  const circleVal = interaction.options.getString('circle');
  const scopeLabel = SCOPES.find(s => s.value === scope)?.name ?? 'Daily';
  const today = new Date().toISOString().slice(0, 10);
  const circle = resolveCircle(circleVal);

  const [snapshot, quota] = await Promise.all([
    getCircleSnapshot(circle.id),
    getQuota(interaction.guildId, circle.id, scope),
  ]);

  if (!snapshot.tallyStarted) {
    const buf = await renderInfoCard({
      title: `${snapshot.circle.name} — ${scopeLabel} Leaderboard`,
      body: 'Tally Not Started\n\nThe fan-gain tally for this month has not begun yet. Rankings will appear once the first valid gains are recorded.',
      footer: `${snapshot.members.length} active members · check back shortly`,
      accent: '#90a4ae',
    });
    const reply = await interaction.editReply({
      files: [bufferToAttachment(buf, 'leaderboard.png')],
    });
    deleteAfter(reply);
    return;
  }

  const eligible = snapshot.members.filter(m => !m.joinDay);
  const withData = eligible.filter(m => m.hasData);
  const noData = eligible.filter(m => !m.hasData);

  const ranked = [
    ...[...withData].sort((a, b) => pickValue(b, scope) - pickValue(a, scope)),
    ...noData,
  ].slice(0, top);

  const rows = ranked.map(m => {
    const gainRaw = m.hasData ? pickValue(m, scope) : 0;
    const gapRaw = gainRaw - quota;
    const pct = quota > 0 ? Math.min(200, Math.round((gainRaw / quota) * 100)) : 0;
    const gainStr = formatGain(pickValue(m, scope), m, snapshot.tallyStarted, scope);
    const gapStr = (gapRaw >= 0 ? '+' : '') + formatNumber(Math.abs(gapRaw));
    return { name: m.trainerName, gainRaw, gainStr, gapRaw, gapStr, pct, isNew: isNewMember(m) };
  });

  const buf = await renderLeaderboard({
    circleName: snapshot.circle.name,
    scope: scopeLabel,
    date: today,
    totalMembers: snapshot.members.length,
    quotaLabel: formatNumber(quota),
    rows,
  });

  const reply = await interaction.editReply({
    files: [bufferToAttachment(buf, 'leaderboard.png')],
  });
  deleteAfter(reply);
}
