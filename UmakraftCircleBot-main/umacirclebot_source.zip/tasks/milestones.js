/**
 * tasks/milestones.js
 * ─────────────────────
 * Monthly fan-milestone announcements for UmaKraft circle members.
 *
 * ── Anti-spam / restart-safe design ─────────────────────────────────────────
 *
 *  CLAIM  →  SEND CHANNEL  →  SEND MEMBER DM  →  SEND LEADER DM
 *   (DB)       (flag=1)          (flag=1)            (flag=1)
 *
 *  Each step is marked in the DB immediately after it succeeds.
 *  On bot restart the record already exists, so the outer loop skips it —
 *  UNLESS one of the flags is still 0, in which case only that step is retried.
 *
 *  Guarantees:
 *   • A member NEVER receives the same milestone announcement twice.
 *   • The channel NEVER receives the same announcement twice.
 *   • A crash between any two steps means only the missing step(s) are retried.
 *   • The per-channel cap (CHANNEL_NOTIFY_LIMIT) prevents burst spam within
 *     a single cron run.
 * ─────────────────────────────────────────────────────────────────────────────
 */

import fs from 'node:fs/promises';
import { TIERS, FALCO_POOL } from './milestone-tiers.js';
import { renderMilestone, bufferToAttachment } from '../utils/imageReport.js';
import { getCircleSnapshot } from '../core/uma.js';
import { ensureGuildChannels } from '../core/channels.js';
import { log } from '../core/log.js';
import { isLocked } from '../core/busyLock.js';
import { formatNumber } from '../core/format.js';
import { postUpdate } from '../utils/updateLog.js';
import { daysRemainingInMonth } from '../core/tally.js';
import { dmByViewerId, dmLeader } from '../utils/dm.js';
import { hasMilestoneImages, getMilestoneImages } from '../core/milestoneImages.js';
import {
  claimMilestone,
  getMilestoneRecord,
  getPositionCount,
  markChannelSent,
  markDmMemberSent,
  markDmLeaderSent,
  pruneOldMilestoneMonths,
  saveMilestoneMessageId,
  stampSpecialEligible,
  getSpecialEligibleSorted,
  pruneSpecialEligible,
} from '../db/milestoneDb.js';

// Max channel posts per channel per cron run — prevents burst if many members
// hit a threshold in the same 30-minute window.
const CHANNEL_NOTIFY_LIMIT = 5;

// ── Boot-time silent-claim guard ──────────────────────────────────────────────
// On the very first checkMilestones call after each bot restart, we claim every
// qualifying milestone into the DB (so the row exists) but skip ALL sends.
// This prevents a spam burst when the DB is missing or incomplete (fresh deploy,
// volume detach, container reset).  From the second call onward, only genuinely
// new milestones (rows inserted AFTER the silent pass) will trigger messages.
const bootedCircles = new Set();

// ── Helpers ───────────────────────────────────────────────────────────────────

function monthKey(date = new Date()) {
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, '0')}`;
}

function ordinal(n) {
  const s = ['th', 'st', 'nd', 'rd'];
  const v = n % 100;
  return n + (s[(v - 20) % 10] || s[v] || s[0]);
}

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/**
 * Shuffle within groups of rows that share the same first_qualified_at AND
 * monthly_gain (true ties). Rows in different groups keep their sorted order.
 * @param {{ trainer_id: string, first_qualified_at: string, monthly_gain: number }[]} sorted
 */
function shuffleTiedGroups(sorted) {
  const result = [];
  let i = 0;
  while (i < sorted.length) {
    let j = i + 1;
    while (
      j < sorted.length &&
      sorted[j].first_qualified_at === sorted[i].first_qualified_at &&
      sorted[j].monthly_gain === sorted[i].monthly_gain
    ) {
      j++;
    }
    result.push(...shuffle(sorted.slice(i, j)));
    i = j;
  }
  return result;
}

/** Returns a function that cycles through the pool in shuffled order. */
function makeImageIterator(pool) {
  let remaining = shuffle(pool);
  let lastUsed = null;
  return function next() {
    if (remaining.length === 0) {
      remaining = shuffle(pool);
      if (remaining.length > 1 && remaining[0] === lastUsed) {
        [remaining[0], remaining[1]] = [remaining[1], remaining[0]];
      }
    }
    lastUsed = remaining.shift();
    return lastUsed;
  };
}

async function fileExists(p) {
  try {
    await fs.access(p);
    return true;
  } catch {
    return false;
  }
}

/**
 * Build a milestone image card.
 * Returns { buffer, body, posLabel }
 */
async function buildMilestonePayload(member, tier, daysLeft, position, nextImage) {
  const mainMsg = Array.isArray(tier.main)
    ? tier.main[Math.floor(Math.random() * tier.main.length)]
    : tier.main;
  const body = tier.urgent && daysLeft <= tier.urgentDays ? tier.urgent : mainMsg;
  const posLabel = `${ordinal(position)} member to hit ${formatNumber(tier.threshold)} fans this month`;

  const imagePath =
    tier.dedicatedImage ??
    (tier.imagePool
      ? tier.imagePool[Math.floor(Math.random() * tier.imagePool.length)]
      : nextImage());
  const hasImage = await fileExists(imagePath);

  const buffer = await renderMilestone({
    trainerName: member.trainerName,
    thresholdLabel: formatNumber(tier.threshold),
    monthlyGain: formatNumber(member.monthlyGain),
    posLabel,
    message: body,
    imagePath: hasImage ? imagePath : null,
    isSpecial: !!tier.special,
    circleName: '',
  });

  return { buffer, body, posLabel };
}

/**
 * Send the milestone image to all guilds.
 * Returns { handled, sentMsg } where:
 *   handled — true if at least one guild accepted (or was throttled)
 *   sentMsg — { guildId, channelId, msgId } of the first successfully sent message
 */
async function sendChannelAnnouncement(guilds, tier, buffer, channelNotifyCount) {
  let handledByAtLeastOneGuild = false;
  let sentMsg = null;

  for (const [, partial] of guilds) {
    let guild;
    try {
      guild = await partial.fetch();
    } catch {
      continue;
    }

    let channels;
    try {
      channels = await ensureGuildChannels(guild);
    } catch {
      continue;
    }

    const { announcement } = channels;
    if (!announcement) continue;

    const channelId = announcement.id;
    const sentSoFar = channelNotifyCount.get(channelId) ?? 0;

    if (sentSoFar >= CHANNEL_NOTIFY_LIMIT) {
      log.info(
        `milestones: #${announcement.name} hit run cap (${CHANNEL_NOTIFY_LIMIT}) — skipping channel post`
      );
      handledByAtLeastOneGuild = true;
      continue;
    }

    try {
      const attachment = bufferToAttachment(buffer, 'milestone.png');
      const payload = {
        content: tier.special ? '@everyone' : undefined,
        files: [attachment],
      };
      const msg = await announcement.send(payload);
      channelNotifyCount.set(channelId, sentSoFar + 1);
      handledByAtLeastOneGuild = true;
      if (!sentMsg) {
        sentMsg = { guildId: guild.id, channelId: announcement.id, msgId: msg.id };
      }
    } catch (err) {
      log.warn(`milestones: channel send failed in ${guild.name}: ${err.message}`);
    }
  }

  return { handled: handledByAtLeastOneGuild, sentMsg };
}

// ── Main export ───────────────────────────────────────────────────────────────

export async function checkMilestones(client, circleId) {
  if (isLocked()) {
    log.info('milestones: skipped — notification lock held');
    return;
  }
  // ── Housekeeping ──────────────────────────────────────────────────────────
  try {
    pruneOldMilestoneMonths(2);
    const now = new Date();
    const cutoff = new Date(now.getFullYear(), now.getMonth() - 2, 1);
    pruneSpecialEligible(
      `${cutoff.getFullYear()}-${String(cutoff.getMonth() + 1).padStart(2, '0')}`
    );
  } catch (err) {
    log.warn('milestones: pruneOldMilestoneMonths failed:', err.message);
  }

  // ── Boot-time silent pass ─────────────────────────────────────────────────
  // The first call after each restart only claims rows into the DB without
  // sending anything.  This prevents a burst when the DB is empty (fresh deploy,
  // volume detach, container reset).  After this run isFirstRunAfterBoot is
  // false, so subsequent calls behave normally.
  const silentMode = !bootedCircles.has(circleId);
  if (silentMode) {
    log.info(
      `milestones: first run after boot for circle ${circleId} — silent claim pass (no messages sent)`
    );
  }

  // ── Fetch circle data ─────────────────────────────────────────────────────
  let snapshot;
  try {
    snapshot = await getCircleSnapshot(circleId);
  } catch (err) {
    log.warn('milestones: failed to fetch circle snapshot:', err.message);
    return;
  }
  if (!snapshot?.members?.length) return;

  const today = new Date();
  const daysLeft = daysRemainingInMonth(today);
  const month = monthKey(today);

  // Fetch all guilds once for the entire run (not needed in silent mode).
  let guilds;
  if (!silentMode) {
    try {
      guilds = await client.guilds.fetch();
    } catch (err) {
      log.warn('milestones: failed to fetch guilds:', err.message);
      return;
    }
  }

  const imagePool = hasMilestoneImages() ? getMilestoneImages() : FALCO_POOL;
  const nextImage = makeImageIterator(imagePool);

  // Per-channel post counter for this run (reset every cron tick).
  const channelNotifyCount = new Map();

  // ── Special-tier winner sets (per tier, computed once per run) ────────────
  // Priority order for the 3-slot cap:
  //   1st — who crossed the threshold EARLIEST (first_qualified_at ASC)
  //   2nd — highest monthly fan count at that moment (tiebreak for same tick)
  //   3rd — random (true tie on both above — groups shuffled in JS)
  //
  // stampSpecialEligible uses INSERT OR IGNORE, so each trainer's timestamp
  // and gain are recorded ONCE on their first qualifying tick, never updated.
  // Winners are locked in by the DB claim — re-runs won't re-roll them.
  const specialWinners = new Map(); // tierKey → Set<trainerId>
  for (const tier of TIERS) {
    if (!tier.special) continue;

    // Stamp every currently qualifying member (INSERT OR IGNORE — safe to call
    // every tick; only the first call per trainer/tier/month/circle writes).
    for (const m of snapshot.members) {
      if (!m.joinDay && m.monthlyGain >= tier.threshold) {
        stampSpecialEligible(m.trainerId, tier.key, month, circleId, m.monthlyGain);
      }
    }

    const alreadyClaimed = getPositionCount(tier.key, month, circleId);
    const slotsLeft = Math.max(0, 3 - alreadyClaimed);

    if (slotsLeft === 0) {
      // All 3 slots already filled — rebuild set from DB for retry logic.
      specialWinners.set(
        tier.key,
        new Set(
          snapshot.members
            .filter(m => getMilestoneRecord(m.trainerId, tier.key, month, circleId))
            .map(m => m.trainerId)
        )
      );
      continue;
    }

    // Fetch all stamped members sorted by priority (earliest → highest gain).
    const sortedEligible = getSpecialEligibleSorted(tier.key, month, circleId);
    const activeIds = new Set(snapshot.members.map(m => m.trainerId));

    // Filter to members still in the snapshot and not yet claimed.
    const unclaimed = sortedEligible.filter(
      r => activeIds.has(r.trainer_id) && !getMilestoneRecord(r.trainer_id, tier.key, month, circleId)
    );

    // Shuffle within groups that are truly tied (same tick AND same gain),
    // then pick the top slotsLeft entries.
    const withTieBreak = shuffleTiedGroups(unclaimed);
    const newWinners = withTieBreak.slice(0, slotsLeft).map(r => r.trainer_id);

    // Combine already-claimed winners + newly selected.
    const alreadyWon = snapshot.members
      .filter(m => getMilestoneRecord(m.trainerId, tier.key, month, circleId))
      .map(m => m.trainerId);
    specialWinners.set(tier.key, new Set([...alreadyWon, ...newWinners]));

    if (newWinners.length > 0) {
      log.info(
        `milestones: special tier ${tier.key} — ${unclaimed.length} eligible, selected ${newWinners.length} new winner(s) by priority for circle ${circleId}`
      );
    }
  }

  // ── Process each member × tier ────────────────────────────────────────────
  for (const member of snapshot.members) {
    // Skip brand-new members (joinDay flag = still in grace period).
    if (member.joinDay) continue;

    for (const tier of TIERS) {
      // Not enough fans for this tier.
      if (member.monthlyGain < tier.threshold) continue;

      // Special tiers (60M/80M/100M): only selected winners per circle get it.
      if (tier.special && !specialWinners.get(tier.key)?.has(member.trainerId)) continue;

      // ── Check existing DB record ────────────────────────────────────────
      const record = getMilestoneRecord(member.trainerId, tier.key, month, circleId);

      if (record) {
        // Already claimed. In silent mode skip everything — we only care about
        // ensuring rows exist, not about retrying pending sends right now.
        if (silentMode) continue;

        // Normal mode: check if any sends are still pending (restart retry).
        const allDone = record.channel_sent && record.dm_member_sent && record.dm_leader_sent;
        if (allDone) continue; // Nothing left to do.

        // Retry only the parts that haven't been marked done yet.
        await retrySends(
          client,
          guilds,
          member,
          tier,
          month,
          record,
          channelNotifyCount,
          nextImage,
          daysLeft,
          snapshot,
          circleId
        );
        continue;
      }

      // ── New milestone — claim atomically before sending ─────────────────
      // getPositionCount is called BEFORE the INSERT so the ordinal is correct.
      const position = getPositionCount(tier.key, month, circleId) + 1;
      const claimed = claimMilestone(member.trainerId, tier.key, month, position, circleId);

      // If claimed = false, another concurrent tick beat us — skip.
      if (!claimed) continue;

      // Silent mode: mark all sends complete immediately so retry logic never
      // tries to deliver these "phantom" boot-time claims.
      if (silentMode) {
        markChannelSent(member.trainerId, tier.key, month, circleId);
        markDmMemberSent(member.trainerId, tier.key, month, circleId);
        markDmLeaderSent(member.trainerId, tier.key, month, circleId);
        log.info(
          `milestones: silent-claim — ${member.trainerName} ${tier.key} (already qualified at boot)`
        );
        continue;
      }

      log.info(`milestones: NEW — ${member.trainerName} hit ${tier.key} (position ${position})`);

      // Build the milestone image card.
      const { buffer, body, posLabel } = await buildMilestonePayload(
        member,
        tier,
        daysLeft,
        position,
        nextImage
      );

      // ── Channel announcement ───────────────────────────────────────────
      const { handled: channelOk, sentMsg } = await sendChannelAnnouncement(
        guilds,
        tier,
        buffer,
        channelNotifyCount
      );

      if (!channelOk) {
        // All guilds failed — leave channel_sent = 0 so next tick retries.
        log.error(
          `milestones: channel send failed for ALL guilds — will retry next tick (${member.trainerName}:${tier.key})`
        );
      } else {
        markChannelSent(member.trainerId, tier.key, month, circleId);
        // Store the message ID so the 24h cleanup task can delete it later.
        if (sentMsg) {
          saveMilestoneMessageId(
            member.trainerId,
            tier.key,
            month,
            sentMsg.guildId,
            sentMsg.channelId,
            sentMsg.msgId,
            circleId
          );
        }
        // Notify #update channel.
        postUpdate(
          client,
          '🎉',
          `${member.trainerName} hit ${formatNumber(tier.threshold)} fans!`,
          `${posLabel}`
        ).catch(() => {});
      }

      // ── DM the member ──────────────────────────────────────────────────
      const dmMemberSent = await dmByViewerId(
        client,
        member.trainerId,
        buildMemberDmText(member, tier, body, posLabel, snapshot.circle.name)
      );
      if (dmMemberSent) markDmMemberSent(member.trainerId, tier.key, month, circleId);

      // ── DM the leader ──────────────────────────────────────────────────
      const dmLeaderSent = await dmLeader(
        client,
        snapshot,
        buildLeaderDmText(member, tier, position)
      );
      if (dmLeaderSent) markDmLeaderSent(member.trainerId, tier.key, month, circleId);
    }
  }

  // ── Mark first run complete ───────────────────────────────────────────────
  if (silentMode) {
    bootedCircles.add(circleId);
    log.info(
      `milestones: silent claim pass complete for circle ${circleId} — normal sends resume next tick`
    );
  }
}

// ── Retry helper (used after a crash-restart) ────────────────────────────────

/**
 * Called when a milestone record exists but some sends are still pending.
 * Retries only the steps whose flag is still 0.
 */
async function retrySends(
  client,
  guilds,
  member,
  tier,
  month,
  record,
  channelNotifyCount,
  nextImage,
  daysLeft,
  snapshot,
  circleId
) {
  const { position } = record;
  log.info(
    `milestones: RETRY pending sends for ${member.trainerName}:${tier.key} (ch=${record.channel_sent} dm_m=${record.dm_member_sent} dm_l=${record.dm_leader_sent})`
  );

  let buffer = null,
    body = null,
    posLabel = null;

  // Only build the payload if we need to send something that requires it.
  const needsBuffer = !record.channel_sent;
  if (needsBuffer || !record.dm_member_sent) {
    const built = await buildMilestonePayload(member, tier, daysLeft, position, nextImage);
    buffer = built.buffer;
    body = built.body;
    posLabel = built.posLabel;
  }

  // Retry channel
  if (!record.channel_sent) {
    const { handled: ok, sentMsg } = await sendChannelAnnouncement(
      guilds,
      tier,
      buffer,
      channelNotifyCount
    );
    if (ok) {
      markChannelSent(member.trainerId, tier.key, month, circleId);
      if (sentMsg) {
        saveMilestoneMessageId(
          member.trainerId,
          tier.key,
          month,
          sentMsg.guildId,
          sentMsg.channelId,
          sentMsg.msgId,
          circleId
        );
      }
      log.info(`milestones: retry channel OK for ${member.trainerName}:${tier.key}`);
    }
  }

  // Retry member DM
  if (!record.dm_member_sent) {
    if (!body) {
      const built = await buildMilestonePayload(member, tier, daysLeft, position, nextImage);
      body = built.body;
      posLabel = built.posLabel;
    }
    const ok = await dmByViewerId(
      client,
      member.trainerId,
      buildMemberDmText(member, tier, body, posLabel, snapshot.circle.name)
    );
    if (ok) markDmMemberSent(member.trainerId, tier.key, month, circleId);
  }

  // Retry leader DM
  if (!record.dm_leader_sent) {
    const ok = await dmLeader(client, snapshot, buildLeaderDmText(member, tier, position));
    if (ok) markDmLeaderSent(member.trainerId, tier.key, month, circleId);
  }
}

// ── DM text builders ──────────────────────────────────────────────────────────

function buildMemberDmText(member, tier, body, posLabel, circleName) {
  const header = tier.dmHeader ?? '🎉 **Milestone reached!**';
  return (
    `${header}\n\n` +
    `${body}\n\n` +
    `You've hit **${formatNumber(tier.threshold)} fans** this month in **${circleName}**!\n` +
    `**Current monthly gain:** ${formatNumber(member.monthlyGain)}\n` +
    `*You are the ${posLabel}!*`
  );
}

function buildLeaderDmText(member, tier, position) {
  if (tier.special) {
    const label = formatNumber(tier.threshold);
    return (
      `${tier.embedTitle}\n\n` +
      `**${member.trainerName}** just secured a **Top (1–3) spot** with over **${label} fans** this month! 🏇✨\n` +
      `**Current monthly gain:** ${formatNumber(member.monthlyGain)}\n` +
      `*${ordinal(position)} member to reach ${label} this month.*`
    );
  }
  return (
    `📢 **Milestone alert!**\n\n` +
    `**${member.trainerName}** just hit **${formatNumber(tier.threshold)} fans** this month!\n` +
    `**Current monthly gain:** ${formatNumber(member.monthlyGain)}\n` +
    `*${ordinal(position)} member to reach this milestone.*`
  );
}
