/**
 * tasks/logsUpdateReport.js
 * ──────────────────────────
 * Posts a daily fan-deficit summary to #logs-update.
 *
 * Runs at 08:30 JST (after data sync + daily warnings).
 *
 * Rules:
 *   • Any member below quota is listed, sorted by monthly gain (lowest first).
 *   • Members missing 10,000,000 fans or more are GUARANTEED to appear,
 *     marked with ⭐, regardless of how many entries there are.
 *   • Remaining slots (up to 10 total) are filled with the next lowest.
 *   • Members below quota but missing < 10M fill slots only if space remains.
 *
 * Output (text, not image — this is the activity log channel):
 *
 *   📊 **Fan Deficit Report — May 24**
 *   UmaKraft · 4 member(s) below 30,000,000 goal
 *
 *   ⭐ 1. TrainerA — 5,200,000 fans · ❗ missing 24,800,000
 *   ⭐ 2. TrainerB — 8,100,000 fans · ❗ missing 21,900,000
 *   ❌ 3. TrainerC — 22,500,000 fans · missing 7,500,000
 *
 *   ✅ 26 member(s) on track
 *   ⭐ = missing 10M+ fans — priority alert
 */

import { getCircleSnapshot } from '../core/uma.js';
import { getUpdateChannel } from '../core/channels.js';
import { config } from '../core/config.js';
import { store } from '../core/store.js';
import { formatNumber } from '../core/format.js';
import { log } from '../core/log.js';
import { isLocked } from '../core/busyLock.js';
import { resolveQuota } from '../core/quotaKeys.js';

const GUARANTEE_GAP = 10_000_000; // 10M missing → guaranteed listing
const MAX_SLOTS = 10; // max total entries in the list

/** Resolve per-guild monthly requirement for the given circle (falls back to global config). */
async function getMonthlyReq(guildId, circleId) {
  if (!guildId) return config.monthlyRequirement;
  const cfg = await store.getGuildConfig(guildId).catch(() => ({}));
  return resolveQuota(cfg, circleId, 'monthly', config.monthlyRequirement);
}

export async function postFanDeficitReport(client, circleId) {
  if (isLocked()) {
    log.info('logsUpdateReport: skipped — notification lock held');
    return;
  }
  let snapshot;
  try {
    snapshot = await getCircleSnapshot(circleId);
  } catch (err) {
    log.warn('logsUpdateReport: snapshot fetch failed:', err.message);
    return;
  }

  if (!snapshot?.members?.length) return;
  if (!snapshot.tallyStarted) {
    log.debug('logsUpdateReport: tally not started — skipping');
    return;
  }

  const today = new Date().toISOString().slice(0, 10);
  const guilds = await client.guilds.fetch();

  for (const [, partial] of guilds) {
    let guild;
    try {
      guild = await partial.fetch();
    } catch {
      continue;
    }

    const quota = await getMonthlyReq(guild.id, circleId);
    const eligible = snapshot.members.filter(m => m.hasData && !m.joinDay);
    const onTrack = eligible.filter(m => m.monthlyGain >= quota);
    const failing = eligible
      .filter(m => m.monthlyGain < quota)
      .map(m => ({ ...m, gap: quota - m.monthlyGain }))
      .sort((a, b) => a.monthlyGain - b.monthlyGain); // lowest fans first

    // Partition by guarantee threshold.
    const guaranteed = failing.filter(m => m.gap >= GUARANTEE_GAP);
    const regular = failing.filter(m => m.gap < GUARANTEE_GAP);

    // Guaranteed always shown; fill remaining slots with regular (still lowest-first).
    const regularSlots = Math.max(0, MAX_SLOTS - guaranteed.length);
    const displayList = [...guaranteed, ...regular.slice(0, regularSlots)];

    if (displayList.length === 0 && onTrack.length > 0) {
      // Everyone is on track — post a brief all-clear.
      try {
        const ch = await getUpdateChannel(guild);
        if (ch) {
          await ch.send(
            `✅ **Fan Report — ${today}**\n` +
              `All ${onTrack.length} member(s) are on track for ${formatNumber(quota)} fans · ${snapshot.circle.name}`
          );
        }
      } catch {
        /* silent */
      }
      continue;
    }

    // ── Build the message ───────────────────────────────────────────────────
    const lines = [
      `📊 **Fan Deficit Report — ${today}**`,
      `${snapshot.circle.name} · **${failing.length}** member(s) below ${formatNumber(quota)} goal`,
      '',
    ];

    displayList.forEach((m, i) => {
      const isGuaranteed = m.gap >= GUARANTEE_GAP;
      const badge = isGuaranteed ? '⭐' : '❌';
      const gapLabel = isGuaranteed
        ? `❗ missing **${formatNumber(m.gap)}**`
        : `missing ${formatNumber(m.gap)}`;

      lines.push(
        `${badge} **${i + 1}.** ${m.trainerName} — ${formatNumber(m.monthlyGain)} fans · ${gapLabel}`
      );
    });

    // Note if there are more failing members not shown.
    const hidden = failing.length - displayList.length;
    if (hidden > 0) {
      lines.push(`*…and ${hidden} more below quota (gap < 10M)*`);
    }

    lines.push('');
    lines.push(
      `✅ **${onTrack.length}** member(s) on track` +
        (guaranteed.length > 0 ? `  ·  ⭐ = missing 10M+ fans (priority alert)` : '')
    );

    // ── Post ────────────────────────────────────────────────────────────────
    try {
      const ch = await getUpdateChannel(guild);
      if (!ch) continue;
      await ch.send(lines.join('\n'));
      log.info(
        `logsUpdateReport: posted to ${guild.name} — ${displayList.length} listed, ${onTrack.length} on track`
      );
    } catch (err) {
      log.warn(`logsUpdateReport: failed in ${guild.name}: ${err.message}`);
    }
  }
}
