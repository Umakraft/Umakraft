import {
  buildSnapshot,
  setCachedSnapshot,
  findEarliestJoinDate,
  clearHistoricalCache,
  getPreviousMonthFinals,
  computeMemberStats,
} from '../core/uma.js';
import { store } from '../core/store.js';
import { log } from '../core/log.js';
import { config } from '../core/config.js';

/**
 * Live status for the most recent data sync attempt.
 * Read by core/health.js to surface sync health via GET /health.
 */
export const syncStatus = {
  lastSyncAt: null,
  lastSyncError: null,
  lastSyncCircleId: null,
  consecutiveFailures: 0,
};

/**
 * Processing order (per spec):
 *  1. Fetch fresh data from uma.moe and build a snapshot
 *  2. Detect newly joined / returned members
 *  3. Assign historically accurate join dates (walks back up to 6 months)
 *  4. Calculate daily fan gains with join-day zero + 30M spike guard
 *  5. Save corrected values (dedup-safe — safe to run multiple times per day)
 *  6. Update the in-memory cache so commands get fresh data without extra API calls
 *  7. Mark left members; never overwrite an existing join date unless an earlier one is found
 *
 * circleId defaults to the main circle. Pass a different ID to sync a secondary circle.
 * Each circle uses its own namespaced storage so data never cross-contaminates.
 */
export async function syncCircleData(circleId = config.circleId) {
  const today = new Date();
  const todayStr = today.toISOString().slice(0, 10);
  const nowIso = today.toISOString();

  // ── Step 1: Fetch raw data ─────────────────────────────────────────────────
  let snapshot;
  try {
    snapshot = await buildSnapshot(circleId);
  } catch (err) {
    syncStatus.lastSyncError = err.message;
    syncStatus.lastSyncCircleId = circleId;
    syncStatus.consecutiveFailures += 1;
    log.error(`dataSync(${circleId}): failed to fetch uma.moe data:`, err.message);
    return;
  }

  const classified = snapshot.rawClassified;
  const known = await store.getMembersForCircle(circleId);

  // ── Steps 2-3: Detect new/returned members and resolve join dates ──────────
  const newViewerIds = new Set();
  for (const m of classified) {
    if (!m.active) continue;
    const existing = known[m.trainerId];
    if (!existing || existing.leftAt) {
      newViewerIds.add(m.trainerId);
    }
  }

  const resolvedJoinDates = new Map();
  for (const trainerId of newViewerIds) {
    let joinDate;
    try {
      const historical = await findEarliestJoinDate(
        trainerId,
        today.getUTCFullYear(),
        today.getUTCMonth() + 1,
        circleId
      );
      if (historical) {
        joinDate = historical;
        log.debug(`dataSync(${circleId}): ${trainerId} historical join → ${joinDate}`);
      } else {
        const raw = classified.find(m => m.trainerId === trainerId);
        if (raw && raw.firstNonZeroIdx >= 0) {
          joinDate = new Date(
            Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), raw.firstNonZeroIdx + 1)
          ).toISOString();
        } else {
          joinDate = nowIso;
        }
      }
    } catch (err) {
      log.warn(
        `dataSync(${circleId}): could not determine join date for ${trainerId}: ${err.message}`
      );
      joinDate = nowIso;
    }

    const existingJoin = known[trainerId]?.joinedAt;
    if (!existingJoin || joinDate < existingJoin) {
      resolvedJoinDates.set(trainerId, joinDate);
    }
  }

  clearHistoricalCache();

  // ── Step 5a: Persist member records (circle-scoped) ────────────────────────
  const seenViewerIds = new Set();
  let newCount = 0;
  let leftCount = 0;
  let returnedCount = 0;

  for (const m of classified) {
    if (!m.active) continue;
    seenViewerIds.add(m.trainerId);

    const existing = known[m.trainerId];
    const joinedAt = resolvedJoinDates.get(m.trainerId) ?? existing?.joinedAt ?? nowIso;

    if (!existing) {
      newCount += 1;
      await store.upsertMemberForCircle(circleId, m.trainerId, {
        trainerName: m.trainerName,
        joinedAt,
        firstSeenAt: nowIso,
        lastSeen: nowIso,
        leftAt: null,
      });
    } else if (existing.leftAt) {
      returnedCount += 1;
      await store.upsertMemberForCircle(circleId, m.trainerId, {
        trainerName: m.trainerName,
        joinedAt,
        lastSeen: nowIso,
        leftAt: null,
      });
    } else {
      const patch = { trainerName: m.trainerName, lastSeen: nowIso };
      if (resolvedJoinDates.has(m.trainerId)) {
        patch.joinedAt = resolvedJoinDates.get(m.trainerId);
      }
      await store.upsertMemberForCircle(circleId, m.trainerId, patch);
    }
  }

  // Mark members no longer in THIS circle as having left.
  // Only looks at members stored for this specific circle — other circles unaffected.
  for (const [trainerId, info] of Object.entries(known)) {
    if (!seenViewerIds.has(trainerId) && !info.leftAt) {
      leftCount += 1;
      await store.upsertMemberForCircle(circleId, trainerId, { leftAt: nowIso });
    }
  }

  // ── Steps 4-5b: Compute and save daily gains (circle-scoped) ──────────────
  const prevValues = await getPreviousMonthFinals(circleId, today).catch(err => {
    log.warn(`dataSync(${circleId}): could not get previous month finals:`, err.message);
    return {};
  });

  const updatedMembers = await store.getMembersForCircle(circleId);
  let savedGains = 0;

  for (const m of classified) {
    if (!m.active) continue;
    const storedMember = updatedMembers[m.trainerId];
    const stats = computeMemberStats(m, {
      previousMonthFinal: prevValues[m.trainerId] ?? null,
      joinedAtIso: storedMember?.joinedAt ?? null,
      today,
    });
    await store.storeDailyGainForCircle(
      circleId,
      m.trainerId,
      todayStr,
      stats.todayGain,
      m.latestValue
    );
    savedGains += 1;
  }

  // Prune old gain records once a month (per circle).
  const pruneKey = `lastGainPrune_${circleId}`;
  const lastPrune = await store.getState(pruneKey);
  if (!lastPrune || Date.now() - new Date(lastPrune).getTime() > 30 * 24 * 60 * 60 * 1000) {
    await store.pruneDailyGainsForCircle(circleId, 90);
    await store.setState(pruneKey, nowIso);
  }

  // ── Step 6: Rebuild cache in-process (no extra API call) ──────────────────
  try {
    const enriched = classified.map(m => {
      const stored = updatedMembers[m.trainerId];
      const joinedAt = stored?.joinedAt ?? null;
      const stats = computeMemberStats(m, {
        previousMonthFinal: prevValues[m.trainerId] ?? null,
        joinedAtIso: joinedAt,
        today,
      });
      return { ...m, ...stats, joinedAt };
    });
    const activeMembers = enriched.filter(m => m.active);
    const leftMembers = enriched.filter(m => !m.active);
    const tallyStarted = activeMembers.some(m => m.hasData);
    setCachedSnapshot(circleId, {
      circle: snapshot.circle,
      members: activeMembers,
      allMembers: enriched,
      leftMembers,
      rawClassified: classified,
      todayDay: today.getUTCDate(),
      latestIdx: classified.reduce((acc, m) => Math.max(acc, m.latestIdx), 0),
      tallyStarted,
    });
  } catch (err) {
    log.warn(
      `dataSync(${circleId}): in-process snapshot rebuild failed — cache may be stale:`,
      err.message
    );
  }

  await store.setState(`lastDataSync_${circleId}`, nowIso);

  // Update live sync status so health endpoint can reflect it.
  syncStatus.lastSyncAt = nowIso;
  syncStatus.lastSyncError = null;
  syncStatus.lastSyncCircleId = circleId;
  syncStatus.consecutiveFailures = 0;

  const summary = `${seenViewerIds.size} active, +${newCount} new${returnedCount ? ` (${returnedCount} returned)` : ''}, -${leftCount} left`;
  if (newCount || leftCount || returnedCount) {
    log.info(`dataSync(${circleId}): ${summary}, saved ${savedGains} daily records`);
  } else {
    log.debug(`dataSync(${circleId}): ${summary}`);
  }

  return { activeCount: seenViewerIds.size, newCount, leftCount, returnedCount };
}
