import cron from 'node-cron';
import { PermissionsBitField } from 'discord.js';
import { config, getConfiguredCircles } from '../core/config.js';
import { log } from '../core/log.js';
import { store } from '../core/store.js';
import { syncCircleData } from './dataSync.js';
import { checkAndSendGreetings } from './dailyMessages.js';
import { postWeeklyLeaderboard, postWeeklyHelp } from './weeklyAnnouncement.js';
import { maybePostTallyResults } from './tallyResults.js';
import { checkMilestones } from './milestones.js';
import { cleanupMilestoneMessages } from './milestoneCleanup.js';
import { sendOnboardingReminders } from './onboardingReminder.js';
import { postDailyWarnings } from './dailyWarnings.js';
import { runNameLinker } from './nameLinker.js';
import { cleanupCommandMessages } from './messageCleanup.js';
import { startTimelineScheduler } from '../timeline/timelineScheduler.js';
import {
  getTimelineChannel,
  getLeaderboardChannel,
  getImageArchiveChannel,
} from '../core/channels.js';
import { updateGameData } from './updateGameData.js';
import { checkOfflineMembers } from './offlineCheck.js';
import { postDailyTop3, postWeeklyTop3, postMonthlyTop3 } from './leaderboardAnnouncements.js';
import {
  postInterCircleDaily,
  postInterCircleWeekly,
  postInterCircleMonthly,
} from './interCircleAnnouncements.js';
import { postMonthlyWarning } from './monthlyWarning.js';
import { postWeeklyWarning } from './weeklyWarning.js';
import { purgeAnnouncementChannel } from './purgeAnnouncement.js';
import { purgeUmaStore } from './purgeUmaStore.js';
import { runChatArchiver } from './chatArchiver.js';
import { runImageArchive } from './imageArchive.js';
import { postFanDeficitReport } from './logsUpdateReport.js';
import { runAttendanceCheck } from './attendanceCheck.js';
import { postUpdate } from '../utils/updateLog.js';
import { postChangelogIfUpdated } from '../utils/changelog.js';
import { getUpdateChannel } from '../core/channels.js';
import { registerTask, recordTaskStart, recordTaskEnd } from '../core/taskRegistry.js';
import { runSqliteBackup } from './sqliteBackup.js';

function schedule(expr, name, fn) {
  registerTask(name, expr);
  cron.schedule(
    expr,
    async () => {
      log.debug(`task ${name}: running`);
      recordTaskStart(name);
      try {
        await fn();
        recordTaskEnd(name, true);
      } catch (err) {
        log.error(`task ${name} failed:`, err);
        recordTaskEnd(name, false, err.message);
      }
    },
    { timezone: config.timezone }
  );
  log.info(`scheduled ${name} (${expr} ${config.timezone})`);
}

export function startScheduledTasks(client) {
  // Every 30 minutes — pull fresh circle data for all configured circles (parallel)
  schedule('*/30 * * * *', 'dataSync', async () => {
    await Promise.all(getConfiguredCircles().map(c => syncCircleData(c.id)));
  });

  // Milestones run after each data sync so we react quickly (parallel)
  schedule('5,35 * * * *', 'milestones', async () => {
    await Promise.all(getConfiguredCircles().map(c => checkMilestones(client, c.id)));
  });

  // Delete milestone announcement messages that are older than 24 hours
  schedule('10,40 * * * *', 'milestoneCleanup', () => cleanupMilestoneMessages(client));

  // Trainer-card onboarding reminders — every 10 minutes (600 seconds).
  // Only fires for members who joined May 12 2026+ and haven't submitted yet.
  schedule('*/10 * * * *', 'onboardingReminder', () => sendOnboardingReminders(client));

  // Hourly greeting check — sends noon/night/midnight to each member at the
  // correct hour in THEIR local timezone. Dedup guards prevent duplicate DMs.
  schedule('0 * * * *', 'greetings', () => checkAndSendGreetings(client));

  // Daily attendance check — at 6:00 AM, scoped per circle (parallel)
  schedule('0 6 * * *', 'attendanceCheck', async () => {
    await Promise.all(getConfiguredCircles().map(c => runAttendanceCheck(client, c.id)));
  });

  // Daily warnings + daily top-3 — staggered after the 07:00 data sync
  // (sync fires at :00, warnings at :05, leaderboard at :10 to avoid a race)
  schedule('5 7 * * *', 'dailyWarnings', async () => {
    for (const c of getConfiguredCircles()) await postDailyWarnings(client, c.id);
  });
  schedule('10 7 * * *', 'dailyTop3', async () => {
    for (const c of getConfiguredCircles()) await postDailyTop3(client, c.id);
  });
  schedule('20 7 * * *', 'interCircleDaily', () => postInterCircleDaily(client));

  // Monthly 30M goal check — at 8am daily (only fires when day-of-month >= 10)
  schedule('0 8 * * *', 'monthlyWarning', async () => {
    for (const c of getConfiguredCircles()) await postMonthlyWarning(client, c.id);
  });

  // Weekly 7.5M goal check — at 8:15am daily (skips Monday — week just reset)
  schedule('15 8 * * *', 'weeklyWarning', async () => {
    for (const c of getConfiguredCircles()) await postWeeklyWarning(client, c.id);
  });

  // Daily fan-deficit log in #logs-update — at 8:30am (after warnings + data refresh)
  schedule('30 8 * * *', 'logsUpdateReport', async () => {
    for (const c of getConfiguredCircles()) await postFanDeficitReport(client, c.id);
  });

  // Offline member check — at 10am daily
  schedule('0 10 * * *', 'offlineCheck', () => checkOfflineMembers(client));

  // Weekly leaderboard + top-3 every Monday at 9am (sequential — circle 1 first)
  schedule('0 9 * * 1', 'weeklyLeaderboard', async () => {
    for (const c of getConfiguredCircles()) await postWeeklyLeaderboard(client, c.id);
  });
  schedule('5 9 * * 1', 'weeklyTop3', async () => {
    for (const c of getConfiguredCircles()) await postWeeklyTop3(client, c.id);
  });
  schedule('15 9 * * 1', 'interCircleWeekly', () => postInterCircleWeekly(client));

  // Monthly top-3 — posted at 23:00 on the last day of the month (before tally)
  // node-cron doesn't support "last day of month" natively, so we check inside the fn.
  schedule('0 23 * * *', 'monthlyTop3', async () => {
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(today.getDate() + 1);
    if (tomorrow.getMonth() !== today.getMonth()) {
      for (const c of getConfiguredCircles()) await postMonthlyTop3(client, c.id);
    }
  });
  schedule('55 22 * * *', 'interCircleMonthly', async () => {
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(today.getDate() + 1);
    if (tomorrow.getMonth() !== today.getMonth()) {
      await postInterCircleMonthly(client);
    }
  });

  // Weekly help post — every Monday at 6am
  schedule('0 6 * * 1', 'weeklyHelp', () => postWeeklyHelp(client));

  // Tally results — checked nightly, only fires on tally boundary days (sequential — circle 1 first)
  schedule('30 23 * * *', 'tallyResults', async () => {
    for (const c of getConfiguredCircles()) await maybePostTallyResults(client, false, c.id);
  });

  // Auto name linker — every 4 hours
  schedule('0 */4 * * *', 'nameLinker', () => runNameLinker(client));

  // Purge #announcement every hour: removes human messages and any bot message
  // older than 24h (including old embeds, image reports, etc.).
  schedule('0 * * * *', 'purgeAnnouncement', () => purgeAnnouncementChannel(client));

  // Clean up bot command replies older than 24h
  schedule('15 4 * * *', 'messageCleanup', () => cleanupCommandMessages(client));

  // Daily SQLite backup — 3:30 AM, keeps last 7 days
  schedule('30 3 * * *', 'sqliteBackup', () => runSqliteBackup());

  // Refresh character/game data from gametora every 24h (at 3am)
  schedule('0 3 * * *', 'updateGameData', () => updateGameData());

  // Chat archiver — moves oldest #chat message to #chat-history every 300 seconds.
  schedule('*/5 * * * *', 'chatArchiver', () => runChatArchiver(client));

  // Image archiver — preserves one image from Media category every 120 seconds.
  schedule('*/2 * * * *', 'imageArchive', () => runImageArchive(client));

  // Timeline news feed — disabled until TIMELINE_URL is set
  startTimelineScheduler(client);
}

/**
 * One-off tasks to run once the bot has been alive for some time:
 *   - Initial data sync immediately
 *   - First name-linker pass 24h after start (per spec)
 */
export async function runStartupTasks(client) {
  // Immediate data sync for all configured circles so commands work right away (parallel).
  await Promise.all(getConfiguredCircles().map(c => syncCircleData(c.id)));

  // Refresh game data in the background — don't block startup.
  updateGameData().catch(err => log.warn('initial updateGameData failed:', err.message));

  // Auto-create #uma-timeline and #leaderboard in every guild.
  // Also delete the legacy #result-contribution channel now that #leaderboard handles everything.
  try {
    const guilds = await client.guilds.fetch();
    for (const [, partial] of guilds) {
      const guild = await partial.fetch();
      await getTimelineChannel(guild);
      await getLeaderboardChannel(guild);
      await getImageArchiveChannel(guild).catch(() => {});

      // ── Delete legacy channels (one-time, guarded by a store flag) ───────
      // Runs once per guild and never again — avoids unnecessary API calls
      // on every startup once the old channels have already been removed.
      const legacyPurgeKey = `legacyChannelsPurged_${guild.id}`;
      const alreadyPurged = await store.getState(legacyPurgeKey);
      if (!alreadyPurged) {
        // Delete #results-contribution (and any variant spelling)
        const allChannels = await guild.channels.fetch().catch(() => guild.channels.cache);
        for (const [, ch] of allChannels) {
          if (!ch || !ch.isTextBased()) continue;
          const norm = ch.name.toLowerCase().replace(/[\s_]/g, '-');
          if (norm.includes('result') && norm.includes('contribution')) {
            try {
              await ch.delete('Removed — #leaderboard handles all contribution tracking');
              log.info(`Deleted legacy channel #${ch.name} in ${guild.name}`);
            } catch (err) {
              log.warn(`Could not delete #${ch.name}: ${err.message}`);
            }
          }
        }

        // Clear any stored resultsChannelId so stale config doesn't cause issues.
        const gCfg = await store.getGuildConfig(guild.id);
        if (gCfg.resultsChannelId) {
          await store.setGuildConfig(guild.id, { resultsChannelId: null });
          log.info(`Cleared stale resultsChannelId for ${guild.name}`);
        }

        // Delete legacy racetrack channels
        const RACETRACK_CHANNELS = new Set([
          'sapporo',
          'hakodate',
          'niigata',
          'fukushima',
          'nakayama',
          'tokyo',
          'chukyo',
          'kyoto',
          'hanshin',
          'kokura',
          'ooi',
          'kawasaki',
          'funabashi',
          'morioka',
          'longchamp',
        ]);
        const allChannels2 = await guild.channels.fetch().catch(() => guild.channels.cache);
        const me = guild.members.me;
        for (const [, ch] of allChannels2) {
          if (!ch) continue;
          if (RACETRACK_CHANNELS.has(ch.name.toLowerCase())) {
            try {
              if (me?.permissions?.has(PermissionsBitField.Flags.ManageRoles)) {
                await ch.permissionOverwrites
                  .edit(me.id, {
                    [PermissionsBitField.Flags.ViewChannel]: true,
                    [PermissionsBitField.Flags.ManageChannels]: true,
                  })
                  .catch(() => {});
              }
              await ch.delete('Removed — legacy racetrack channel no longer used');
              log.info(`Deleted racetrack channel #${ch.name} in ${guild.name}`);
            } catch (err) {
              log.warn(`Could not delete racetrack channel #${ch.name}: ${err.message}`);
            }
          }
        }

        // Mark this guild as purged so we never run this block again.
        await store.setState(legacyPurgeKey, new Date().toISOString());
        log.info(`Legacy channel cleanup complete for ${guild.name} — will not run again`);
      }
    }
    log.info('ensureChannels: done (timeline + leaderboard)');
  } catch (err) {
    log.warn('ensureChannels: failed:', err.message);
  }

  // One-time purge of #announcement (runs only once, guarded by a store flag).
  purgeAnnouncementChannel(client).catch(err =>
    log.warn('purgeAnnouncement: failed:', err.message)
  );

  // Purge ALL messages from #uma-store on every boot — the channel should
  // always be empty. Clears accumulated /store reply leftovers from before
  // the ephemeral fix, and anything that slipped in while the bot was offline.
  purgeUmaStore(client).catch(err => log.warn('purgeUmaStore: failed:', err.message));

  // Ensure #update and #chat-history exist in every guild.
  try {
    const guilds = await client.guilds.fetch();
    for (const [, partial] of guilds) {
      const guild = await partial.fetch().catch(() => null);
      if (!guild) continue;
      await getUpdateChannel(guild).catch(() => {});
    }
  } catch {}

  // Post changelog to #logs-update if the bot was updated since last run.
  // Guarded by git commit hash — same hash = silent skip, no matter how many
  // times the bot restarts with identical code.
  setTimeout(async () => {
    postChangelogIfUpdated(client).catch(err =>
      log.warn('changelog: startup post failed:', err.message)
    );
  }, 5_000);

  // Post a "bot is online" notification to #logs-update — throttled to once per
  // 10 minutes so rapid restarts don't spam the channel. Fires after the
  // changelog (8s) so the two messages appear in the right order.
  setTimeout(async () => {
    const COOLDOWN_MS = 10 * 60 * 1000; // 10 minutes
    const lastOnline = await store.getState('lastOnlineNotification').catch(() => null);
    const elapsed = lastOnline ? Date.now() - new Date(lastOnline).getTime() : Infinity;
    if (elapsed >= COOLDOWN_MS) {
      await store.setState('lastOnlineNotification', new Date().toISOString()).catch(() => {});
      postUpdate(client, '🟢', 'Bot is online', `UmaKraft circle bot started successfully.`).catch(
        () => {}
      );
    } else {
      log.info(
        `startup: skipped "bot is online" notification (restarted ${Math.round(elapsed / 1000)}s ago)`
      );
    }
  }, 8_000);

  // Timeline is handled entirely by the 5-minute cron (startTimelineScheduler).
  // Running an extra scan here on every boot causes #uma-timeline to be purged
  // and reposted on each restart — skipped to prevent restart spam.

  // Schedule the first name-linker pass at +24h.
  setTimeout(
    () => {
      runNameLinker(client).catch(err => log.error('initial nameLinker failed:', err));
    },
    24 * 60 * 60 * 1000
  );
}
