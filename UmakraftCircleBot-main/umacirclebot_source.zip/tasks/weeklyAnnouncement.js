import { getCircleSnapshot } from '../core/uma.js';
import { ensureGuildChannels, getLeaderboardChannel } from '../core/channels.js';
import { formatNumber } from '../core/format.js';
import { store } from '../core/store.js';
import { log } from '../core/log.js';
import { isLocked } from '../core/busyLock.js';
import { renderWeeklyReport, renderHelpCard, bufferToAttachment } from '../utils/imageReport.js';

export async function postWeeklyLeaderboard(client, circleId) {
  if (isLocked()) {
    log.info('weeklyAnnouncement: skipped — notification lock held');
    return;
  }
  let snapshot;
  try {
    snapshot = await getCircleSnapshot(circleId);
  } catch (err) {
    log.warn('weeklyAnnouncement: failed to fetch data:', err.message);
    return;
  }

  const eligible = snapshot.members.filter(m => m.hasData && !m.joinDay);
  const sorted = [...eligible].sort((a, b) => b.weeklyGain - a.weeklyGain);
  const top = sorted.slice(0, 20);
  const today = new Date().toISOString().slice(0, 10);

  const rows = top.map((m, i) => ({
    rank: i + 1,
    name: m.trainerName,
    daily: formatNumber(m.todayGain),
    weekly: formatNumber(m.weeklyGain),
    monthly: formatNumber(m.monthlyGain),
  }));

  const buf = await renderWeeklyReport({
    circleName: snapshot.circle.name,
    date: today,
    rows,
  });

  const attachment = bufferToAttachment(buf, 'weekly-report.png');

  const guilds = await client.guilds.fetch();
  for (const [, partial] of guilds) {
    try {
      const guild = await partial.fetch();

      // Post to #announcement
      const { announcement } = await ensureGuildChannels(guild);
      if (announcement) {
        await announcement.send({ files: [attachment] });
      }

      // Replace pinned weekly entry in #leaderboard
      const lbChannel = await getLeaderboardChannel(guild);
      if (lbChannel) {
        const guildConfig = await store.getGuildConfig(guild.id);
        const weeklyKey = `lbMsgWeeklyReport_${circleId}`;
        const prevMsgId = guildConfig[weeklyKey];
        if (prevMsgId) {
          try {
            const prev = await lbChannel.messages.fetch(prevMsgId);
            await prev.delete();
          } catch {
            /* already gone */
          }
        }
        const msg = await lbChannel.send({ files: [attachment] });
        await store.setGuildConfig(guild.id, { [weeklyKey]: msg.id });
      }
    } catch (err) {
      log.warn(`weeklyAnnouncement: ${partial.name || partial.id}: ${err.message}`);
    }
  }
}

export async function postWeeklyHelp(client) {
  if (isLocked()) {
    log.info('weeklyHelp: skipped — notification lock held');
    return;
  }

  // Dynamic import avoids circular-module init race with deploy-commands.js
  const { COMMAND_MODULES } = await import('../core/deploy-commands.js');
  const buf = await renderHelpCard(COMMAND_MODULES);
  const attachment = bufferToAttachment(buf, 'bot-commands.png');

  const guilds = await client.guilds.fetch();
  for (const [, partial] of guilds) {
    try {
      const guild = await partial.fetch();
      const { announcement } = await ensureGuildChannels(guild);
      if (announcement) {
        await announcement.send({ files: [attachment] });
      }
    } catch (err) {
      log.warn(`postWeeklyHelp: ${partial.name || partial.id}: ${err.message}`);
    }
  }
}
