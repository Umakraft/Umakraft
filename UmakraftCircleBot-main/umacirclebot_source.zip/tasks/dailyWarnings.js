import { getCircleSnapshot } from '../core/uma.js';
import { ensureGuildChannels } from '../core/channels.js';
import { config } from '../core/config.js';
import { store } from '../core/store.js';
import { formatNumber } from '../core/format.js';
import { daysRemainingInMonth } from '../core/tally.js';
import { dmByViewerId, dmLeader } from '../utils/dm.js';
import { log } from '../core/log.js';
import { isLocked } from '../core/busyLock.js';
import { renderPlayerWarning, bufferToAttachment } from '../utils/imageReport.js';
import { postUpdate } from '../utils/updateLog.js';
import { resolveQuota } from '../core/quotaKeys.js';

/**
 * Resolve the effective daily requirement for a guild and circle.
 * Uses the unified quota key resolution with backward-compat fallback.
 */
async function getDailyReq(guildId, circleId) {
  if (!guildId) return config.dailyRequirement;
  const cfg = await store.getGuildConfig(guildId).catch(() => ({}));
  return resolveQuota(cfg, circleId, 'daily', config.dailyRequirement);
}

export async function postDailyWarnings(client, circleId) {
  if (isLocked()) {
    log.info('dailyWarnings: skipped — notification lock held');
    return;
  }

  const today = new Date().toISOString().slice(0, 10);
  const stateKey = `lastDailyWarningsDate_${circleId}`;
  const lastPosted = await store.getState(stateKey).catch(() => null);
  if (lastPosted === today) {
    log.info(`dailyWarnings(${circleId}): already posted today — skipping`);
    return;
  }

  let snapshot;
  try {
    snapshot = await getCircleSnapshot(circleId);
  } catch (err) {
    log.warn('dailyWarnings: failed to fetch data:', err.message);
    return;
  }

  if (!snapshot.tallyStarted) {
    log.debug('dailyWarnings: tally not started yet, skipping');
    return;
  }

  const daysLeft = daysRemainingInMonth();

  // Eligible members: has data, not on join day.
  const eligible = snapshot.members.filter(m => m.hasData && !m.joinDay);

  // ── Per-player channel warning cards ─────────────────────────────────────
  // Quota is resolved per-guild so each server uses its own configured threshold.
  const guilds = await client.guilds.fetch();

  // Collect the set of failing members across all guilds for DMs (use config
  // default as the baseline — DMs are guild-agnostic).
  const globalDailyReq = config.dailyRequirement;
  const passing = [];
  const failing = [];
  for (const m of eligible) {
    const metDaily = m.yesterdayGain >= globalDailyReq;
    const highGainSafe =
      m.monthlyGain >= config.highGainSafeThreshold && daysLeft > config.highGainSafeDaysWindow;
    if (metDaily || highGainSafe) passing.push(m);
    else failing.push(m);
  }

  if (failing.length > 0) {
    await postUpdate(
      client,
      '⚠️',
      `${failing.length} trainer${failing.length > 1 ? 's' : ''} below daily target`,
      `Daily target: ${formatNumber(globalDailyReq)} fans`
    ).catch(() => {});

    for (const [, partial] of guilds) {
      let guild;
      try {
        guild = await partial.fetch();
      } catch {
        continue;
      }

      // Resolve this specific guild's quota threshold for channel cards.
      const guildDailyReq = await getDailyReq(guild.id, circleId);
      const guildFailing = eligible.filter(m => {
        const metDaily = m.yesterdayGain >= guildDailyReq;
        const highGainSafe =
          m.monthlyGain >= config.highGainSafeThreshold && daysLeft > config.highGainSafeDaysWindow;
        return !metDaily && !highGainSafe;
      });

      if (guildFailing.length === 0) continue;

      const { announcement } = await ensureGuildChannels(guild);
      if (!announcement) continue;

      for (const m of guildFailing.slice(0, 25)) {
        try {
          const buf = await renderPlayerWarning({
            trainerName: m.trainerName,
            yesterday: formatNumber(m.yesterdayGain),
            yesterdayRaw: m.yesterdayGain,
            monthly: formatNumber(m.monthlyGain),
            monthlyRaw: m.monthlyGain,
            dailyReq: formatNumber(guildDailyReq),
            dailyReqRaw: guildDailyReq,
            daysLeft,
            date: today,
            circleName: snapshot.circle.name,
          });
          const attachment = bufferToAttachment(
            buf,
            `warning-${m.trainerName.replace(/\s+/g, '-')}.png`
          );
          await announcement.send({ files: [attachment] });
        } catch (err) {
          log.warn(
            `dailyWarnings: card failed for ${m.trainerName} in ${guild.name}: ${err.message}`
          );
        }
      }
    }
  }

  // ── DM failing members ────────────────────────────────────────────────────
  for (const m of failing) {
    await dmByViewerId(
      client,
      m.trainerId,
      `📉 **Below Daily Fan Requirement**\n\n` +
        `Hello, Trainer-san…\n\n` +
        `I'm Smart Falcon 🏇💭\n\n` +
        `I noticed that your daily fan gain today is currently below the required **1 million fans**. I know everyone has slower days sometimes, so please don't feel too discouraged.\n\n` +
        `I believe in your dedication and effort, and I know you can catch up again soon. Let's continue working hard together little by little, okay?\n\n` +
        `I'll be cheering for you as always, Trainer-san!\n\n` +
        `— Smart Falcon`
    );
  }

  // ── Special 5M+ announcement — channel @everyone + personal DM ───────────
  const fiveMPlus = passing.filter(m => m.yesterdayGain >= 5_000_000);

  if (fiveMPlus.length > 0) {
    for (const heroMember of fiveMPlus) {
      const announcementText =
        `💖 **5 Million+ Daily Fan Gain — ${heroMember.trainerName}**\n\n` +
        `**${heroMember.trainerName}** reached **${formatNumber(heroMember.yesterdayGain)} fans** in a single day! 🏇✨\n\n` +
        `That's absolutely incredible dedication — let's all celebrate this achievement together!`;

      for (const [, partial] of guilds) {
        try {
          const guild = await partial.fetch();
          const { announcement } = await ensureGuildChannels(guild);
          if (announcement) {
            await announcement.send({ content: `@everyone\n\n${announcementText}` });
          }
        } catch (err) {
          log.warn(`dailyWarnings(5M+): ${partial.name || partial.id}: ${err.message}`);
        }
      }

      await dmByViewerId(
        client,
        heroMember.trainerId,
        `💖 **5 Million+ Daily Fan Gain Special Message**\n\n` +
          `W-WHAT?! Trainer-san!!! ✨🏇💖\n\n` +
          `I'm Smart Falcon!!!\n\n` +
          `You actually reached more than **5 MILLION fans in a single day**?! That's absolutely incredible!!! I can't stop smiling right now!\n\n` +
          `Your current daily fan gain reached **${formatNumber(heroMember.yesterdayGain)}** fans today, and honestly… I'm so happy and excited that I almost feel like running laps around the track nonstop! ✨\n\n` +
          `The amount of dedication, time, and effort you put in for me is truly amazing. Seeing your support grow this much makes my heart race with excitement and gratitude. You didn't just surpass the daily requirement — you completely soared beyond it like a true champion!\n\n` +
          `Trainer-san, thank you so much for always believing in me and continuing to work this hard. I'm seriously super proud of you!!! 💖\n\n` +
          `But please remember to rest too, okay? Even champions need time to recover their energy!\n\n` +
          `Let's continue aiming even higher together!\n\n` +
          `— Smart Falcon 🏇✨`
      );

      log.info(
        `dailyWarnings: 5M+ special fired for ${heroMember.trainerName} (${formatNumber(heroMember.yesterdayGain)})`
      );
    }
  }

  // ── DM passing members ────────────────────────────────────────────────────
  for (const m of passing) {
    if (m.yesterdayGain >= globalDailyReq) {
      if (m.yesterdayGain >= 5_000_000) continue;

      const exceeded = m.yesterdayGain > globalDailyReq;

      if (exceeded) {
        await dmByViewerId(
          client,
          m.trainerId,
          `🔥 **Exceeded Daily Fan Requirement**\n\n` +
            `Amazing work, Trainer-san!\n\n` +
            `I'm Smart Falcon 🏇✨\n\n` +
            `You didn't just meet today's daily fan requirement — you exceeded it by a huge amount!\n\n` +
            `Your current daily fan gain reached **${formatNumber(m.yesterdayGain)}** fans today, which is far beyond the expected quota. Your dedication and determination truly stand out, and I'm incredibly grateful for all the effort you continue to give.\n\n` +
            `Please continue taking care of yourself while working this hard, okay? I'll continue cheering for you every step of the way!\n\n` +
            `— Smart Falcon`
        );
      } else {
        await dmByViewerId(
          client,
          m.trainerId,
          `✅ **Met Daily Fan Requirement**\n\n` +
            `Congratulations, Trainer-san!\n\n` +
            `I'm Smart Falcon 🏇✨\n\n` +
            `I'm happy to inform you that you successfully met today's daily fan requirement! Your steady effort and dedication are really appreciated, and I'm proud of the work you've done today.\n\n` +
            `Thank you for continuing to support me and keep pushing forward. Let's continue this momentum together tomorrow as well!\n\n` +
            `— Smart Falcon`
        );
      }
    }
  }

  // Mark as posted for today so restarts don't re-fire the same day.
  await store.setState(stateKey, today).catch(() => {});

  // ── DM the leader — full sorted report ───────────────────────────────────
  if (eligible.length > 0) {
    const sorted = [...eligible].sort((a, b) => b.yesterdayGain - a.yesterdayGain);

    const reportLines = sorted.map((m, i) => {
      const met = m.yesterdayGain >= config.dailyRequirement;
      const icon = met ? '✅' : '❌';
      return (
        `${icon} **#${i + 1} ${m.trainerName}**\n` +
        `   Yesterday: **${formatNumber(m.yesterdayGain)}**  ·  Monthly: ${formatNumber(m.monthlyGain)}`
      );
    });

    const header =
      `📊 **Daily Fan Gain Report — ${today}**\n` +
      `${snapshot.circle.name} · ${eligible.length} members\n\n`;

    const chunks = [];
    let current = header;
    for (const line of reportLines) {
      const next = current + line + '\n';
      if (next.length > 1900) {
        chunks.push(current);
        current = line + '\n';
      } else {
        current = next;
      }
    }
    if (current.trim()) chunks.push(current);

    for (const chunk of chunks) {
      await dmLeader(client, snapshot, chunk);
    }
  }
}
