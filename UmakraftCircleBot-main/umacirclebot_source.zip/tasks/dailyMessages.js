/**
 * dailyMessages.js
 * ─────────────────
 * Sends timed greeting DMs to every linked member based on THEIR local timezone.
 * Called every hour by the scheduler. Each greeting type fires at most once per
 * calendar day per member (dedup guards), preventing duplicate DMs.
 *
 * Greeting schedule (local time):
 *   12:00 → noon greeting
 *   21:00 → night greeting
 *   00:00 → midnight greeting
 *   Morning → handled separately via presenceUpdate (first online of the day)
 */

import { store } from '../core/store.js';
import { log } from '../core/log.js';
import { isLocked } from '../core/busyLock.js';

const DEFAULT_TZ = 'Asia/Tokyo';

// ── Messages ──────────────────────────────────────────────────────────────────

const NOON_MSG =
  `☀️ **Noon Greeting**\n\n` +
  `Good noon, Trainer-san!\n\n` +
  `I'm Smart Falcon ☀️🏇\n\n` +
  `The sun is high, so make sure to take a short break and recharge your energy. ` +
  `You've been working hard, and I'll continue cheering for you through the rest of the day. ` +
  `Let's keep moving forward together!\n\n` +
  `— Smart Falcon`;

const NIGHT_MSG =
  `🌙 **Night Greeting**\n\n` +
  `Good night, Trainer-san!\n\n` +
  `I'm Smart Falcon 🌙🏇\n\n` +
  `You worked hard today, so please make sure to get plenty of rest tonight. ` +
  `Tomorrow is another chance to do your best, and I'll be waiting to cheer you on again with full energy!\n\n` +
  `Sleep well, Trainer-san.\n\n` +
  `— Smart Falcon`;

const MIDNIGHT_MSG =
  `🌌 **Midnight Greeting**\n\n` +
  `Midnight already, Trainer-san…\n\n` +
  `I'm Smart Falcon 🌙🏇\n\n` +
  `I noticed you're still awake and working hard for me even at this hour… I'm really grateful, but also a little worried.\n\n` +
  `Your effort means a lot to me, but I also want you to stay healthy and get proper rest. ` +
  `Please don't push yourself too much tonight, okay?\n\n` +
  `Let's continue again tomorrow with fresh energy together.\n\n` +
  `Good night, Trainer-san.\n\n` +
  `— Smart Falcon`;

// ── Dedup guards ──────────────────────────────────────────────────────────────
// Key format: "discordId:YYYY-MM-DD" using the member's LOCAL date.
// Cleared automatically each run (only same-day keys accumulate).

const sentToday = {
  noon: new Set(),
  night: new Set(),
  midnight: new Set(),
};

// ── Helpers ───────────────────────────────────────────────────────────────────

/**
 * Get the local hour (0–23) for a given IANA timezone.
 * Handles the edge case where some environments return "24" for midnight.
 */
function getLocalHour(tz) {
  try {
    const parts = new Intl.DateTimeFormat('en-US', {
      timeZone: tz,
      hour: 'numeric',
      hour12: false,
    }).formatToParts(new Date());
    const h = parseInt(parts.find(p => p.type === 'hour')?.value ?? '0', 10);
    return h === 24 ? 0 : h;
  } catch {
    return -1;
  }
}

/**
 * Get the local calendar date string (YYYY-MM-DD) for a given timezone.
 */
function getLocalDateStr(tz) {
  try {
    return new Date().toLocaleDateString('en-CA', { timeZone: tz });
  } catch {
    return new Date().toISOString().slice(0, 10);
  }
}

/**
 * Build a dedup key using the member's own local date, preventing cross-day issues.
 */
function dedupKey(discordId, tz) {
  return `${discordId}:${getLocalDateStr(tz)}`;
}

// ── Main export ───────────────────────────────────────────────────────────────

/**
 * Check every linked member's local time and send the appropriate greeting.
 * Called once per hour by the scheduler.
 * Each greeting type is sent at most once per calendar day per member.
 */
export async function checkAndSendGreetings(client) {
  if (isLocked()) {
    log.info('dailyMessages: skipped — notification lock held');
    return;
  }
  const links = await store.getLinks();
  const discordIds = Object.keys(links);
  if (!discordIds.length) return;

  let sent = 0;

  for (const discordId of discordIds) {
    try {
      const tz = (await store.getTimezone(discordId)) || DEFAULT_TZ;
      const hour = getLocalHour(tz);
      if (hour < 0) continue;

      let type = null;
      let msg = null;
      if (hour === 12) {
        type = 'noon';
        msg = NOON_MSG;
      } else if (hour === 21) {
        type = 'night';
        msg = NIGHT_MSG;
      } else if (hour === 0) {
        type = 'midnight';
        msg = MIDNIGHT_MSG;
      }

      if (!type) continue;

      const key = dedupKey(discordId, tz);
      if (sentToday[type].has(key)) continue;
      sentToday[type].add(key);

      const user = await client.users.fetch(discordId);
      await user.send(msg);
      sent++;
    } catch (err) {
      log.warn(`dailyMessages: could not greet ${discordId}: ${err.message}`);
    }
  }

  if (sent > 0) {
    log.info(`dailyMessages: sent ${sent} greeting(s)`);
  }
}
