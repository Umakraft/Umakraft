import { Events } from 'discord.js';
import { store } from '../core/store.js';
import { log } from '../core/log.js';

// In-memory set of Discord user IDs currently online.
// Populated/cleared via PresenceUpdate events.
export const onlineUsers = new Set();

// Guards against sending the morning DM more than once per day per member.
// Key format: "discordId:YYYY-MM-DD"
const morningGreetedToday = new Set();

// Prune keys from previous days to prevent unbounded memory growth.
function pruneGreetedSet() {
  const today = new Date().toISOString().slice(0, 10);
  for (const key of morningGreetedToday) {
    if (!key.endsWith(`:${today}`)) morningGreetedToday.delete(key);
  }
}

const MORNING_MSG =
  `🌅 **Morning Greeting**\n\n` +
  `Good morning, Trainer-san!\n\n` +
  `I'm Smart Falcon 🏇✨\n\n` +
  `Let's start today with energy and a smile! I'll be cheering for you so we can make this another exciting and successful day together. Don't forget to eat properly and take care of yourself too!\n\n` +
  `— Smart Falcon`;

function todayKey(discordId) {
  return `${discordId}:${new Date().toISOString().slice(0, 10)}`;
}

export function register(client) {
  client.on(Events.PresenceUpdate, async (oldPresence, newPresence) => {
    try {
      pruneGreetedSet();

      const userId = newPresence?.userId;
      if (!userId) return;
      if (newPresence.user?.bot) return;

      const newStatus = newPresence.status; // 'online' | 'idle' | 'dnd' | 'offline' | 'invisible'
      const oldStatus = oldPresence?.status ?? 'offline';

      const isNowActive = newStatus === 'online' || newStatus === 'idle' || newStatus === 'dnd';
      const wasOffline = !oldPresence || oldStatus === 'offline' || oldStatus === 'invisible';

      if (isNowActive) {
        onlineUsers.add(userId);
        await store.setState(`lastSeen:${userId}`, new Date().toISOString());
      } else {
        onlineUsers.delete(userId);
        await store.setState(`lastSeen:${userId}`, new Date().toISOString());
      }

      // Morning greeting fires only when transitioning from offline → active for the first time today.
      if (!wasOffline || !isNowActive) return;

      const key = todayKey(userId);
      if (morningGreetedToday.has(key)) return;

      const links = await store.getLinks();
      if (!Object.prototype.hasOwnProperty.call(links, userId)) return;

      morningGreetedToday.add(key);

      const user = await client.users.fetch(userId);
      try {
        await user.send(MORNING_MSG);
        log.info(`presenceUpdate: sent morning greeting to ${user.tag}`);
      } catch (dmErr) {
        // User has DMs disabled or has blocked the bot — not a real error.
        // Remove the guard key so we retry the next time they come online today.
        morningGreetedToday.delete(key);
        log.debug(`presenceUpdate: DM blocked for ${user.tag} — ${dmErr.message}`);
      }
    } catch (err) {
      log.warn(`presenceUpdate handler error: ${err.message}`);
    }
  });
}
