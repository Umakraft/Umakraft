import { Events, PermissionFlagsBits } from 'discord.js';
import { upsertTrainer, upsertTrainerSkills, getTrainerById } from '../db/trainerDb.js';
import { fetchTrainerProfile, getCircleSnapshot, buildSnapshot } from '../core/uma.js';
import { refreshLeaderboard } from '../trainer/trainerLeaderboard.js';
import { store } from '../core/store.js';
import { getConfiguredCircles } from '../core/config.js';
import { log } from '../core/log.js';
import { getUmaResultsChannel, getFriendChannel, getBehaviourChannel } from '../core/channels.js';
import { getOnboardingRow, markCardProvided, setPendingVerification } from '../db/onboardingDb.js';
import { jstDate, jstTime } from '../core/format.js';
import { classifyUmaImage } from '../utils/imageClassifier.js';
import { resolveAndLink, resolveAndLinkByName, notifyOwnerPending } from '../utils/verificationHelper.js';

// ── Media-post dedup (once per user per day, in-memory) ───────────────────────
const _mediaNotified = new Map();

function shouldNotifyMedia(userId, guildId) {
  const key = `${guildId}:${userId}`;
  const today = jstDate();
  if (_mediaNotified.get(key) === today) return false;
  if (_mediaNotified.size > 200) {
    for (const [k, d] of _mediaNotified) {
      if (d !== today) _mediaNotified.delete(k);
    }
  }
  _mediaNotified.set(key, today);
  return true;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function isAdminMember(member) {
  if (!member) return false;
  return (
    member.permissions.has(PermissionFlagsBits.Administrator) ||
    member.permissions.has(PermissionFlagsBits.ManageGuild)
  );
}

function expiresAt72h() {
  const d = new Date(Date.now() + 72 * 60 * 60 * 1000);
  return d.toISOString().replace('T', ' ').slice(0, 19);
}

const TRAINER_ID_RE = /^\s*(\d[\d\s]{7,14}\d)\s*$/;
const STORE_CMD_RE  = /^\s*store\s+(\d[\d\s]{7,14}\d)\s*$/i;

const MEDIA_EXTENSIONS   = /\.(png|jpe?g|gif|webp|mp4|mov|webm)$/i;
const MEDIA_CONTENT_TYPES = [
  'image/png', 'image/jpeg', 'image/gif', 'image/webp',
  'video/mp4', 'video/quicktime', 'video/webm',
];

function hasImageAttachment(message) {
  return message.attachments.some(
    a => MEDIA_CONTENT_TYPES.includes(a.contentType) || MEDIA_EXTENSIONS.test(a.name ?? '')
  );
}

// resolveAndLink and resolveAndLinkByName are imported from utils/verificationHelper.js

// ── Club affiliation check ────────────────────────────────────────────────────
// Returns a warning string if the club on the card doesn't match any
// configured circle, or null if it looks fine / can't be determined.

function checkClubAffiliation(clubName) {
  if (!clubName) return null;
  const circles = getConfiguredCircles();
  const lower   = clubName.toLowerCase().trim();
  const matched = circles.some(
    c => lower.includes(c.name.toLowerCase()) || c.name.toLowerCase().includes(lower)
  );
  if (!matched) {
    return (
      `⚠️ Your trainer card shows **${clubName}** as your club, ` +
      `not detected in any configured circle.\n` +
      `Please look on uma.moe to check if you are detected. If you are not showing up on uma.moe, that is the cause — only members detected on uma.moe can be linked.`
    );
  }
  return null;
}

// ── Check if a new member is still unlinked (should be restricted) ────────────

async function isRestrictedNewMember(userId, guildId) {
  const row = getOnboardingRow(userId, guildId);
  if (!row) return false;
  // 7-day grace period — no restriction during the first 7 days
  const daysSinceJoin = (Date.now() - new Date(row.joined_at).getTime()) / 86_400_000;
  if (daysSinceJoin < 7) return false;
  // Pending or approved verification after 7 days = access granted
  if (row.verification_status === 'pending' || row.verification_status === 'approved') return false;
  // Day 8+: restricted unless they have a confirmed link
  const linked = await store.getLinkedViewerId(userId);
  return !linked;
}

// ── Trainer ID store handler (#uma-store channel) ─────────────────────────────

async function handleTrainerId(message, rawId) {
  const trainerId     = rawId.replace(/\s+/g, '');
  const resultsChannel = await getUmaResultsChannel(message.guild);
  if (!resultsChannel) {
    log.warn('handleTrainerId: could not find/create #uma-results channel');
    return;
  }

  const profile = await fetchTrainerProfile(trainerId);
  if (!profile) {
    await resultsChannel
      .send({ content: `❌ Trainer ID \`${trainerId}\` was not found on uma.moe. Please check the ID and try again.` })
      .catch(() => {});
    return;
  }

  const existing = getTrainerById(trainerId);
  try {
    upsertTrainer({
      trainer_id:        trainerId,
      character:         profile.trainer_name,
      rank_score:        profile.parent_rank ?? profile.rank_score ?? 0,
      affinity_score:    profile.affinity ?? 0,
      mile:              0,
      medium:            0,
      long_dist:         0,
      sprint:            0,
      blue_spark_count:  0,
      white_spark_count: profile.white_count ?? 0,
      win_count:         profile.win_count ?? 0,
      unique_skill:      '',
      white_skills:      '[]',
      raw_profile:       JSON.stringify(profile),
      submitted_by:      message.author.id,
      expires_at:        existing?.is_saved ? null : expiresAt72h(),
      is_saved:          existing?.is_saved ?? 0,
    });
    if (profile.white_sparks?.length) {
      upsertTrainerSkills(
        trainerId,
        profile.white_sparks.map(id => ({ skill_name: String(id), skill_type: 'white_skill' }))
      );
    }
  } catch (err) {
    log.error('handleTrainerId: DB error:', err);
    await resultsChannel
      .send({ content: `❌ Failed to store trainer \`${trainerId}\`: ${err.message}` })
      .catch(() => {});
    return;
  }

  log.info(
    `handleTrainerId: ${existing ? 'updated' : 'added'} ${trainerId} (${profile.trainer_name}) by ${message.author.tag}`
  );
  refreshLeaderboard(message.guild, trainerId).catch(err =>
    log.warn('handleTrainerId: leaderboard rebuild error:', err.message)
  );
}

// ── Forward a trainer card image to #friends ──────────────────────────────────
// When targetGuild is provided (DM path), posts only to that guild's #friends.
// Without it (guild path), posts to every guild the bot is in.

async function forwardTrainerCard(client, user, attachment, targetGuild = null) {
  let forwarded = false;
  const entries = targetGuild
    ? [[targetGuild.id, targetGuild]]
    : [...client.guilds.cache];
  for (const [, guild] of entries) {
    const friendCh = await getFriendChannel(guild).catch(() => null);
    if (!friendCh) continue;
    try {
      await friendCh.send({
        content: `🏇 **Trainer Card** from <@${user.id}> (${user.tag})`,
        files:   [attachment.proxyURL ?? attachment.url],
      });
      forwarded = true;
    } catch (err) {
      log.warn(`forwardTrainerCard: failed in ${guild.name}: ${err.message}`);
    }
  }
  return forwarded;
}

// ── Behaviour channel helper ──────────────────────────────────────────────────

async function sendBehaviour(guild, content) {
  const ch = await getBehaviourChannel(guild).catch(() => null);
  if (!ch) return;
  await ch.send({ content, flags: [4096] }).catch(() => {});
}

// ── Media post notification ───────────────────────────────────────────────────

async function notifyMediaPost(message) {
  if (!shouldNotifyMedia(message.author.id, message.guild.id)) return;
  const displayName = message.member?.displayName ?? message.author.username;
  await sendBehaviour(
    message.guild,
    `📸 **${displayName}** posted media in #${message.channel.name} · ${jstTime()}`
  );
}

// ── Hype reaction (multi-circle, once per day per user) ───────────────────────

const _hypedToday = new Map();

async function maybeHypeReaction(message) {
  if (!message.guild) return;

  const today   = jstDate();
  const hypeKey = `${message.author.id}:${today}`;
  if (_hypedToday.has(hypeKey)) return;

  let trainerId;
  try { trainerId = await store.getLinkedViewerId(message.author.id); } catch { return; }
  if (!trainerId) return;

  for (const circle of getConfiguredCircles()) {
    let snapshot;
    try { snapshot = await getCircleSnapshot(circle.id); } catch { continue; }

    const member = snapshot.members.find(m => String(m.trainerId) === String(trainerId));
    if (!member) continue;

    if (member.yesterdayGain >= 5_000_000) {
      try {
        await message.react('🏇');
        _hypedToday.set(hypeKey, true);
        log.debug(`hyped: reacted to ${message.author.tag} (${circle.name} gain=${member.yesterdayGain})`);
      } catch { /* Missing Permissions or message deleted — ignore */ }
    }
    break;
  }
}

// ── Main event handler ────────────────────────────────────────────────────────

export function register(client) {
  client.on(Events.MessageCreate, async message => {
    if (message.author.bot) return;

    try {
      // ── DM path ───────────────────────────────────────────────────────────
      if (!message.guild) {

        // Find if this user has a pending onboarding row in any guild
        function findPendingGuildId() {
          for (const [guildId] of client.guilds.cache) {
            const row = getOnboardingRow(message.author.id, guildId);
            if (row && !row.card_provided) return guildId;
          }
          return null;
        }

        // Text trainer ID → linking flow
        const idMatch = message.content.match(TRAINER_ID_RE);
        if (idMatch) {
          const result = await resolveAndLink(message.author.id, idMatch[1]);
          if (result.ok) {
            const pendingGuildId = findPendingGuildId();
            if (pendingGuildId) markCardProvided(message.author.id, pendingGuildId);
            await message.reply(
              `✅ Linked! You are confirmed as **${result.trainerName}** in **${result.circleName}**.\n` +
              `You now have full access to all channels! 🏇`
            ).catch(() => {});
            log.info(`linking: DM text-ID linked ${message.author.tag} → ${result.trainerName} (${result.circleName})`);
          } else {
            await message.reply(
              `❌ Link failed — please look on uma.moe to check if you are detected. ` +
              `If you are not showing up on uma.moe, that is the cause of the issue — cannot link members not detected on uma.moe.`
            ).catch(() => {});
          }
          return;
        }

        // Image → classify and handle
        if (hasImageAttachment(message)) {
          const pendingGuildId = findPendingGuildId();
          if (!pendingGuildId) return;

          const img    = message.attachments.first();
          const result = await classifyUmaImage(img.proxyURL ?? img.url);

          if (result.screen_type === 'profile_ui') {
            await message.reply(
              `❌ That's your **Profile** screen — please send your **Trainer Card** instead!\n\n` +
              `From the Profile screen, tap the **Trainer Card** button (top-right corner) ` +
              `to open your Trainer Card, then screenshot and send that. 🏇`
            ).catch(() => {});
            return;
          }

          if (result.screen_type === 'trainer_card') {
            const clubWarning = checkClubAffiliation(result.club_name);
            if (clubWarning) {
              await message.reply(clubWarning).catch(() => {});
            }

            const targetGuild = client.guilds.cache.get(pendingGuildId) ?? null;
            const forwarded = await forwardTrainerCard(client, message.author, img, targetGuild);
            if (forwarded) {
              markCardProvided(message.author.id, pendingGuildId);

              // Step 1: try link by trainer ID
              let linkResult = { ok: false };
              if (result.trainer_id) {
                linkResult = await resolveAndLink(message.author.id, result.trainer_id);
              }

              // Step 2: try link by trainer name (case-insensitive uma.moe lookup)
              if (!linkResult.ok && result.trainer_name) {
                linkResult = await resolveAndLinkByName(message.author.id, result.trainer_name);
              }

              if (linkResult.ok) {
                await message.reply(
                  `✅ Trainer card received! You are now linked as **${linkResult.trainerName}** in **${linkResult.circleName}**.\n` +
                  `Your card has been shared in **#friend-channel** and you have full channel access! 🏇🌸`
                ).catch(() => {});
                log.info(`onboarding: DM card auto-linked ${message.author.tag} → ${linkResult.trainerName} (${linkResult.circleName})`);
              } else {
                // Step 3: pending — notify owner, set pending status
                if (targetGuild) {
                  const displayName =
                    targetGuild.members.cache.get(message.author.id)?.displayName ??
                    message.author.username;
                  setPendingVerification(message.author.id, pendingGuildId, {
                    trainerId:   result.trainer_id,
                    trainerName: result.trainer_name,
                    cardUrl:     img.proxyURL ?? img.url,
                  });
                  notifyOwnerPending(targetGuild, message.author, {
                    trainerName: result.trainer_name,
                    trainerId:   result.trainer_id,
                    cardUrl:     img.proxyURL ?? img.url,
                    displayName,
                  }).catch(err => log.warn(`notifyOwnerPending error: ${err.message}`));
                }
                await message.reply(
                  `✅ Your trainer card has been shared in **#friend-channel**! 🌸\n\n` +
                  `⏳ Your name could not be automatically matched to a circle member.\n` +
                  `Your application is now **pending review** by the circle leader — ` +
                  `you will be notified once a decision has been made.`
                ).catch(() => {});
                log.info(
                  `onboarding: DM card from ${message.author.tag} → pending ` +
                  `(name: ${result.trainer_name ?? 'n/a'}, id: ${result.trainer_id ?? 'n/a'})`
                );
              }
            }
            return;
          }

          // 'other' or 'unknown' — guide them
          await message.reply(
            `To link your account, please send:\n` +
            `• Your **Trainer ID number** (e.g. \`612 856 830 731\`) — this links your account ✅\n` +
            `• Or your **Trainer Card** screenshot — this will be shared in #friend-channel 🌸`
          ).catch(() => {});
        }

        return;
      }

      // ── Guild path ────────────────────────────────────────────────────────
      const guildCfg = await store.getGuildConfig(message.guild.id);

      // #uma-store: trainer ID paste or text command
      if (message.channelId === guildCfg.umaStoreChannelId) {
        await message.delete().catch(() => {});
        const idMatch = message.content.match(TRAINER_ID_RE) || message.content.match(STORE_CMD_RE);
        if (idMatch) await handleTrainerId(message, idMatch[1]);
        return;
      }

      // #uma-results: only admins may post
      if (message.channelId === guildCfg.umaResultsChannelId && !isAdminMember(message.member)) {
        await message.delete().catch(() => {});
        return;
      }

      // #leaderboard and #announcement: bot-only
      if (
        message.channelId === guildCfg.leaderboardChannelId ||
        message.channelId === guildCfg.announcementChannelId
      ) {
        await message.delete().catch(() => {});
        return;
      }

      // ── New-member linking restriction ─────────────────────────────────────
      if (!isAdminMember(message.member)) {
        const restricted = await isRestrictedNewMember(message.author.id, message.guild.id);

        if (restricted) {
          const friendCh    = await getFriendChannel(message.guild).catch(() => null);
          const isInFriends = friendCh && message.channelId === friendCh.id;

          if (isInFriends) {
            // ── #friends: allow, but process for linking ──────────────────

            // Text trainer ID → link them
            const idMatch = message.content.match(TRAINER_ID_RE);
            if (idMatch) {
              const result = await resolveAndLink(message.author.id, idMatch[1]);
              if (result.ok) {
                markCardProvided(message.author.id, message.guild.id);
                await message.author.send(
                  `✅ Linked! You are confirmed as **${result.trainerName}** in **${result.circleName}**.\n` +
                  `You now have full access to all channels! 🏇`
                ).catch(() => {});
                log.info(`linking: #friends text-ID linked ${message.author.tag} → ${result.trainerName} (${result.circleName})`);
              } else {
                await message.author.send(
                  `❌ Link failed — please look on uma.moe to check if you are detected. ` +
                  `If you are not showing up on uma.moe, that is the cause of the issue — cannot link members not detected on uma.moe.`
                ).catch(() => {});
              }
              // fall through to behaviour log
            }

            // Image → classify (skipped if text ID was already handled above)
            if (!idMatch && hasImageAttachment(message)) {
              const img    = message.attachments.first();
              const result = await classifyUmaImage(img.proxyURL ?? img.url);

              if (result.screen_type === 'profile_ui') {
                await message.delete().catch(() => {});
                await message.author.send(
                  `❌ That's your **Profile** screen — please send your **Trainer Card** instead!\n\n` +
                  `From the Profile screen, tap the **Trainer Card** button (top-right corner) ` +
                  `to open your Trainer Card, then screenshot and send that. 🏇`
                ).catch(() => {});
                return;
              }

              if (result.screen_type === 'trainer_card') {
                const clubWarning = checkClubAffiliation(result.club_name);
                if (clubWarning) {
                  await message.author.send(clubWarning).catch(() => {});
                }

                markCardProvided(message.author.id, message.guild.id);

                // Step 1: try link by trainer ID
                let linkResult = { ok: false };
                if (result.trainer_id) {
                  linkResult = await resolveAndLink(message.author.id, result.trainer_id);
                }

                // Step 2: try link by trainer name (case-insensitive uma.moe lookup)
                if (!linkResult.ok && result.trainer_name) {
                  linkResult = await resolveAndLinkByName(message.author.id, result.trainer_name);
                }

                if (linkResult.ok) {
                  await message.author.send(
                    `✅ Trainer card received! You are now linked as **${linkResult.trainerName}** in **${linkResult.circleName}**.\n` +
                    `You now have full access to all channels! 🏇🌸`
                  ).catch(() => {});
                  log.info(`onboarding: #friends card auto-linked ${message.author.tag} → ${linkResult.trainerName} (${linkResult.circleName})`);
                } else {
                  // Step 3: pending — notify owner, set pending status
                  const displayName = message.member?.displayName ?? message.author.username;
                  const cardImg = message.attachments.first();
                  setPendingVerification(message.author.id, message.guild.id, {
                    trainerId:   result.trainer_id,
                    trainerName: result.trainer_name,
                    cardUrl:     cardImg?.proxyURL ?? cardImg?.url,
                  });
                  notifyOwnerPending(message.guild, message.author, {
                    trainerName: result.trainer_name,
                    trainerId:   result.trainer_id,
                    cardUrl:     cardImg?.proxyURL ?? cardImg?.url,
                    displayName,
                  }).catch(err => log.warn(`notifyOwnerPending error: ${err.message}`));
                  await message.author.send(
                    `✅ Your trainer card has been shared in **#friend-channel**! 🌸\n\n` +
                    `⏳ Your name could not be automatically matched to a circle member.\n` +
                    `Your application is now **pending review** by the circle leader — ` +
                    `you will be notified once a decision has been made.`
                  ).catch(() => {});
                  log.info(
                    `onboarding: #friends card from ${message.author.tag} → pending ` +
                    `(name: ${result.trainer_name ?? 'n/a'}, id: ${result.trainer_id ?? 'n/a'})`
                  );
                }
                // fall through to media notification / behaviour log
              }
              // 'other' or 'unknown' — let it pass silently
            }

          } else {
            // ── Any other channel — delete and DM the member ──────────────
            await message.delete().catch(() => {});
            await message.author.send(
              `🔒 You need to link your account before posting in other channels.\n\n` +
              `Post your **Trainer ID number** (e.g. \`612 856 830 731\`) in ` +
              `${friendCh ? `<#${friendCh.id}>` : '**#friend-channel**'} ` +
              `or DM me directly to get linked! 🏇`
            ).catch(() => {});
            return;
          }
        }
      }

      // ── Regular message processing ────────────────────────────────────────

      // Media post notification
      if (hasImageAttachment(message)) {
        await notifyMediaPost(message);
      }

      // Behaviour log
      const isReply     = !!message.reference;
      const displayName = message.member?.displayName ?? message.author.username;
      const action      = isReply ? 'replied in' : 'posted in';
      sendBehaviour(
        message.guild,
        `💬 **${displayName}** ${action} #${message.channel.name} · ${jstTime()}`
      ).catch(() => {});

      // Hype reaction
      maybeHypeReaction(message).catch(() => {});

    } catch (err) {
      log.warn('messageCreate handler error:', err.message);
    }
  });

  // ── Message delete ──────────────────────────────────────────────────────────
  client.on(Events.MessageDelete, async message => {
    if (!message.guild || message.author?.bot) return;
    try {
      const displayName = message.member?.displayName ?? message.author?.username ?? 'Unknown';
      await sendBehaviour(
        message.guild,
        `🗑️ **${displayName}** deleted a message in #${message.channel?.name ?? 'unknown'} · ${jstTime()}`
      );
    } catch { /* silent */ }
  });

  // ── Message edit ────────────────────────────────────────────────────────────
  client.on(Events.MessageUpdate, async (oldMessage, newMessage) => {
    if (!newMessage.guild || newMessage.author?.bot) return;
    if (oldMessage.content === newMessage.content) return;
    try {
      const displayName = newMessage.member?.displayName ?? newMessage.author?.username ?? 'Unknown';
      await sendBehaviour(
        newMessage.guild,
        `✏️ **${displayName}** edited a message in #${newMessage.channel?.name ?? 'unknown'} · ${jstTime()}`
      );
    } catch { /* silent */ }
  });

  // ── Reaction add ────────────────────────────────────────────────────────────
  client.on(Events.MessageReactionAdd, async (reaction, user) => {
    if (user.bot) return;
    try {
      if (reaction.partial) await reaction.fetch().catch(() => {});
      if (!reaction.message.guild) return;
      const guild       = reaction.message.guild;
      const member      = await guild.members.fetch(user.id).catch(() => null);
      const displayName = member?.displayName ?? user.username ?? 'Unknown';
      const emoji       = reaction.emoji.id
        ? `<:${reaction.emoji.name}:${reaction.emoji.id}>`
        : reaction.emoji.name;
      await sendBehaviour(
        guild,
        `👍 **${displayName}** reacted ${emoji} in #${reaction.message.channel?.name ?? 'unknown'} · ${jstTime()}`
      );
    } catch { /* silent */ }
  });
}
