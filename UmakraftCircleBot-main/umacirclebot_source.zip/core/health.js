// @ts-check
/**
 * health.js
 * ─────────
 * Minimal HTTP health-check server.
 *
 * Railway pings /health to verify the service is alive.
 * Replit uses port 8080 as the external preview port — this satisfies both.
 *
 * If the primary port is already in use (e.g. Replit occupies 8080),
 * the server automatically falls back to the next available port.
 *
 * Endpoints:
 *   GET /          → 200 full status payload
 *   GET /health    → 200 full status payload
 *   GET /ready     → 200 if bot is logged in, 503 otherwise
 */
import http from 'node:http';
import { log } from './log.js';
import { timelineStatus } from '../timeline/timeline.js';
import { getState } from '../db/timelineCache.js';
import { syncStatus } from '../tasks/dataSync.js';
import { getTaskStats, getRegisteredCount } from './taskRegistry.js';
import { getConfiguredCircles } from './config.js';

/** @type {import('discord.js').Client | null} */
let botClient = null;

/**
 * Create and start the health HTTP server.
 * Tries each port in PORTS_TO_TRY in order; stops at the first that binds.
 * @param {import('discord.js').Client} client
 */
export function startHealthServer(client) {
  botClient = client;

  const primaryPort = parseInt(process.env.PORT || process.env.HEALTH_PORT || '8080', 10);
  const PORTS_TO_TRY = [primaryPort, 8081, 3000].filter((p, i, arr) => arr.indexOf(p) === i);

  function requestHandler(req, res) {
    const online = botClient?.isReady() ?? false;

    if (req.url === '/ready') {
      res.writeHead(online ? 200 : 503, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ready: online }));
      return;
    }

    const lastUpdate = getState('last_update');
    const lastError = getState('last_error');
    const mem = process.memoryUsage();

    const payload = {
      status: online ? 'ok' : 'starting',
      bot_online: online,
      bot_tag: botClient?.user?.tag ?? null,
      active_circles: getConfiguredCircles().length,
      data_sync: {
        last_sync_at: syncStatus.lastSyncAt,
        last_sync_circle_id: syncStatus.lastSyncCircleId,
        last_sync_error: syncStatus.lastSyncError,
        consecutive_failures: syncStatus.consecutiveFailures,
      },
      timeline: {
        last_update_at: lastUpdate ?? timelineStatus.lastUpdateAt,
        last_error: lastError ?? timelineStatus.lastError,
        total_posted: timelineStatus.totalPosted,
        is_running: timelineStatus.isRunning,
      },
      tasks: {
        registered: getRegisteredCount(),
        stats: getTaskStats(),
      },
      memory: {
        heap_used_mb: Math.round(mem.heapUsed / 1024 / 1024),
        heap_total_mb: Math.round(mem.heapTotal / 1024 / 1024),
        rss_mb: Math.round(mem.rss / 1024 / 1024),
      },
      uptime_seconds: Math.floor(process.uptime()),
      timestamp: new Date().toISOString(),
    };

    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(payload, null, 2));
  }

  function tryBind(index) {
    if (index >= PORTS_TO_TRY.length) {
      log.warn('[Health] No available port found — health server disabled');
      return;
    }

    const port = PORTS_TO_TRY[index];
    const server = http.createServer(requestHandler);

    server.once('error', err => {
      if (err.code === 'EADDRINUSE') {
        log.warn(`[Health] Port ${port} in use — trying next port`);
        tryBind(index + 1);
      } else {
        log.warn(`[Health] Health server error on port ${port}: ${err.message}`);
      }
    });

    server.listen(port, '0.0.0.0', () => {
      log.info(`[Health] Health server listening on port ${port} → GET /health`);
    });
  }

  tryBind(0);
}
