import { config } from './config.js';
import { log } from './log.js';
import { store } from './store.js';

const API_BASE = 'https://uma.moe/api/v4';
const API_BASE_V3 = 'https://uma.moe/api/v3';

// If a new member's first-day delta exceeds this it is almost certainly a
// pre-existing fan count being recorded for the first time, not real daily gain.
const SPIKE_THRESHOLD = 30_000_000;

// How long the in-memory snapshot cache is considered fresh.
// Commands always read from the cache; only dataSync refreshes it.
const SNAPSHOT_TTL_MS = 25 * 60 * 1000; // 25 minutes

// ─── Rate-limit-aware fetch ──────────────────────────────────────────────────

/**
 * Fetch with exponential-backoff retry on 429 / 5xx.
 * Waits: 5s, 15s, 45s between attempts (or Retry-After header value for 429s).
 */
async function fetchWithRetry(url, opts, attempt = 0) {
  const res = await fetch(url, opts);
  if (res.status === 429 || res.status >= 500) {
    const delays = [5_000, 15_000, 45_000];
    if (attempt < delays.length) {
      let wait = delays[attempt];
      if (res.status === 429) {
        const retryAfter = res.headers.get('retry-after');
        if (retryAfter) {
          const parsed = parseInt(retryAfter, 10);
          if (!isNaN(parsed)) wait = Math.max(wait, parsed * 1_000);
        }
      }
      log.warn(`uma.moe ${res.status} — retrying in ${wait / 1000}s (attempt ${attempt + 1})`);
      await new Promise(r => setTimeout(r, wait));
      return fetchWithRetry(url, opts, attempt + 1);
    }
    throw new Error(`uma.moe API ${res.status}: ${res.statusText} (after retries)`);
  }
  if (!res.ok) {
    throw new Error(`uma.moe API ${res.status}: ${res.statusText}`);
  }
  return res.json();
}

const UMA_HEADERS = {
  Accept: 'application/json',
  'User-Agent': 'UmaCircleBot/1.0 (+https://github.com/Falco-chan)',
};

/**
 * Low-level search helper.
 *
 * Queries /api/v3/search with the given trainer_id and optional search_type.
 * Returns the raw API item ONLY when the returned account_id is an exact match
 * for the requested id — prevents wrong-trainer results from general searches.
 *
 * Returns null when:
 *   - the API is unreachable / returns an error
 *   - no items are returned
 *   - the first item's account_id does not match
 */
async function searchTrainerId(id, searchType) {
  const params = new URLSearchParams({
    page: '0',
    limit: '1',
    trainer_id: id,
    sort_by: 'affinity_score',
    sort_order: 'desc',
    max_follower_num: '999',
  });
  if (searchType) params.set('search_type', searchType);

  try {
    const res = await fetch(`${API_BASE_V3}/search?${params.toString()}`, { headers: UMA_HEADERS });
    if (res.status === 404) return null;
    if (!res.ok) throw new Error(`search API ${res.status}`);

    const data = await res.json();
    const items = data?.items;
    if (!Array.isArray(items) || items.length === 0) return null;

    const item = items[0];
    // Strict equality — the API sometimes returns an unrelated top result
    // when the trainer_id filter has no matches.
    if (String(item.account_id) !== String(id)) return null;

    return item;
  } catch (err) {
    log.warn(`searchTrainerId(${id}, ${searchType}): ${err.message}`);
    return null;
  }
}

/**
 * Fetch a trainer's full profile from uma.moe by their viewer/account ID.
 *
 * Strategy (two-pass):
 *   1. Try search_type=inheritance — returns full inheritance build data.
 *   2. If empty, retry without search_type — finds trainers who exist on
 *      uma.moe but have not yet set up an inheritance build.
 *
 * Returns null if the trainer is not registered on uma.moe at all.
 *
 * Returned shape:
 *   {
 *     trainer_id, trainer_name,
 *     affinity, white_count, win_count, parent_rank, parent_rarity,
 *     main_parent_id, parent_left_id, parent_right_id,
 *     blue_sparks, pink_sparks, green_sparks, white_sparks,
 *     blue_stars, pink_stars, green_stars, white_stars,
 *     rank_score, team_class, team_evaluation_point, comment,
 *     leader_char_id, trophy
 *   }
 */
export async function fetchTrainerProfile(trainerId) {
  const id = String(trainerId).replace(/\s+/g, '');

  // Pass 1: with inheritance filter (full build data)
  let item = await searchTrainerId(id, 'inheritance');

  // Pass 2: fallback — trainer exists but has no inheritance build
  if (!item) {
    log.debug(`fetchTrainerProfile(${id}): inheritance pass empty, trying plain search`);
    item = await searchTrainerId(id, null);
  }

  if (!item) return null;

  const inh = item.inheritance ?? {};

  return {
    trainer_id: item.account_id ?? id,
    trainer_name: item.trainer_name ?? null,

    // Inherited build stats (null/empty when trainer has no inheritance build)
    affinity: inh.affinity_score ?? null,
    white_count: inh.white_count ?? null,
    win_count: inh.win_count ?? null,
    parent_rank: inh.parent_rank ?? null,
    parent_rarity: inh.parent_rarity ?? null,

    main_parent_id: inh.main_parent_id ? Math.floor(inh.main_parent_id / 100) : null,
    parent_left_id: inh.parent_left_id ? Math.floor(inh.parent_left_id / 100) : null,
    parent_right_id: inh.parent_right_id ? Math.floor(inh.parent_right_id / 100) : null,

    blue_sparks: inh.blue_sparks ?? [],
    pink_sparks: inh.pink_sparks ?? [],
    green_sparks: inh.green_sparks ?? [],
    white_sparks: inh.white_sparks ?? [],

    blue_stars: inh.blue_stars_sum ?? 0,
    pink_stars: inh.pink_stars_sum ?? 0,
    green_stars: inh.green_stars_sum ?? 0,
    white_stars: inh.white_stars_sum ?? 0,

    // Extra fields (may not be present in all results)
    rank_score: item.rank_score ?? null,
    team_class: item.team_class ?? null,
    team_evaluation_point: item.team_evaluation_point ?? null,
    comment: item.comment ?? null,
    leader_char_id: item.leader_chara_dress_id
      ? Math.floor(item.leader_chara_dress_id / 100)
      : null,
    trophy: {
      g1: item.trophy?.g1 ?? 0,
      g2: item.trophy?.g2 ?? 0,
      g3: item.trophy?.g3 ?? 0,
      ex: item.trophy?.ex ?? 0,
    },
  };
}

export async function fetchCircle(circleId = config.circleId, year, month) {
  const params = new URLSearchParams({ circle_id: String(circleId) });
  if (year != null) params.set('year', String(year));
  if (month != null) params.set('month', String(month));
  const url = `${API_BASE}/circles?${params.toString()}`;
  return fetchWithRetry(url, {
    headers: {
      Accept: 'application/json',
      'User-Agent': 'UmaCircleBot/1.0 (+https://github.com/Falco-chan)',
    },
  });
}

// ─── Member classification ───────────────────────────────────────────────────

/**
 * Classify which members are currently in the circle vs. those who left.
 * Members who are still active keep having their daily_fans updated;
 * those who left have their array frozen on the day they left.
 */
export function classifyMembers(payload, today = new Date()) {
  const members = payload?.members ?? [];
  const isCurrentMonth =
    members.length > 0 &&
    members[0].year === today.getUTCFullYear() &&
    members[0].month === today.getUTCMonth() + 1;

  let latestIdx = 0;
  for (const m of members) {
    for (let i = m.daily_fans.length - 1; i >= 0; i--) {
      if (m.daily_fans[i] > 0) {
        if (i > latestIdx) latestIdx = i;
        break;
      }
    }
  }

  return members.map(m => {
    const fans = m.daily_fans;
    const lastValue = fans[latestIdx] || 0;
    const prevValue = latestIdx > 0 ? fans[latestIdx - 1] : 0;

    // Consider a member's last_updated "recent" if it falls within the current
    // calendar month — this handles members who simply had a 0-gain day and
    // whose last_updated timestamp is therefore older than 36 hours.
    const lastUpdatedDate = m.last_updated ? new Date(m.last_updated) : null;
    const updatedThisMonth =
      lastUpdatedDate != null &&
      lastUpdatedDate.getUTCFullYear() === today.getUTCFullYear() &&
      lastUpdatedDate.getUTCMonth() === today.getUTCMonth();

    let active;
    if (!isCurrentMonth) {
      active = lastValue > 0;
    } else if (lastValue === 0) {
      active = false;
    } else if (lastValue > prevValue) {
      active = true;
    } else if (updatedThisMonth) {
      active = true;
    } else {
      active = false;
    }

    let firstNonZeroIdx = -1;
    for (let i = 0; i < fans.length; i++) {
      if (fans[i] > 0) {
        firstNonZeroIdx = i;
        break;
      }
    }

    return {
      trainerId: String(m.viewer_id),
      trainerName: m.trainer_name,
      year: m.year,
      month: m.month,
      dailyFans: fans,
      lastUpdated: m.last_updated,
      active,
      latestIdx,
      latestValue: lastValue,
      firstNonZeroIdx,
    };
  });
}

// ─── Stat computation ────────────────────────────────────────────────────────

/**
 * Compute per-member contribution stats.
 *
 * Rules applied:
 *  1. Join-day gain is always zero.
 *  2. Any day where fans jump from 0 by > 30M is treated as a registration
 *     spike and zeroed (handles members who had fans before the bot started).
 *  3. Weekly gain = calendar week (Mon 00:00 UTC → today).
 *  4. Monthly gain = day 1 → today.
 */
export function computeMemberStats(member, opts = {}) {
  const { previousMonthFinal = null, joinedAtIso = null, today = new Date() } = opts;
  // Normalize: uma.moe occasionally emits negative cumulative values (a known
  // data artifact). Clamp every slot to 0 before any delta math so phantom
  // gains cannot appear from a negative → zero transition.
  const fans = member.dailyFans.map(v => Math.max(0, v ?? 0));

  const todayIdx = Math.min(fans.length - 1, today.getUTCDate() - 1);
  // If uma.moe hasn't synced today's slot yet, fall back to the most recent
  // day that actually has data so gains aren't falsely shown as 0.
  const effectiveTodayIdx = Math.min(todayIdx, member.latestIdx);

  // Build day-over-day deltas.
  const deltas = [];
  for (let i = 0; i <= member.latestIdx; i++) {
    if (i === 0) {
      const prev = previousMonthFinal != null ? Math.max(0, previousMonthFinal) : fans[0];
      deltas.push(Math.max(0, fans[0] - prev));
    } else {
      deltas.push(Math.max(0, fans[i] - fans[i - 1]));
    }
  }

  // Resolve join index within this month.
  let joinIdx = -1;
  if (joinedAtIso) {
    const joined = new Date(joinedAtIso);
    if (joined.getUTCFullYear() === member.year && joined.getUTCMonth() + 1 === member.month) {
      joinIdx = joined.getUTCDate() - 1;
    }
  }

  // Zero join day and any registration spikes.
  //
  // Spike rule 1 (existing): if the previous cumulative total was 0 and the
  //   delta is huge, uma.moe just recorded the member's lifetime fans as a
  //   single jump — zero it.
  //
  // Spike rule 2 (new): the day AFTER the join day is also vulnerable.
  //   uma.moe sometimes records a small value on join day itself, then the full
  //   historical fan count appears on day 2 — fans[joinDay] is non-zero so rule
  //   1 misses it, but the jump is still a registration artifact.  Zero any
  //   delta > SPIKE_THRESHOLD whose immediately-preceding day was the join day.
  for (let i = 0; i < deltas.length; i++) {
    const isJoinDay = i === joinIdx;
    const isPrevZero =
      i === 0 ? previousMonthFinal === null || previousMonthFinal === 0 : fans[i - 1] === 0;
    const isPrevJoinDay = joinIdx >= 0 && i === joinIdx + 1;
    const isSpike = (isPrevZero || isPrevJoinDay) && deltas[i] > SPIKE_THRESHOLD;
    if (isJoinDay || isSpike) deltas[i] = 0;
  }

  // For members who joined this month, only count gains from their join date
  // onwards — pre-join gains belong to a previous circle and must not inflate
  // monthly totals, milestone thresholds, or leaderboard rankings.
  const gainStartIdx = joinIdx >= 0 ? joinIdx : 0;

  // Calendar-week gain (Mon → today, clamped to join date or start of month).
  const daysSinceMon = (today.getUTCDay() + 6) % 7;
  const weekStartIdx = Math.max(gainStartIdx, today.getUTCDate() - daysSinceMon - 1);
  let weeklyGain = 0;
  for (let i = weekStartIdx; i <= todayIdx; i++) weeklyGain += deltas[i] ?? 0;

  // Monthly gain (from join date or day 1 → today).
  let monthlyGain = 0;
  for (let i = gainStartIdx; i <= todayIdx; i++) monthlyGain += deltas[i] ?? 0;

  // ── Status flags ────────────────────────────────────────────────────────────
  // hasData: member has at least one non-zero cumulative total this month.
  const hasData = fans.some(v => v > 0);

  // joinDay: today is this member's join date (gain is intentionally 0).
  let joinDay = false;
  if (joinedAtIso) {
    const j = new Date(joinedAtIso);
    joinDay =
      j.getUTCFullYear() === today.getUTCFullYear() &&
      j.getUTCMonth() === today.getUTCMonth() &&
      j.getUTCDate() === today.getUTCDate();
  }

  // Infer join day for brand-new members whose joinedAt hasn't been stored yet:
  // if every fan slot before today is zero but today's slot has data, they
  // literally just appeared today and should be treated as a join-day member.
  if (!joinDay && !joinedAtIso) {
    const hasDataBeforeToday = fans.slice(0, effectiveTodayIdx).some(v => v > 0);
    if (!hasDataBeforeToday && fans[effectiveTodayIdx] > 0) {
      joinDay = true;
    }
  }

  return {
    deltas,
    todayGain: deltas[effectiveTodayIdx] ?? 0,
    yesterdayGain: effectiveTodayIdx >= 1 ? (deltas[effectiveTodayIdx - 1] ?? 0) : 0,
    weeklyGain,
    monthlyGain,
    totalLifetimeFans: fans[member.latestIdx] || 0,
    hasData,
    joinDay,
  };
}

// ─── In-memory snapshot cache (per circle) ───────────────────────────────────

// Map<circleId, { snapshot, cachedAt }>
const snapshotCaches = new Map();

// In-flight guard: prevents parallel cold-start calls from firing duplicate
// buildSnapshot() API requests for the same circle.
// Map<circleId, Promise<snapshot>>
const buildInFlight = new Map();

/**
 * Called by dataSync after every successful API pull.
 * Keyed by circleId so multiple circles never overwrite each other.
 */
export function setCachedSnapshot(circleId, snapshot) {
  snapshotCaches.set(String(circleId), { snapshot, cachedAt: Date.now() });
}

/**
 * Return the cached snapshot for the given circle. If the cache is empty or
 * stale AND we have nothing at all, makes one live API call.
 *
 * Commands should always read from the cache and never trigger API calls.
 */
export async function getCircleSnapshot(circleId = config.circleId) {
  const key = String(circleId);
  const cached = snapshotCaches.get(key) || { snapshot: null, cachedAt: 0 };

  // Fresh cache — serve it.
  if (cached.snapshot && Date.now() - cached.cachedAt < SNAPSHOT_TTL_MS) {
    return cached.snapshot;
  }

  // Stale but not empty — serve the stale data rather than risk a 429.
  if (cached.snapshot) {
    log.debug(`getCircleSnapshot(${circleId}): serving stale cache (sync pending)`);
    return cached.snapshot;
  }

  // Cache is completely empty (first boot before the first sync completes).
  // Guard against parallel cold-start callers all firing buildSnapshot at once:
  // if one is already in progress, return the same promise instead of starting a new one.
  if (buildInFlight.has(key)) {
    log.debug(`getCircleSnapshot(${circleId}): joining in-flight cold-start build`);
    return buildInFlight.get(key);
  }

  log.debug(`getCircleSnapshot(${circleId}): cold start — fetching live`);
  const promise = buildSnapshot(circleId).finally(() => buildInFlight.delete(key));
  buildInFlight.set(key, promise);
  return promise;
}

/**
 * Build a full snapshot object from the API (called by dataSync and on cold start).
 * Also updates the in-memory cache keyed by circleId.
 */
export async function buildSnapshot(circleId = config.circleId) {
  const today = new Date();
  const payload = await fetchCircle(circleId);
  const classified = classifyMembers(payload, today);
  const prevValues = await getPreviousMonthFinals(circleId, today);

  const enriched = await Promise.all(
    classified.map(async m => {
      // Pass circleId so join dates are read from the correct circle's table.
      const joinedAt = await getStoredJoinedAt(m.trainerId, circleId);
      const stats = computeMemberStats(m, {
        previousMonthFinal: prevValues[m.trainerId] ?? null,
        joinedAtIso: joinedAt,
        today,
      });
      return { ...m, ...stats, joinedAt };
    })
  );

  const active = enriched.filter(m => m.active);
  const left = enriched.filter(m => !m.active);

  // tallyStarted: at least one active member has recorded fans this month.
  // When false, all gain values are structurally 0 — no real data yet.
  const tallyStarted = active.some(m => m.hasData);

  const snapshot = {
    circle: payload.circle,
    members: active,
    allMembers: enriched,
    leftMembers: left,
    rawClassified: classified,
    todayDay: today.getUTCDate(),
    latestIdx: classified.reduce((acc, m) => Math.max(acc, m.latestIdx), 0),
    tallyStarted,
  };

  setCachedSnapshot(circleId, snapshot);
  return snapshot;
}

// ─── Historical join-date finder ─────────────────────────────────────────────

// Shared cache for historical month payloads within a single sync run.
const historicalMonthCache = new Map();

const MAX_LOOKBACK = 6;

/**
 * Walk backwards through monthly API data to find the earliest month
 * `trainerId` appears in. Returns an ISO date string, or null.
 *
 * Uses a shared in-process cache so that multiple new members discovered in
 * the same sync run don't re-fetch the same historical months.
 */
export async function findEarliestJoinDate(
  trainerId,
  currentYear,
  currentMonth,
  circleId = config.circleId
) {
  // Build the list of months to examine (most recent first)
  const months = [];
  let year = currentYear;
  let month = currentMonth;
  for (let i = 0; i < MAX_LOOKBACK; i++) {
    month -= 1;
    if (month === 0) { month = 12; year -= 1; }
    months.push({ year, month });
  }

  // Fetch all uncached months in parallel — reduces worst-case 3 s serial wait
  // to a single round-trip. Already-cached months are skipped for free.
  await Promise.all(months.map(async ({ year, month }) => {
    const cacheKey = `${circleId}:${year}-${month}`;
    if (historicalMonthCache.has(cacheKey)) return;
    try {
      const payload = await fetchCircle(circleId, year, month);
      historicalMonthCache.set(cacheKey, payload);
    } catch (err) {
      log.debug(`findEarliestJoinDate: prefetch ${year}-${month}: ${err.message}`);
    }
  }));

  // Walk months in order, stopping as soon as the member is absent
  let earliest = null;
  for (const { year, month } of months) {
    const cacheKey = `${circleId}:${year}-${month}`;
    const payload = historicalMonthCache.get(cacheKey);
    if (!payload) break;

    const found = (payload.members ?? []).find(m => String(m.viewer_id) === String(trainerId));
    if (!found) break; // Not in this month — they joined after this point.

    const fans = found.daily_fans || [];
    let firstDay = 1;
    for (let d = 0; d < fans.length; d++) {
      if (fans[d] > 0) { firstDay = d + 1; break; }
    }
    earliest = new Date(Date.UTC(year, month - 1, firstDay)).toISOString();
  }

  return earliest;
}

/** Clear the historical month cache after a sync run. */
export function clearHistoricalCache() {
  historicalMonthCache.clear();
}

// ─── Previous-month finals cache ─────────────────────────────────────────────

// Map<`${circleId}:${year}-${month}`, {expires, data}> — one entry per circle
// so parallel syncs for different circles don't evict each other's cached data.
const prevMonthCache = new Map();

export async function getPreviousMonthFinals(circleId, today) {
  let year = today.getUTCFullYear();
  let month = today.getUTCMonth(); // 0-indexed today → last month in 1-indexed terms
  if (month === 0) {
    year -= 1;
    month = 12;
  }

  const key = `${circleId}:${year}-${month}`;
  // Fixed: Map lookup so each circle has its own cache slot.
  const cached = prevMonthCache.get(key);
  if (cached && Date.now() < cached.expires) return cached.data;
  try {
    const payload = await fetchCircle(circleId, year, month);
    const out = {};
    for (const m of payload.members ?? []) {
      const fans = m.daily_fans || [];
      for (let i = fans.length - 1; i >= 0; i--) {
        if (fans[i] > 0) {
          out[String(m.viewer_id)] = fans[i];
          break;
        }
      }
    }
    prevMonthCache.set(key, { expires: Date.now() + 60 * 60 * 1000, data: out });
    return out;
  } catch (err) {
    log.warn('Could not fetch previous month finals:', err.message);
    return {};
  }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

// Fixed: accept circleId and read from the correct circle's members table.
// Previously called store.getMembers() which always returned Circle 1,
// causing Circle 2 join dates to resolve as null.
async function getStoredJoinedAt(trainerId, circleId) {
  const members = await store.getMembersForCircle(circleId);
  return members[trainerId]?.joinedAt || null;
}
