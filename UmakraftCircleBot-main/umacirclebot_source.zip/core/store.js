// @ts-check
/**
 * store.js
 * ────────
 * Public persistence API for the bot.
 *
 * All storage is now backed by SQLite via db/storeDb.js.
 * The public interface is unchanged — every caller continues to work as-is.
 *
 * Initialization: store.init() calls initStoreDb() which creates the tables
 * and automatically imports any existing JSON flat-files on first boot.
 */
import { config } from './config.js';
import {
  initStoreDb,
  getMembers,
  upsertMember,
  setMembers,
  storeDailyGain,
  getDailyGainsForDate,
  getMemberDailyGains as dbGetMemberDailyGains,
  pruneDailyGains,
  getGuildConfig,
  setGuildConfig,
  getAllGuildConfigs,
  getBotState,
  setBotState,
  getTimezone,
  setTimezone,
  recordCommandMessage as dbRecordCommandMessage,
  takeCommandMessagesOlderThan as dbTakeCommandMessages,
} from '../db/storeDb.js';
import {
  setLink as dbSetLink,
  removeLink as dbRemoveLink,
  getLinkedViewerId as dbGetViewerId,
  getAllLinks as dbGetAllLinks,
  isLinksDbInitialized,
} from '../db/linksDb.js';

export const store = {
  async init() {
    initStoreDb();
  },

  // ── Members ─────────────────────────────────────────────────────────────────

  /**
   * @deprecated Circle-1 only shortcut. For multi-circle code use getMembersForCircle(circleId).
   * @returns {Promise<Record<string, object>>}
   */
  async getMembers() {
    return getMembers(config.circleId);
  },

  /**
   * @deprecated Circle-1 only shortcut. For multi-circle code use upsertMemberForCircle(circleId, ...).
   * @param {string} trainerId
   * @param {object} patch
   * @returns {Promise<object>}
   */
  async upsertMember(trainerId, patch) {
    return upsertMember(config.circleId, trainerId, patch);
  },

  /**
   * @deprecated Circle-1 only shortcut. For multi-circle code use setMembersForCircle(circleId, ...).
   * @param {Record<string, object>} map
   */
  async setMembers(map) {
    setMembers(config.circleId, map);
  },

  // ── Circle-scoped members ───────────────────────────────────────────────────

  /** @param {string} circleId @returns {Promise<Record<string, object>>} */
  async getMembersForCircle(circleId) {
    return getMembers(circleId);
  },

  /**
   * @param {string} circleId
   * @param {string} trainerId
   * @param {object} patch
   */
  async upsertMemberForCircle(circleId, trainerId, patch) {
    return upsertMember(circleId, trainerId, patch);
  },

  /** @param {string} circleId @param {Record<string, object>} map */
  async setMembersForCircle(circleId, map) {
    setMembers(circleId, map);
  },

  // ── Daily gain records ──────────────────────────────────────────────────────

  /**
   * @param {string} trainerId
   * @param {string} dateStr  YYYY-MM-DD
   * @param {number} gain
   * @param {number} totalFans
   */
  /**
   * @deprecated Circle-1 only shortcut. For multi-circle code use storeDailyGainForCircle(circleId, ...).
   * @param {string} trainerId
   * @param {string} dateStr
   * @param {number} gain
   * @param {number} totalFans
   */
  async storeDailyGain(trainerId, dateStr, gain, totalFans) {
    storeDailyGain(config.circleId, trainerId, dateStr, gain, totalFans);
  },

  /**
   * @deprecated Circle-1 only shortcut. For multi-circle code use getDailyGainsForDateForCircle(circleId, ...).
   * @param {string} dateStr @returns {Promise<object[]>}
   */
  async getDailyGainsForDate(dateStr) {
    return getDailyGainsForDate(config.circleId, dateStr);
  },

  /**
   * @deprecated Circle-1 only shortcut. For multi-circle code use store directly via db/storeDb.js getMemberDailyGains(circleId, ...).
   * @param {string} trainerId
   * @param {string | null} [fromDate]
   * @param {string | null} [toDate]
   * @returns {Promise<object[]>}
   */
  async getMemberDailyGains(trainerId, fromDate = null, toDate = null) {
    return dbGetMemberDailyGains(config.circleId, trainerId, fromDate, toDate);
  },

  /**
   * @deprecated Circle-1 only shortcut. For multi-circle code use pruneDailyGainsForCircle(circleId, ...).
   * @param {number} [retentionDays]
   */
  async pruneDailyGains(retentionDays = 90) {
    pruneDailyGains(config.circleId, retentionDays);
  },

  // ── Circle-scoped daily gains ───────────────────────────────────────────────

  /**
   * @param {string} circleId
   * @param {string} trainerId
   * @param {string} dateStr
   * @param {number} gain
   * @param {number} totalFans
   */
  async storeDailyGainForCircle(circleId, trainerId, dateStr, gain, totalFans) {
    storeDailyGain(circleId, trainerId, dateStr, gain, totalFans);
  },

  /** @param {string} circleId @param {string} dateStr @returns {Promise<object[]>} */
  async getDailyGainsForDateForCircle(circleId, dateStr) {
    return getDailyGainsForDate(circleId, dateStr);
  },

  /** @param {string} circleId @param {number} [retentionDays] */
  async pruneDailyGainsForCircle(circleId, retentionDays = 90) {
    pruneDailyGains(circleId, retentionDays);
  },

  // ── Discord ↔ Uma links (backed by linksDb) ─────────────────────────────────

  /** @returns {Promise<Record<string, string>>} */
  async getLinks() {
    if (isLinksDbInitialized()) return dbGetAllLinks();
    return {};
  },

  /**
   * @param {string} discordUserId
   * @param {string} trainerId
   */
  async setLink(discordUserId, trainerId) {
    if (isLinksDbInitialized()) dbSetLink(discordUserId, trainerId);
  },

  /** @param {string} discordUserId */
  async removeLink(discordUserId) {
    if (isLinksDbInitialized()) dbRemoveLink(discordUserId);
  },

  /**
   * @param {string} discordUserId
   * @returns {Promise<string | null>}
   */
  async getLinkedViewerId(discordUserId) {
    if (isLinksDbInitialized()) return dbGetViewerId(discordUserId);
    return null;
  },

  // ── Guild config ─────────────────────────────────────────────────────────────

  /** @param {string} guildId @returns {Promise<object>} */
  async getGuildConfig(guildId) {
    return getGuildConfig(guildId);
  },

  /**
   * @param {string} guildId
   * @param {object} patch
   * @returns {Promise<object>}
   */
  async setGuildConfig(guildId, patch) {
    return setGuildConfig(guildId, patch);
  },

  /** @returns {Promise<Record<string, object>>} */
  async getAllGuildConfigs() {
    return getAllGuildConfigs();
  },

  // ── Generic state ─────────────────────────────────────────────────────────────

  /**
   * @template T
   * @param {string} key
   * @param {T} [defaultValue]
   * @returns {Promise<T>}
   */
  async getState(key, defaultValue = null) {
    return getBotState(key, defaultValue);
  },

  /**
   * @param {string} key
   * @param {*} value
   */
  async setState(key, value) {
    setBotState(key, value);
  },

  // ── Timezones ─────────────────────────────────────────────────────────────────

  /** @param {string} discordId @returns {Promise<string | null>} */
  async getTimezone(discordId) {
    return getTimezone(discordId);
  },

  /** @param {string} discordId @param {string} tz */
  async setTimezone(discordId, tz) {
    setTimezone(discordId, tz);
  },

  // ── Command messages (for 24h cleanup) ───────────────────────────────────────

  /** @param {{ channelId: string, messageId: string }} entry */
  async recordCommandMessage(entry) {
    dbRecordCommandMessage(entry.channelId, entry.messageId);
  },

  /** @param {number} ageMs @returns {Promise<object[]>} */
  async takeCommandMessagesOlderThan(ageMs) {
    return dbTakeCommandMessages(ageMs);
  },
};
