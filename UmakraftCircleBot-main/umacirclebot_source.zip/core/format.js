const NUMBER_FMT = new Intl.NumberFormat('en-US');

const JST_TZ = 'Asia/Tokyo';

/** Returns the current date in JST as YYYY-MM-DD */
export function jstDate() {
  return new Date().toLocaleDateString('en-CA', { timeZone: JST_TZ });
}

/** Returns the current time in JST as "Mon DD, HH:MM JST" */
export function jstTime() {
  return (
    new Date().toLocaleString('en-US', {
      timeZone: JST_TZ,
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    }) + ' JST'
  );
}

export function formatNumber(n) {
  return NUMBER_FMT.format(Math.round(n || 0));
}

export function formatRank(rank) {
  if (rank == null) return '–';
  return `#${rank}`;
}

export function formatDateLong(date = new Date()) {
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    timeZone: 'UTC',
  });
}

export function formatDateShort(date = new Date()) {
  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    timeZone: 'UTC',
  });
}

/**
 * Format a fan-gain value with proper status labels.
 *
 * @param {number} value  - The raw gain number.
 * @param {object} member - Member object with `hasData` and `joinDay` booleans.
 * @param {boolean} tallyStarted - Whether any member has data this month.
 * @param {'daily'|'weekly'|'monthly'} scope - Which gain window this is for.
 */
export function formatGain(value, member, tallyStarted, scope = 'any') {
  if (!tallyStarted) return 'Not Started';
  if (!member.hasData) return 'No Data Yet';
  if (member.joinDay) {
    return scope === 'daily' ? 'Join Day' : 'Starts Tomorrow';
  }
  return formatNumber(value);
}

/**
 * Trim a long string to fit in a Discord embed field/value safely.
 */
export function truncate(str, max) {
  if (!str) return '';
  if (str.length <= max) return str;
  return `${str.slice(0, max - 1)}…`;
}
