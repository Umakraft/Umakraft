/**
 * utils/imageReport.js
 * ─────────────────────
 * PIPELINE 1 — IMAGE GENERATION
 * Input:  structured game data (leaderboards, fan gains, stats, profiles)
 * Output: PNG buffer rendered via HTML/CSS → headless Chromium
 * Nature: deterministic — same data always produces the same image
 * OpenAI: NOT used and NOT required in this pipeline
 * See:    utils/imageClassifier.js for Pipeline 2 (image analysis)
 * ─────────────────────────────────────────────────────────────────
 * Renders styled HTML card templates to PNG buffers via headless Chromium.
 * Replaces Discord EmbedBuilder for all fan-gain commands and announcements.
 *
 * Each exported render* function accepts a plain data object and returns a
 * PNG Buffer. Use bufferToAttachment() to wrap the buffer for Discord.
 *
 * Browser lifecycle (launch, crash recovery, retry) lives in imageReport-browser.js.
 */

import { readFile } from 'node:fs/promises';
import { AttachmentBuilder } from 'discord.js';
import { renderHtml } from './imageReport-browser.js';

// ── Shared CSS ────────────────────────────────────────────────────────────────

function css(accent = '#ffd700', accent2 = null) {
  const a2 = accent2 || accent + '99';
  return `
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body {
  background: #0d0d1f;
  font-family: system-ui, -apple-system, Arial, sans-serif;
  color: #fff;
  display: inline-block;
  width: 100%;
}
.card {
  background: linear-gradient(170deg,#161628 0%,#0d0d1f 100%);
  position: relative;
  overflow: hidden;
}
.card::after {
  content: 'UmaKraft';
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%) rotate(-20deg);
  font-size: 220px;
  font-weight: 900;
  color: rgba(255,255,255,0.08);
  white-space: nowrap;
  pointer-events: none;
  z-index: 50;
  letter-spacing: -4px;
  user-select: none;
}
.accent-bar {
  height: 3px;
  background: linear-gradient(90deg,${accent},${a2});
}
.header {
  padding: 16px 22px 13px;
  border-bottom: 1px solid rgba(255,255,255,0.07);
}
.hrow { display:flex; align-items:flex-start; justify-content:space-between; gap:12px; }
.htitle { font-size:18px; font-weight:700; letter-spacing:-0.2px; line-height:1.25; }
.htitle .hl { color:${accent}; }
.hdate { font-size:11px; color:rgba(255,255,255,0.38); white-space:nowrap; margin-top:3px; }
.hsub { font-size:11px; color:rgba(255,255,255,0.42); margin-top:5px; }
.col-labels {
  display:flex; align-items:center; gap:10px;
  padding: 5px 22px 4px;
  font-size:10px; text-transform:uppercase; letter-spacing:0.7px;
  color:rgba(255,255,255,0.28);
  border-bottom:1px solid rgba(255,255,255,0.05);
}
.body { padding:4px 0 6px; }
.row {
  padding: 11px 22px;
  display:flex; align-items:center; gap:10px;
}
.row:nth-child(odd)  { background:rgba(255,255,255,0.022); }
.row:nth-child(even) { background:transparent; }
.rank  { font-size:16px; font-weight:700; min-width:40px; text-align:right; color:rgba(255,255,255,0.45); flex-shrink:0; }
.medal { font-size:22px; min-width:30px; flex-shrink:0; line-height:1; }
.name  { flex:1; font-size:17px; font-weight:700; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.new-tag {
  display:inline-block; font-size:9px; padding:1px 4px;
  background:rgba(100,200,100,0.18); color:#81c784;
  border:1px solid rgba(100,200,100,0.28); border-radius:3px;
  margin-left:5px; vertical-align:middle; white-space:nowrap; flex-shrink:0;
}
.gain { font-size:17px; font-weight:700; color:${accent}; min-width:120px; text-align:right; flex-shrink:0; }
.sub-gain { font-size:12px; color:rgba(255,255,255,0.35); min-width:95px; text-align:right; flex-shrink:0; }
.divider { height:1px; background:rgba(255,255,255,0.06); margin:4px 0; }
.section-title {
  padding:8px 22px 4px;
  font-size:10px; text-transform:uppercase; letter-spacing:0.7px;
  color:rgba(255,255,255,0.35); font-weight:600;
}
.warn-row { padding:6px 22px; display:flex; align-items:center; gap:10px; font-size:12px; }
.warn-row .name  { color:rgba(255,255,255,0.7); }
.warn-row .warn-val { color:#ef9a9a; font-weight:600; min-width:108px; text-align:right; flex-shrink:0; }
.footer {
  padding:9px 22px;
  border-top:1px solid rgba(255,255,255,0.06);
  font-size:10px; color:rgba(255,255,255,0.28);
  display:flex; justify-content:space-between; align-items:center;
}
.stat-grid {
  display:grid; grid-template-columns:1fr 1fr;
  gap:1px; background:rgba(255,255,255,0.07);
}
.stat-cell { background:#161628; padding:16px 20px; }
.stat-lbl  { font-size:10px; text-transform:uppercase; letter-spacing:0.7px; color:rgba(255,255,255,0.35); margin-bottom:6px; }
.stat-val  { font-size:21px; font-weight:700; color:${accent}; }
.stat-sub  { font-size:10px; color:rgba(255,255,255,0.28); margin-top:3px; }
.bar-row   { padding:9px 22px; display:flex; align-items:center; gap:12px; }
.bar-lbl   { font-size:11px; font-weight:600; text-transform:uppercase; letter-spacing:0.5px; color:rgba(255,255,255,0.45); min-width:68px; }
.bar-track { flex:1; height:7px; background:rgba(255,255,255,0.08); border-radius:4px; overflow:hidden; }
.bar-fill  { height:100%; border-radius:4px; background:linear-gradient(90deg,${accent},${a2}); }
.bar-val   { font-size:13px; font-weight:700; color:${accent}; min-width:108px; text-align:right; }
.rank-badge {
  display:inline-flex; align-items:center; gap:5px;
  padding:7px 14px;
  background:rgba(255,255,255,0.04);
  border:1px solid rgba(255,255,255,0.09);
  border-radius:7px;
  font-size:13px; font-weight:600; color:${accent};
  margin:4px 22px 8px;
}
.total-row {
  padding:10px 22px;
  display:flex; align-items:center; justify-content:space-between;
}
.total-label { font-size:12px; font-weight:600; color:rgba(255,255,255,0.5); }
.total-val   { font-size:15px; font-weight:700; color:${accent}; }
</style>`;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function esc(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
function medal(rank) {
  return rank === 1 ? '🥇' : rank === 2 ? '🥈' : rank === 3 ? '🥉' : '';
}
function rankCell(r) {
  const m = medal(r);
  return m ? `<span class="medal">${m}</span>` : `<span class="rank">#${r}</span>`;
}

/**
 * Deterministic per-name color from a curated palette.
 * All hues are chosen to avoid red (0-25°, 335-360°) and green (85-165°),
 * which are reserved for fan-gain indicators.
 */
const NAME_COLORS = [
  '#FFD700', // gold          hue ~51°
  '#FFC107', // amber         hue ~45°
  '#FF9800', // orange        hue ~36°
  '#FF8C42', // deep orange   hue ~27°
  '#FFEE58', // bright yellow hue ~53°
  '#FFF176', // pale yellow   hue ~59°
  '#F48FB1', // light pink    hue ~340°
  '#FF80AB', // hot pink      hue ~340°
  '#FF4D94', // deep pink     hue ~338°
  '#E040FB', // purple-pink   hue ~291°
  '#CE93D8', // lavender      hue ~291°
  '#BA68C8', // medium purple hue ~291°
  '#AB47BC', // dark purple   hue ~291°
  '#B388FF', // soft violet   hue ~262°
  '#82B1FF', // light blue    hue ~217°
  '#64B5F6', // cornflower    hue ~207°
  '#4FC3F7', // sky blue      hue ~199°
  '#29B6F6', // deep sky      hue ~202°
  '#00BCD4', // cyan          hue ~187°
  '#4DD0E1', // light cyan    hue ~187°
];

function hashColor(name) {
  let h = 0;
  for (let i = 0; i < name.length; i++) {
    h = Math.imul(h * 31 + name.charCodeAt(i), 0x9e3779b9) >>> 0;
  }
  return NAME_COLORS[h % NAME_COLORS.length];
}

// ── Leaderboard ───────────────────────────────────────────────────────────────
/**
 * Renders a ranked table matching the Monthly Goal Warning card style.
 *
 * data: {
 *   circleName:   string,
 *   scope:        'Daily' | 'Weekly' | 'Monthly',
 *   date:         string,           — YYYY-MM-DD
 *   totalMembers: number,
 *   quotaLabel:   string,           — e.g. '1,000,000'
 *   rows: [{
 *     name:    string,
 *     gainRaw: number,              — raw fan gain for this scope
 *     gainStr: string,              — formatted gain
 *     gapRaw:  number,              — gainRaw − quota  (+ = surplus, − = deficit)
 *     gapStr:  string,              — e.g. '+500,000' or '-500,000'
 *     pct:     number,              — 0-100+ (gain/quota × 100)
 *     isNew?:  boolean,
 *   }]
 * }
 */
export async function renderLeaderboard(data) {
  const ACCENTS = { Daily: '#ffd700', Weekly: '#4fc3f7', Monthly: '#ce93d8' };
  const accent = ACCENTS[data.scope] ?? '#ffd700';
  const ICONS = { Daily: '🏆', Weekly: '📊', Monthly: '🌟' };
  const icon = ICONS[data.scope] ?? '🏆';

  function pctColor(pct) {
    if (pct >= 100) return '#81c784';
    if (pct >= 70) return '#ffd54f';
    if (pct >= 40) return '#ffb74d';
    return '#ef9a9a';
  }

  const rows = (data.rows || [])
    .map((r, i) => {
      const clr = pctColor(r.pct ?? 0);
      const gapClr = (r.gapRaw ?? 0) >= 0 ? '#81c784' : 'rgba(255,255,255,0.4)';
      const barW = Math.min(100, r.pct ?? 0);
      const rowBg = i % 2 === 0 ? 'rgba(255,255,255,0.022)' : 'transparent';
      return `<tr style="background:${rowBg}">
      <td style="padding:7px 6px 7px 12px;font-size:13px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:220px">${esc(r.name)}${r.isNew ? '<span class="new-tag">NEW</span>' : ''}</td>
      <td style="padding:7px 6px;font-size:13px;font-weight:700;color:${clr};text-align:right;white-space:nowrap">${esc(r.gainStr)}</td>
      <td style="padding:7px 6px;font-size:12px;color:${gapClr};text-align:right;white-space:nowrap">${esc(r.gapStr)}</td>
      <td style="padding:7px 12px 7px 10px;min-width:100px">
        <div style="height:6px;background:rgba(255,255,255,0.08);border-radius:3px;overflow:hidden">
          <div style="width:${barW}%;height:100%;background:linear-gradient(90deg,${clr},${clr}99);border-radius:3px"></div>
        </div>
      </td>
    </tr>`;
    })
    .join('');

  const scopeLabel = data.scope?.toLowerCase() ?? 'fan';
  const colLabel = `${data.scope} Fan Gain`;
  const gapLabel = `Gap to ${esc(data.quotaLabel ?? '')}`;

  const html = `<!DOCTYPE html><html><head><meta charset="utf-8">
<style>
* { margin:0;padding:0;box-sizing:border-box; }
body { background:#0d0d1f;font-family:system-ui,-apple-system,Arial,sans-serif;color:#fff;display:inline-block;width:680px; }
.card { background:linear-gradient(170deg,#161628 0%,#0d0d1f 100%);position:relative;overflow:hidden; }
.card::after { content:'UmaKraft';position:absolute;top:50%;left:50%;transform:translate(-50%,-50%) rotate(-20deg);font-size:220px;font-weight:900;color:rgba(255,255,255,0.08);white-space:nowrap;pointer-events:none;z-index:50;letter-spacing:-4px;user-select:none; }
.accent-bar { height:3px;background:linear-gradient(90deg,${accent},${accent}88); }
.header { padding:14px 18px 10px;border-bottom:1px solid rgba(255,255,255,0.07); }
.htitle { font-size:16px;font-weight:700; }
.hsub { font-size:11px;color:rgba(255,255,255,0.4);margin-top:3px; }
table { width:100%;border-collapse:collapse; }
thead th { padding:6px 6px;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:rgba(255,255,255,0.3);border-bottom:1px solid rgba(255,255,255,0.07);background:#101020; }
thead th:first-child { padding-left:12px; }
thead th:last-child  { padding-right:12px; }
td { border-bottom:1px solid rgba(255,255,255,0.03); }
.new-tag { display:inline-block;font-size:9px;padding:1px 4px;background:rgba(100,200,100,0.18);color:#81c784;border:1px solid rgba(100,200,100,0.28);border-radius:3px;margin-left:5px;vertical-align:middle; }
.footer { padding:9px 18px;border-top:1px solid rgba(255,255,255,0.06);font-size:10px;color:rgba(255,255,255,0.28);display:flex;justify-content:space-between; }
</style></head>
<body><div class="card">
  <div class="accent-bar"></div>
  <div class="header">
    <div style="display:flex;justify-content:space-between;align-items:flex-start">
      <div class="htitle">${icon} ${esc(data.circleName)} — ${esc(data.scope)}</div>
      <div style="font-size:11px;color:rgba(255,255,255,0.38);white-space:nowrap;margin-top:2px">${esc(data.date)}</div>
    </div>
    <div class="hsub">${esc(String(data.rows?.length ?? 0))} member${(data.rows?.length ?? 0) !== 1 ? 's' : ''} ranked · ${esc(data.quotaLabel ?? '')} ${scopeLabel} goal</div>
  </div>
  <table>
    <thead><tr>
      <th style="text-align:left">Trainer</th>
      <th style="text-align:right">${colLabel}</th>
      <th style="text-align:right">${gapLabel}</th>
      <th style="text-align:left;padding-left:10px;min-width:100px">Progress</th>
    </tr></thead>
    <tbody>${rows}</tbody>
  </table>
  <div class="footer">
    <span>${esc(data.circleName)}</span>
    <span>${esc(data.date)}</span>
  </div>
</div></body></html>`;

  return renderHtml(html, 680);
}

// ── Inter-Circle Leaderboard ──────────────────────────────────────────────────
/**
 * Renders a unified cross-circle leaderboard image.
 *
 * data: {
 *   scope:        'Daily' | 'Weekly' | 'Monthly',
 *   date:         string,
 *   totalMembers: number,
 *   circleCount:  number,
 *   rows: [{
 *     name:       string,
 *     circleName: string,   ← which circle this trainer belongs to
 *     gainRaw:    number,
 *     gainStr:    string,
 *   }]
 * }
 */
export async function renderInterCircleLeaderboard(data) {
  const ACCENTS = { Daily: '#ffd700', Weekly: '#4fc3f7', Monthly: '#ce93d8' };
  const accent = ACCENTS[data.scope] ?? '#ffd700';
  const ICONS = { Daily: '🏆', Weekly: '📊', Monthly: '🌟' };
  const icon = ICONS[data.scope] ?? '🏆';

  // Assign a stable color badge per unique circle name
  const CIRCLE_COLORS = ['#ffd700', '#26c6da', '#ce93d8', '#81c784'];
  const circleNames = [...new Set((data.rows ?? []).map(r => r.circleName))];
  const circleColor = name => CIRCLE_COLORS[circleNames.indexOf(name) % CIRCLE_COLORS.length];

  const rows = (data.rows ?? [])
    .map((r, i) => {
      const m = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : '';
      const rankCell = m
        ? `<span style="font-size:18px;min-width:32px;text-align:center;display:inline-block">${m}</span>`
        : `<span style="font-size:13px;font-weight:700;color:rgba(255,255,255,0.4);min-width:32px;text-align:right;display:inline-block">#${i + 1}</span>`;
      const clr = hashColor(r.name);
      const badgeClr = circleColor(r.circleName);
      const rowBg = i % 2 === 0 ? 'rgba(255,255,255,0.022)' : 'transparent';
      return `<tr style="background:${rowBg}">
      <td style="padding:7px 6px 7px 12px;white-space:nowrap">${rankCell}</td>
      <td style="padding:7px 6px;font-size:13px;font-weight:700;color:${clr};max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(r.name)}</td>
      <td style="padding:7px 6px;white-space:nowrap">
        <span style="display:inline-block;font-size:9px;font-weight:700;padding:2px 6px;border-radius:4px;background:${badgeClr}22;color:${badgeClr};border:1px solid ${badgeClr}55;white-space:nowrap;max-width:110px;overflow:hidden;text-overflow:ellipsis">${esc(r.circleName)}</span>
      </td>
      <td style="padding:7px 12px 7px 6px;font-size:13px;font-weight:700;color:${accent};text-align:right;white-space:nowrap">${esc(r.gainStr)}</td>
    </tr>`;
    })
    .join('');

  const html = `<!DOCTYPE html><html><head><meta charset="utf-8">
<style>
* { margin:0;padding:0;box-sizing:border-box; }
body { background:#0d0d1f;font-family:system-ui,-apple-system,Arial,sans-serif;color:#fff;display:inline-block;width:680px; }
.card { background:linear-gradient(170deg,#161628 0%,#0d0d1f 100%);position:relative;overflow:hidden; }
.card::after { content:'UmaKraft';position:absolute;top:50%;left:50%;transform:translate(-50%,-50%) rotate(-20deg);font-size:220px;font-weight:900;color:rgba(255,255,255,0.08);white-space:nowrap;pointer-events:none;z-index:50;letter-spacing:-4px;user-select:none; }
.accent-bar { height:3px;background:linear-gradient(90deg,${accent},${accent}44); }
.header { padding:14px 18px 10px;border-bottom:1px solid rgba(255,255,255,0.07); }
.htitle { font-size:16px;font-weight:700; }
.hsub { font-size:11px;color:rgba(255,255,255,0.4);margin-top:3px; }
table { width:100%;border-collapse:collapse; }
thead th { padding:6px;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:rgba(255,255,255,0.3);border-bottom:1px solid rgba(255,255,255,0.07);background:#101020; }
thead th:first-child { padding-left:12px; }
thead th:last-child { padding-right:12px; }
td { border-bottom:1px solid rgba(255,255,255,0.03); }
.footer { padding:9px 18px;border-top:1px solid rgba(255,255,255,0.06);font-size:10px;color:rgba(255,255,255,0.28);display:flex;justify-content:space-between; }
</style></head>
<body><div class="card">
  <div class="accent-bar"></div>
  <div class="header">
    <div style="display:flex;justify-content:space-between;align-items:flex-start">
      <div class="htitle">${icon} Inter-Circle — ${esc(data.scope)} Leaderboard</div>
      <div style="font-size:11px;color:rgba(255,255,255,0.38);white-space:nowrap;margin-top:2px">${esc(data.date)}</div>
    </div>
    <div class="hsub">${esc(String(data.rows?.length ?? 0))} trainers ranked across ${esc(String(data.circleCount ?? 2))} circles · ${esc(String(data.totalMembers ?? 0))} total members</div>
  </div>
  <table>
    <thead><tr>
      <th style="text-align:center;min-width:40px">#</th>
      <th style="text-align:left">Trainer</th>
      <th style="text-align:left">Circle</th>
      <th style="text-align:right;padding-right:12px">${esc(data.scope)} Fan Gain</th>
    </tr></thead>
    <tbody>${rows}</tbody>
  </table>
  <div class="footer">
    <span>All Circles Combined</span>
    <span>${esc(data.date)}</span>
  </div>
</div></body></html>`;

  return renderHtml(html, 680);
}

// ── Fan Gain (personal) ───────────────────────────────────────────────────────
/**
 * data: { trainerName, circleName,
 *         daily, weekly, monthly,          ← formatted strings
 *         dailyRaw, weeklyRaw, monthlyRaw, ← numbers (0 if N/A)
 *         rank, weekLabel, date, daysLeft, monthlyReq }
 */
export async function renderFanGain(data) {
  const accent = '#ffb347';
  const req = data.monthlyReq || 30_000_000;

  const pct = (raw, target) =>
    typeof raw === 'number' && raw > 0 ? Math.min(100, Math.round((raw / target) * 100)) : 0;

  const dailyPct = pct(data.dailyRaw, req / 30);
  const weeklyPct = pct(data.weeklyRaw, req / 4);
  const monthlyPct = pct(data.monthlyRaw, req);

  const barRow = (label, pctVal, valStr) => `
    <div class="bar-row">
      <span class="bar-lbl">${label}</span>
      <div class="bar-track"><div class="bar-fill" style="width:${pctVal}%"></div></div>
      <span class="bar-val">${esc(valStr)}</span>
    </div>`;

  const html = `<!DOCTYPE html><html><head><meta charset="utf-8">${css(accent)}</head>
<body><div class="card">
  <div class="accent-bar"></div>
  <div class="header">
    <div class="hrow">
      <div class="htitle">🏇 ${esc(data.trainerName)}</div>
      <div class="hdate">${esc(data.date)}</div>
    </div>
    <div class="hsub">${esc(data.circleName)} · Fan Gain Report</div>
  </div>
  <div class="body" style="padding:10px 0 6px">
    ${barRow('Daily', dailyPct, data.daily)}
    ${barRow('Weekly', weeklyPct, data.weekly)}
    ${barRow('Monthly', monthlyPct, data.monthly)}
    ${data.rank ? `<div class="rank-badge">🏅 ${esc(data.rank)}</div>` : ''}
  </div>
  <div class="footer">
    <span>Week: ${esc(data.weekLabel)}</span>
    <span>${esc(data.daysLeft)} day${data.daysLeft !== 1 ? 's' : ''} remaining</span>
  </div>
</div></body></html>`;

  return renderHtml(html, 580);
}

// ── Total Fan (personal lifetime) ─────────────────────────────────────────────
/**
 * data: { trainerName, rank, totalFans, circleName }
 */
export async function renderTotalFan(data) {
  const accent = '#b39ddb';
  const html = `<!DOCTYPE html><html><head><meta charset="utf-8">${css(accent)}</head>
<body><div class="card">
  <div class="accent-bar"></div>
  <div class="header">
    <div class="hrow">
      <div class="htitle">⭐ ${esc(data.trainerName)}</div>
    </div>
    <div class="hsub">${esc(data.circleName)} · Lifetime Fan Count</div>
  </div>
  <div style="padding:20px 22px;display:flex;gap:14px">
    <div style="flex:1;text-align:center;background:rgba(255,255,255,0.04);border-radius:9px;padding:18px 14px">
      <div class="stat-lbl">Lifetime Rank</div>
      <div style="font-size:30px;font-weight:700;color:${accent}">${esc(data.rank)}</div>
    </div>
    <div style="flex:1;text-align:center;background:rgba(255,255,255,0.04);border-radius:9px;padding:18px 14px">
      <div class="stat-lbl">Total Fans</div>
      <div style="font-size:26px;font-weight:700;color:#ffd54f">${esc(data.totalFans)}</div>
    </div>
  </div>
  <div class="footer">
    <span>${esc(data.circleName)}</span>
    <span>Active members only · left members excluded</span>
  </div>
</div></body></html>`;
  return renderHtml(html, 500);
}

// ── Circle Totals ─────────────────────────────────────────────────────────────
/**
 * data: { circleName, date, totalDaily, totalWeekly, totalMonthly, totalLifetime,
 *         activeMembers, pendingCount }
 */
export async function renderCircleTotals(data) {
  const accent = '#4db6ac';
  const pending = data.pendingCount > 0 ? ` · ${data.pendingCount} pending excluded` : '';
  const html = `<!DOCTYPE html><html><head><meta charset="utf-8">${css(accent)}</head>
<body><div class="card">
  <div class="accent-bar"></div>
  <div class="header">
    <div class="hrow">
      <div class="htitle">🌸 ${esc(data.circleName)} — Circle Totals</div>
      <div class="hdate">${esc(data.date)}</div>
    </div>
    <div class="hsub">${esc(data.activeMembers)} active members${pending}</div>
  </div>
  <div class="stat-grid">
    <div class="stat-cell">
      <div class="stat-lbl">Daily Total</div>
      <div class="stat-val">${esc(data.totalDaily)}</div>
      <div class="stat-sub">fans gained today</div>
    </div>
    <div class="stat-cell">
      <div class="stat-lbl">Weekly Total</div>
      <div class="stat-val" style="color:#4fc3f7">${esc(data.totalWeekly)}</div>
      <div class="stat-sub">this week</div>
    </div>
    <div class="stat-cell">
      <div class="stat-lbl">Monthly Total</div>
      <div class="stat-val" style="color:#ce93d8">${esc(data.totalMonthly)}</div>
      <div class="stat-sub">this month</div>
    </div>
    <div class="stat-cell">
      <div class="stat-lbl">Lifetime Total</div>
      <div class="stat-val" style="color:#ffd54f">${esc(data.totalLifetime)}</div>
      <div class="stat-sub">all time (active)</div>
    </div>
  </div>
  <div class="footer">
    <span>${esc(data.circleName)}</span>
    <span>Members who left are excluded</span>
  </div>
</div></body></html>`;
  return renderHtml(html, 580);
}

// ── Daily Warnings ────────────────────────────────────────────────────────────
/**
 * data: { circleName, date, threshold, rows[{name,yesterday,monthly}] }
 */
export async function renderDailyWarnings(data) {
  const accent = '#ef5350';
  const rows = (data.rows || [])
    .map(
      (r, i) => `
    <div class="row">
      <span class="rank">#${i + 1}</span>
      <span style="min-width:0px;width:0"></span>
      <span class="name">${esc(r.name)}</span>
      <span class="gain" style="color:#ef9a9a;min-width:96px">${esc(r.yesterday)}</span>
      <span class="sub-gain">${esc(r.monthly)}</span>
    </div>`
    )
    .join('');

  const html = `<!DOCTYPE html><html><head><meta charset="utf-8">${css(accent)}</head>
<body><div class="card">
  <div class="accent-bar"></div>
  <div class="header">
    <div class="hrow">
      <div class="htitle">⚠️ Daily Reminder — Below ${esc(data.threshold)}</div>
      <div class="hdate">${esc(data.date)}</div>
    </div>
    <div class="hsub">${esc(data.circleName)} · Trainers below the daily fan target</div>
  </div>
  <div class="col-labels">
    <span style="min-width:34px"></span>
    <span style="min-width:0px"></span>
    <span style="flex:1">Trainer</span>
    <span style="min-width:96px;text-align:right">Yesterday</span>
    <span style="min-width:90px;text-align:right">Monthly</span>
  </div>
  <div class="body">${rows}</div>
  <div class="footer">
    <span>Safe: members above 20M monthly with &gt;15 days remaining are excluded</span>
  </div>
</div></body></html>`;
  return renderHtml(html, 640);
}

// ── Weekly Contribution Report ────────────────────────────────────────────────
/**
 * data: { circleName, date, rows[{rank,name,daily,weekly,monthly}] }
 */
export async function renderWeeklyReport(data) {
  const accent = '#ffd54f';
  const rows = (data.rows || [])
    .map(
      r => `
    <div class="row">
      ${rankCell(r.rank)}
      <span style="min-width:0px;width:0"></span>
      <span class="name">${esc(r.name)}</span>
      <span class="sub-gain">${esc(r.daily)}</span>
      <span class="gain" style="min-width:96px">${esc(r.weekly)}</span>
      <span class="sub-gain" style="color:#ce93d8">${esc(r.monthly)}</span>
    </div>`
    )
    .join('');

  const html = `<!DOCTYPE html><html><head><meta charset="utf-8">${css(accent)}</head>
<body><div class="card">
  <div class="accent-bar"></div>
  <div class="header">
    <div class="hrow">
      <div class="htitle">📈 ${esc(data.circleName)} — Weekly Contribution</div>
      <div class="hdate">Week ending ${esc(data.date)}</div>
    </div>
    <div class="hsub">Weekly Contribution Report</div>
  </div>
  <div class="col-labels">
    <span style="min-width:34px;margin-right:0px"></span>
    <span style="min-width:0px"></span>
    <span style="flex:1">Trainer</span>
    <span style="min-width:90px;text-align:right">Daily</span>
    <span style="min-width:96px;text-align:right;color:${accent}">Weekly</span>
    <span style="min-width:90px;text-align:right;color:#ce93d8">Monthly</span>
  </div>
  <div class="body">${rows}</div>
  <div class="footer">
    <span>${esc(data.circleName)}</span>
    <span>Week ending ${esc(data.date)}</span>
  </div>
</div></body></html>`;
  return renderHtml(html, 700);
}

// ── Tally Results ─────────────────────────────────────────────────────────────
/**
 * data: { circleName, weekLabel, date, rows[{rank,name,weekGain,monthly}], circleWeekTotal }
 */
export async function renderTallyResults(data) {
  const accent = '#ffab91';
  const rows = (data.rows || [])
    .map(
      r => `
    <div class="row">
      ${rankCell(r.rank)}
      <span style="min-width:0px;width:0"></span>
      <span class="name">${esc(r.name)}</span>
      <span class="gain">${esc(r.weekGain)}</span>
      <span class="sub-gain" style="color:#ce93d8">${esc(r.monthly)}</span>
    </div>`
    )
    .join('');

  const html = `<!DOCTYPE html><html><head><meta charset="utf-8">${css(accent)}</head>
<body><div class="card">
  <div class="accent-bar"></div>
  <div class="header">
    <div class="hrow">
      <div class="htitle">📋 ${esc(data.circleName)} — <span class="hl">${esc(data.weekLabel)}</span> Week Results</div>
      <div class="hdate">${esc(data.date)}</div>
    </div>
    <div class="hsub">Weekly tally results</div>
  </div>
  <div class="col-labels">
    <span style="min-width:34px"></span>
    <span style="min-width:0px"></span>
    <span style="flex:1">Trainer</span>
    <span style="min-width:108px;text-align:right;color:${accent}">Week Gain</span>
    <span style="min-width:90px;text-align:right;color:#ce93d8">Monthly</span>
  </div>
  <div class="body">${rows}</div>
  <div class="divider"></div>
  <div class="total-row">
    <span class="total-label">Circle Weekly Total</span>
    <span class="total-val">${esc(data.circleWeekTotal)}</span>
  </div>
  <div class="footer">
    <span>${esc(data.circleName)}</span>
    <span>${esc(data.date)}</span>
  </div>
</div></body></html>`;
  return renderHtml(html, 640);
}

// ── Simple info card (tally not started, errors, etc.) ────────────────────────
/**
 * data: { title, body, footer, accent }
 */
export async function renderInfoCard(data) {
  const accent = data.accent || '#90a4ae';
  const html = `<!DOCTYPE html><html><head><meta charset="utf-8">${css(accent)}</head>
<body><div class="card">
  <div class="accent-bar"></div>
  <div class="header">
    <div class="htitle">${esc(data.title)}</div>
  </div>
  <div style="padding:16px 22px;font-size:13px;line-height:1.6;color:rgba(255,255,255,0.7)">
    ${esc(data.body)}
  </div>
  <div class="footer"><span>${esc(data.footer || '')}</span></div>
</div></body></html>`;
  return renderHtml(html, 520);
}

// ── Timeline event card ───────────────────────────────────────────────────────
/**
 * Milestone-style card for a single Uma Musume timeline event.
 *
 * data: { title, url, startDateFmt, endDateFmt, countdown, status,
 *         type, description, imageDataUrl, date }
 * status: 'active' | 'upcoming' | 'ending_soon' | 'ended' | 'unknown'
 *
 * Layout matches renderMilestone exactly — 680 px wide, dark gradient,
 * UmaKraft watermark, 3 px accent bar, left info panel + 220 px image panel,
 * footer bar at the bottom.
 */
export async function renderTimelineEvent(data) {
  // Status → accent colours (mirrors milestone's special/standard palette).
  const STATUS_MAP = {
    active: { accent: '#f48fb1', a2: '#ce93d8', label: '🟢 ACTIVE' },
    upcoming: { accent: '#90caf9', a2: '#5865f2', label: '🔵 UPCOMING' },
    ending_soon: { accent: '#ffd700', a2: '#ffab40', label: '🔴 ENDING SOON' },
    ended: { accent: '#747f8d', a2: '#5a6370', label: '⚫ ENDED' },
    unknown: { accent: '#b39ddb', a2: '#7b68ee', label: '⚪ SCHEDULED' },
  };
  const st = STATUS_MAP[data.status] ?? STATUS_MAP.unknown;
  const accent = st.accent;
  const accent2 = st.a2;

  // Right image panel — same dimensions and cover crop as milestone character art.
  const imgPanel = data.imageDataUrl
    ? `<div style="width:220px;flex-shrink:0;overflow:hidden;background:#0a0a1a">` +
      `<img src="${data.imageDataUrl}" style="width:100%;height:100%;object-fit:cover;object-position:top center"></div>`
    : '';

  // Type tag (e.g. "Gacha", "Story") — shown as the "pos" subtitle.
  const typeTag = data.type ? esc(data.type) : 'Timeline Event';

  // Date stat rows — same structure as milestone's stat-row.
  const dateStats = [
    data.startDateFmt
      ? `<div class="stat-row"><span class="stat-lbl">📅 Start</span><span class="stat-val-dim">${esc(data.startDateFmt)}</span></div>`
      : null,
    data.endDateFmt
      ? `<div class="stat-row"><span class="stat-lbl">⏰ End</span><span class="stat-val-dim">${esc(data.endDateFmt)}</span></div>`
      : null,
  ]
    .filter(Boolean)
    .join('');

  // Countdown — rendered like the milestone's .stat-val (accent-coloured, bold).
  const countdownRow = data.countdown
    ? `<div class="stat-row"><span class="stat-lbl">⏳ Time</span><span class="stat-val">${esc(data.countdown)}</span></div>`
    : '';

  // Description — same .msg style as milestone (small, muted, capped).
  const desc = (data.description ?? '').slice(0, 220);
  const descHtml = desc
    ? `<div class="divider"></div><div class="msg">${esc(desc)}${data.description?.length > 220 ? '…' : ''}</div>`
    : '';

  const html = `<!DOCTYPE html><html><head><meta charset="utf-8">
<style>
* { margin:0;padding:0;box-sizing:border-box; }
body { background:#0d0d1f;font-family:system-ui,-apple-system,Arial,sans-serif;color:#fff;display:inline-block;width:680px; }
.card { background:linear-gradient(170deg,#161628 0%,#0d0d1f 100%);display:flex;min-height:280px;position:relative;overflow:hidden; }
.card::after { content:'UmaKraft';position:absolute;top:50%;left:50%;transform:translate(-50%,-50%) rotate(-20deg);font-size:220px;font-weight:900;color:rgba(255,255,255,0.08);white-space:nowrap;pointer-events:none;z-index:50;letter-spacing:-4px;user-select:none; }
.accent-bar { position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,${accent},${accent2}); }
.left { flex:1;padding:22px 20px 18px;display:flex;flex-direction:column;gap:8px;margin-top:3px;min-width:0; }
.tier { font-size:11px;text-transform:uppercase;letter-spacing:0.8px;color:${accent};font-weight:700; }
.name { font-size:20px;font-weight:700;letter-spacing:-0.3px;line-height:1.2; }
.pos { font-size:11px;color:rgba(255,255,255,0.45);margin-top:2px; }
.divider { height:1px;background:rgba(255,255,255,0.08);margin:4px 0; }
.stat-row { display:flex;gap:6px;align-items:center; }
.stat-lbl { font-size:10px;text-transform:uppercase;letter-spacing:0.5px;color:rgba(255,255,255,0.35);min-width:72px; }
.stat-val { font-size:13px;font-weight:700;color:${accent}; }
.stat-val-dim { font-size:12px;font-weight:600;color:rgba(255,255,255,0.6); }
.msg { font-size:11px;line-height:1.55;color:rgba(255,255,255,0.6);flex:1;overflow:hidden; }
.footer-bar { font-size:10px;color:rgba(255,255,255,0.3);padding:8px 20px;border-top:1px solid rgba(255,255,255,0.06);display:flex;justify-content:space-between; }
</style></head>
<body><div style="width:680px">
  <div class="card">
    <div class="accent-bar"></div>
    <div class="left">
      <div class="tier">${st.label}</div>
      <div class="name">${esc(data.title)}</div>
      <div class="pos">${esc(typeTag)}</div>
      <div class="divider"></div>
      ${dateStats}
      ${countdownRow}
      ${descHtml}
    </div>
    ${imgPanel}
  </div>
  <div class="footer-bar">
    <span>uma.moe/timeline</span>
    <span>${esc(data.date ?? '')}</span>
  </div>
</div></body></html>`;

  return renderHtml(html, 680);
}

// ── Monthly 30M warning card ──────────────────────────────────────────────────
/**
 * data: { circleName, daysLeft, monthName, date,
 *         rows: [{name, monthly, monthlyRaw, gap, gapRaw, onTrack}] }
 */
export async function renderMonthlyWarningCard(data) {
  const accent = '#ff7043';

  const goal = 30_000_000;

  const rows = (data.rows || [])
    .map((r, i) => {
      const pct = Math.min(100, Math.round((r.monthlyRaw / goal) * 100));
      const color = r.onTrack ? '#81c784' : pct >= 60 ? '#ffd54f' : '#ef9a9a';
      const rowBg = i % 2 === 0 ? 'rgba(255,255,255,0.02)' : 'transparent';
      return `<tr style="background:${rowBg}">
      <td style="padding:7px 10px;font-size:12px;font-weight:600">${esc(r.name)}</td>
      <td style="padding:7px 6px;font-size:12px;font-weight:700;color:${color};text-align:right">${esc(r.monthly)}</td>
      <td style="padding:7px 6px;font-size:11px;color:rgba(255,255,255,0.4);text-align:right">-${esc(r.gap)}</td>
      <td style="padding:7px 10px;min-width:90px">
        <div style="height:6px;background:rgba(255,255,255,0.08);border-radius:3px;overflow:hidden">
          <div style="width:${pct}%;height:100%;background:linear-gradient(90deg,${color},${color}99);border-radius:3px"></div>
        </div>
      </td>
    </tr>`;
    })
    .join('');

  const html = `<!DOCTYPE html><html><head><meta charset="utf-8">
<style>
* { margin:0;padding:0;box-sizing:border-box; }
body { background:#0d0d1f;font-family:system-ui,-apple-system,Arial,sans-serif;color:#fff;display:inline-block;width:640px; }
.card { background:linear-gradient(170deg,#161628 0%,#0d0d1f 100%);position:relative;overflow:hidden; }
.card::after { content:'UmaKraft';position:absolute;top:50%;left:50%;transform:translate(-50%,-50%) rotate(-20deg);font-size:220px;font-weight:900;color:rgba(255,255,255,0.08);white-space:nowrap;pointer-events:none;z-index:50;letter-spacing:-4px;user-select:none; }
.accent-bar { height:3px;background:linear-gradient(90deg,${accent},${accent}88); }
.header { padding:14px 18px 10px;border-bottom:1px solid rgba(255,255,255,0.07); }
.htitle { font-size:16px;font-weight:700; }
.hsub { font-size:11px;color:rgba(255,255,255,0.4);margin-top:3px; }
table { width:100%;border-collapse:collapse; }
thead th { padding:6px 6px;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:rgba(255,255,255,0.3);border-bottom:1px solid rgba(255,255,255,0.07);background:#101020; }
thead th:first-child { padding-left:10px; }
thead th:last-child { padding-right:10px; }
td { border-bottom:1px solid rgba(255,255,255,0.03); }
.footer { padding:9px 18px;border-top:1px solid rgba(255,255,255,0.06);font-size:10px;color:rgba(255,255,255,0.28);display:flex;justify-content:space-between; }
</style></head>
<body><div class="card">
  <div class="accent-bar"></div>
  <div class="header">
    <div class="htitle">📊 Monthly Goal Warning — ${esc(data.monthName)}</div>
    <div class="hsub">${esc(String(data.rows.length))} member${data.rows.length !== 1 ? 's' : ''} below 30,000,000 fan goal · ${esc(String(data.daysLeft))} day${data.daysLeft !== 1 ? 's' : ''} remaining</div>
  </div>
  <table>
    <thead><tr>
      <th style="text-align:left">Trainer</th>
      <th style="text-align:right">Monthly</th>
      <th style="text-align:right">Gap to 30M</th>
      <th style="text-align:left;padding-left:10px;min-width:90px">Progress</th>
    </tr></thead>
    <tbody>${rows}</tbody>
  </table>
  <div class="footer">
    <span>${esc(data.circleName)}</span>
    <span>${esc(data.date)}</span>
  </div>
</div></body></html>`;

  return renderHtml(html, 640);
}

// ── Circle Master — Excel-style day-by-day table ──────────────────────────────
/**
 * data: { circleName, monthName, year, date,
 *         days: number[],                 ← 1-based day numbers
 *         members: [{name, gains, monthly}],  ← gains indexed by days position
 *         totals: number[],              ← circle total per day
 *         circleMonthly: number }
 */
export async function renderCircleMaster(data) {
  const accent = '#ffd54f';

  function compactNum(n) {
    if (!n || n === 0) return '—';
    if (n >= 1_000_000) {
      const v = n / 1_000_000;
      return (v % 1 === 0 ? v.toFixed(0) : v.toFixed(1)) + 'M';
    }
    if (n >= 1_000) return Math.round(n / 1_000) + 'K';
    return String(n);
  }

  const nameCW = 140;
  const dayCW = 58;
  const monCW = 88;
  const totalW = nameCW + data.days.length * dayCW + monCW;

  const dayHeaders = data.days
    .map(d => `<th style="min-width:${dayCW}px;max-width:${dayCW}px;text-align:center">${d}</th>`)
    .join('');

  const memberRows = data.members
    .map((m, ri) => {
      const isTop3 = ri < 3;
      const topStyle = isTop3 ? 'color:#ffd700;font-weight:700' : '';
      const cells = m.gains
        .map(g => {
          const v = compactNum(g);
          const color =
            g >= 2_000_000
              ? '#ffd700'
              : g >= 1_000_000
                ? '#a5d6a7'
                : g > 0
                  ? 'rgba(255,255,255,0.65)'
                  : 'rgba(255,255,255,0.2)';
          return `<td style="text-align:center;font-size:11px;color:${color}">${v}</td>`;
        })
        .join('');
      const rowBg = ri % 2 === 0 ? 'rgba(255,255,255,0.025)' : 'transparent';
      return `<tr style="background:${rowBg}">
      <td style="padding:6px 10px;font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:${nameCW}px;${topStyle}">${esc(m.name)}</td>
      ${cells}
      <td style="text-align:right;padding-right:10px;font-size:12px;font-weight:700;color:#ce93d8;min-width:${monCW}px">${compactNum(m.monthly)}</td>
    </tr>`;
    })
    .join('');

  const totalCells = data.totals
    .map(g => {
      const v = compactNum(g);
      return `<td style="text-align:center;font-size:11px;color:#4fc3f7;font-weight:600">${v}</td>`;
    })
    .join('');

  const totalRow = `<tr style="background:rgba(79,195,247,0.06);border-top:1px solid rgba(79,195,247,0.2)">
    <td style="padding:6px 10px;font-size:11px;font-weight:700;color:#4fc3f7">Circle Total</td>
    ${totalCells}
    <td style="text-align:right;padding-right:10px;font-size:12px;font-weight:700;color:#4fc3f7">${compactNum(data.circleMonthly)}</td>
  </tr>`;

  const html = `<!DOCTYPE html><html><head><meta charset="utf-8">
<style>
* { margin:0;padding:0;box-sizing:border-box; }
body { background:#0d0d1f;font-family:system-ui,-apple-system,Arial,sans-serif;color:#fff;display:inline-block;width:${totalW}px; }
.card { background:linear-gradient(170deg,#161628 0%,#0d0d1f 100%);position:relative;overflow:hidden; }
.card::after { content:'UmaKraft';position:absolute;top:50%;left:50%;transform:translate(-50%,-50%) rotate(-20deg);font-size:220px;font-weight:900;color:rgba(255,255,255,0.08);white-space:nowrap;pointer-events:none;z-index:50;letter-spacing:-4px;user-select:none; }
.accent-bar { height:3px;background:linear-gradient(90deg,${accent},${accent}88); }
.header { padding:14px 16px 10px;border-bottom:1px solid rgba(255,255,255,0.07); }
.htitle { font-size:16px;font-weight:700; }
.hsub { font-size:11px;color:rgba(255,255,255,0.42);margin-top:4px; }
table { width:100%;border-collapse:collapse; }
thead th { padding:6px 0;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:rgba(255,255,255,0.35);border-bottom:1px solid rgba(255,255,255,0.08);background:#101020; }
thead th:first-child { text-align:left;padding-left:10px; }
thead th:last-child { text-align:right;padding-right:10px; }
td { padding:5px 0;border-bottom:1px solid rgba(255,255,255,0.03); }
.footer { padding:9px 16px;border-top:1px solid rgba(255,255,255,0.06);font-size:10px;color:rgba(255,255,255,0.28);display:flex;justify-content:space-between; }
</style></head>
<body><div class="card">
  <div class="accent-bar"></div>
  <div class="header">
    <div class="htitle">📊 ${esc(data.circleName)} — Circle Master (${esc(data.monthName)} ${esc(String(data.year))})</div>
    <div class="hsub">${esc(data.members.length)} members · ${esc(data.days.length)} days recorded · sorted by monthly total</div>
  </div>
  <table>
    <thead><tr>
      <th style="min-width:${nameCW}px;text-align:left;padding-left:10px">Trainer</th>
      ${dayHeaders}
      <th style="min-width:${monCW}px;text-align:right;padding-right:10px;color:#ce93d8">Monthly</th>
    </tr></thead>
    <tbody>${memberRows}${totalRow}</tbody>
  </table>
  <div class="footer">
    <span>${esc(data.circleName)}</span>
    <span>${esc(data.date)}</span>
  </div>
</div></body></html>`;

  return renderHtml(html, totalW);
}

// ── Circle Master — Single Day view ──────────────────────────────────────────
/**
 * data: { circleName, monthName, year, day, date,
 *         rows: [{rank, name, gain}], totalGain }
 */
export async function renderCircleMasterDay(data) {
  const accent = '#ffd54f';
  const rows = (data.rows || [])
    .map(
      r => `
    <div class="row">
      ${rankCell(r.rank)}
      <span style="min-width:0px;width:0"></span>
      <span class="name">${esc(r.name)}</span>
      <span class="gain">${esc(r.gain)}</span>
    </div>`
    )
    .join('');

  const html = `<!DOCTYPE html><html><head><meta charset="utf-8">${css(accent)}</head>
<body><div class="card">
  <div class="accent-bar"></div>
  <div class="header">
    <div class="hrow">
      <div class="htitle">📋 ${esc(data.circleName)} — Day ${esc(String(data.day))}</div>
      <div class="hdate">${esc(data.monthName)} ${esc(String(data.day))}, ${esc(String(data.year))}</div>
    </div>
    <div class="hsub">Circle Daily Total: ${esc(data.totalGain)}</div>
  </div>
  <div class="col-labels">
    <span style="min-width:34px"></span><span style="min-width:0px"></span>
    <span style="flex:1">Trainer</span>
    <span style="min-width:108px;text-align:right">Fan Gain</span>
  </div>
  <div class="body">${rows}</div>
  <div class="footer">
    <span>${esc(data.circleName)}</span>
    <span>${esc(data.date)}</span>
  </div>
</div></body></html>`;
  return renderHtml(html, 580);
}

// ── Milestone card ────────────────────────────────────────────────────────────
/**
 * data: { trainerName, thresholdLabel, monthlyGain, posLabel, message,
 *         imagePath, isSpecial, circleName }
 */
export async function renderMilestone(data) {
  const accent = data.isSpecial ? '#ffd700' : '#f48fb1';
  const accent2 = data.isSpecial ? '#ffab40' : '#ce93d8';
  const icon = data.isSpecial ? '💞' : '🎉';

  // Load character image as base64 data URL
  let imgTag = '';
  if (data.imagePath) {
    try {
      const buf = await readFile(data.imagePath);
      const ext = data.imagePath.split('.').pop().toLowerCase();
      const mime = ext === 'png' ? 'image/png' : ext === 'gif' ? 'image/gif' : 'image/jpeg';
      const b64 = buf.toString('base64');
      imgTag = `<img src="data:${mime};base64,${b64}" style="width:100%;height:100%;object-fit:cover;object-position:top center">`;
    } catch {
      /* no image */
    }
  }

  const hasImg = imgTag !== '';
  const leftWidth = hasImg ? 'flex:1' : 'flex:1';
  const imgPanel = hasImg
    ? `<div style="width:220px;flex-shrink:0;overflow:hidden;background:#0a0a1a">${imgTag}</div>`
    : '';

  // Truncate message to avoid giant cards
  const msgText =
    (data.message || '').slice(0, 280) + ((data.message || '').length > 280 ? '…' : '');

  const html = `<!DOCTYPE html><html><head><meta charset="utf-8">
<style>
* { margin:0;padding:0;box-sizing:border-box; }
body { background:#0d0d1f;font-family:system-ui,-apple-system,Arial,sans-serif;color:#fff;display:inline-block;width:680px; }
.card { background:linear-gradient(170deg,#161628 0%,#0d0d1f 100%);display:flex;min-height:280px;position:relative;overflow:hidden; }
.card::after { content:'UmaKraft';position:absolute;top:50%;left:50%;transform:translate(-50%,-50%) rotate(-20deg);font-size:220px;font-weight:900;color:rgba(255,255,255,0.08);white-space:nowrap;pointer-events:none;z-index:50;letter-spacing:-4px;user-select:none; }
.accent-bar { position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,${accent},${accent2}); }
.left { ${leftWidth};padding:22px 20px 18px;display:flex;flex-direction:column;gap:8px;margin-top:3px; }
.tier { font-size:11px;text-transform:uppercase;letter-spacing:0.8px;color:${accent};font-weight:700; }
.name { font-size:20px;font-weight:700;letter-spacing:-0.3px;line-height:1.2; }
.pos { font-size:11px;color:rgba(255,255,255,0.45);margin-top:2px; }
.divider { height:1px;background:rgba(255,255,255,0.08);margin:4px 0; }
.stat-row { display:flex;gap:6px;align-items:center; }
.stat-lbl { font-size:10px;text-transform:uppercase;letter-spacing:0.5px;color:rgba(255,255,255,0.35);min-width:95px; }
.stat-val { font-size:13px;font-weight:700;color:${accent}; }
.msg { font-size:11px;line-height:1.55;color:rgba(255,255,255,0.6);flex:1;overflow:hidden; }
.footer-bar { font-size:10px;color:rgba(255,255,255,0.3);padding:8px 20px;border-top:1px solid rgba(255,255,255,0.06); }
</style></head>
<body><div style="width:680px">
  <div class="card">
    <div class="accent-bar"></div>
    <div class="left">
      <div class="tier">${icon} ${esc(data.thresholdLabel)} milestone</div>
      <div class="name">${esc(data.trainerName)}</div>
      <div class="pos">${esc(data.posLabel)}</div>
      <div class="divider"></div>
      <div class="stat-row">
        <span class="stat-lbl">Monthly Gain</span>
        <span class="stat-val">${esc(data.monthlyGain)}</span>
      </div>
      <div class="divider"></div>
      <div class="msg">${esc(msgText)}</div>
    </div>
    ${imgPanel}
  </div>
  <div class="footer-bar">${esc(data.circleName)}</div>
</div></body></html>`;

  return renderHtml(html, 680);
}

// ── Store confirmation card ────────────────────────────────────────────────────
/**
 * data: { trainerName, trainerId, isUpdate, rank, affinity, whiteSkills, submittedBy }
 */
export async function renderStoreConfirmation(data) {
  const accent = '#9b59b6';
  const action = data.isUpdate ? 'Updated' : 'Stored';
  const actionColor = data.isUpdate ? '#4fc3f7' : '#81c784';

  const html = `<!DOCTYPE html><html><head><meta charset="utf-8">${css(accent)}</head>
<body><div class="card">
  <div class="accent-bar"></div>
  <div class="header">
    <div class="hrow">
      <div class="htitle" style="display:flex;align-items:center;gap:8px">
        <span style="font-size:11px;padding:2px 8px;background:${actionColor}22;color:${actionColor};border:1px solid ${actionColor}44;border-radius:4px;font-weight:700;letter-spacing:0.5px">${action}</span>
        ${esc(data.trainerName)}
      </div>
    </div>
    <div class="hsub">Trainer ID: <span style="font-family:monospace;color:rgba(255,255,255,0.6)">${esc(data.trainerId)}</span></div>
  </div>
  <div class="stat-grid">
    <div class="stat-cell">
      <div class="stat-lbl">Trainee Rank</div>
      <div class="stat-val">${esc(data.rank)}</div>
    </div>
    <div class="stat-cell">
      <div class="stat-lbl">Affinity</div>
      <div class="stat-val" style="color:#4fc3f7">${esc(data.affinity)}</div>
    </div>
    <div class="stat-cell" style="grid-column:1/-1">
      <div class="stat-lbl">White Skills</div>
      <div class="stat-val" style="color:#ce93d8">${esc(data.whiteSkills)}</div>
      <div class="stat-sub">Rebuilding #uma-results leaderboard…</div>
    </div>
  </div>
  <div class="footer">
    <span>Submitted by ${esc(data.submittedBy)}</span>
    <span>uma.moe/profile/${esc(data.trainerId)}</span>
  </div>
</div></body></html>`;
  return renderHtml(html, 500);
}

// ── Individual player daily warning ──────────────────────────────────────────
/**
 * data: { trainerName, yesterday, yesterdayRaw, monthly, monthlyRaw,
 *         dailyReq, dailyReqRaw, daysLeft, date, circleName }
 */
export async function renderPlayerWarning(data) {
  const accent = '#ef5350';
  const pct = Math.min(100, Math.round((data.yesterdayRaw / data.dailyReqRaw) * 100)) || 0;
  const shortfall = data.dailyReqRaw - data.yesterdayRaw;
  const shortStr =
    shortfall > 0
      ? (shortfall >= 1_000_000
          ? (shortfall / 1_000_000).toFixed(1) + 'M'
          : Math.round(shortfall / 1_000) + 'K') + ' short'
      : 'Met!';

  const html = `<!DOCTYPE html><html><head><meta charset="utf-8">${css(accent)}</head>
<body><div class="card">
  <div class="accent-bar"></div>
  <div class="header">
    <div class="hrow">
      <div class="htitle">⚠️ ${esc(data.trainerName)}</div>
      <div class="hdate">${esc(data.date)}</div>
    </div>
    <div class="hsub">${esc(data.circleName)} · Daily Fan Gain Warning</div>
  </div>
  <div style="padding:16px 22px 8px">
    <div style="font-size:10px;text-transform:uppercase;letter-spacing:0.7px;color:rgba(255,255,255,0.35);margin-bottom:6px">Yesterday's Gain</div>
    <div style="font-size:32px;font-weight:700;color:#ef9a9a;letter-spacing:-1px">${esc(data.yesterday)}</div>
    <div style="font-size:11px;color:rgba(255,255,255,0.35);margin-top:3px">Daily requirement: ${esc(data.dailyReq)} · <span style="color:#ef9a9a">${shortStr}</span></div>
    <div style="margin-top:12px">
      <div class="bar-track" style="height:8px">
        <div class="bar-fill" style="width:${pct}%;background:linear-gradient(90deg,#ef5350,#ff8a65)"></div>
      </div>
      <div style="display:flex;justify-content:space-between;font-size:10px;color:rgba(255,255,255,0.28);margin-top:4px">
        <span>0</span><span>${pct}% of daily target</span><span>${esc(data.dailyReq)}</span>
      </div>
    </div>
  </div>
  <div class="divider" style="height:1px;background:rgba(255,255,255,0.07);margin:0 22px"></div>
  <div style="padding:10px 22px 14px;display:flex;gap:20px">
    <div>
      <div style="font-size:10px;text-transform:uppercase;letter-spacing:0.5px;color:rgba(255,255,255,0.35);margin-bottom:4px">Monthly Total</div>
      <div style="font-size:15px;font-weight:700;color:#ce93d8">${esc(data.monthly)}</div>
    </div>
    <div>
      <div style="font-size:10px;text-transform:uppercase;letter-spacing:0.5px;color:rgba(255,255,255,0.35);margin-bottom:4px">Days Left</div>
      <div style="font-size:15px;font-weight:700;color:rgba(255,255,255,0.6)">${esc(String(data.daysLeft))} day${data.daysLeft !== 1 ? 's' : ''}</div>
    </div>
  </div>
  <div class="footer">
    <span>Below ${esc(data.dailyReq)} daily target</span>
    <span>${esc(data.circleName)}</span>
  </div>
</div></body></html>`;
  return renderHtml(html, 520);
}

// ── Help Card ─────────────────────────────────────────────────────────────────
/**
 * Renders a command-reference card from live COMMAND_MODULES.
 *
 * modules: array of command module objects (each has a `data` SlashCommandBuilder)
 *
 * Commands are automatically grouped by the CATEGORIES table below.
 * Any command not matched by a category falls into "📦 Other" at the bottom.
 */
const HELP_CATEGORIES = [
  {
    label: 'Fan Tracking',
    icon: '📊',
    accent: '#ffd700',
    test: n =>
      [
        'fan_gain',
        'leaderboard',
        'total_fan',
        'total_circlefan_gain',
        'circle_master',
        'joindate',
      ].includes(n),
  },
  {
    label: 'Trainer',
    icon: '🔗',
    accent: '#4fc3f7',
    test: n => ['link', 'unlink', 'search_trainer', 'store', 'keep'].includes(n),
  },
  {
    label: 'Music',
    icon: '🎵',
    accent: '#ce93d8',
    test: n => ['storesong', 'godplay'].includes(n),
  },
  {
    label: 'Tools',
    icon: '🛠️',
    accent: '#66bb6a',
    test: n => ['set_timezone', 'set_quota', 'timeline_setup', 'timeline_post'].includes(n),
  },
  {
    label: 'General',
    icon: 'ℹ️',
    accent: '#9fa8da',
    test: n => n === 'help',
  },
  {
    label: 'Admin',
    icon: '🔧',
    accent: '#ef6c00',
    test: n => n.startsWith('admin') || n.startsWith('test'),
  },
];

function groupCommands(modules) {
  const cats = HELP_CATEGORIES.map(c => ({ ...c, cmds: [] }));
  const other = { label: 'Other', icon: '📦', accent: '#90a4ae', cmds: [] };

  for (const mod of modules) {
    const name = mod.data.name;
    const desc = mod.data.description;
    const matched = cats.find(c => c.test(name));
    if (matched) matched.cmds.push({ name, desc });
    else other.cmds.push({ name, desc });
  }

  const result = cats.filter(c => c.cmds.length > 0);
  if (other.cmds.length > 0) result.push(other);
  return result;
}

export async function renderHelpCard(modules) {
  const date = new Date().toISOString().slice(0, 10);
  const total = modules.length;
  const cats = groupCommands(modules);

  const categorySections = cats
    .map(cat => {
      const rows = cat.cmds
        .sort((a, b) => a.name.localeCompare(b.name))
        .map((c, i) => {
          const bg = i % 2 === 0 ? 'rgba(255,255,255,0.018)' : 'transparent';
          return `<div style="padding:5px 20px 5px 32px;display:flex;gap:10px;align-items:baseline;background:${bg}">
          <span style="font-size:12px;font-weight:700;font-family:'Courier New',monospace;color:${esc(cat.accent)};white-space:nowrap;flex-shrink:0;min-width:190px">/${esc(c.name)}</span>
          <span style="font-size:11px;color:rgba(255,255,255,0.5);line-height:1.4">${esc(c.desc)}</span>
        </div>`;
        })
        .join('');

      return `
      <div style="padding:9px 20px 5px;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.9px;display:flex;align-items:center;gap:7px;border-top:1px solid rgba(255,255,255,0.05);margin-top:2px">
        <div style="width:7px;height:7px;border-radius:50%;background:${esc(cat.accent)};flex-shrink:0"></div>
        <span style="color:${esc(cat.accent)}">${cat.icon} ${esc(cat.label)}</span>
        <span style="color:rgba(255,255,255,0.2);font-weight:400;text-transform:none;letter-spacing:0">${cat.cmds.length} command${cat.cmds.length !== 1 ? 's' : ''}</span>
      </div>
      ${rows}`;
    })
    .join('');

  const html = `<!DOCTYPE html><html><head><meta charset="utf-8">
<style>
* { margin:0;padding:0;box-sizing:border-box; }
body { background:#0d0d1f;font-family:system-ui,-apple-system,Arial,sans-serif;color:#fff;display:inline-block;width:680px; }
.card { background:linear-gradient(170deg,#161628 0%,#0d0d1f 100%);position:relative;overflow:hidden; }
.card::after { content:'UmaKraft';position:absolute;top:50%;left:50%;transform:translate(-50%,-50%) rotate(-20deg);font-size:220px;font-weight:900;color:rgba(255,255,255,0.06);white-space:nowrap;pointer-events:none;z-index:50;letter-spacing:-4px;user-select:none; }
</style></head>
<body><div class="card">
  <div style="height:3px;background:linear-gradient(90deg,#9fa8da,#ce93d8)"></div>
  <div style="padding:14px 20px 10px;border-bottom:1px solid rgba(255,255,255,0.07)">
    <div style="display:flex;justify-content:space-between;align-items:flex-start">
      <div style="font-size:17px;font-weight:700">📋 Bot Commands</div>
      <div style="font-size:11px;color:rgba(255,255,255,0.35);white-space:nowrap;margin-top:2px">${esc(date)}</div>
    </div>
    <div style="font-size:11px;color:rgba(255,255,255,0.4);margin-top:3px">${esc(String(total))} commands registered · Uma Circle Bot</div>
  </div>
  ${categorySections}
  <div style="padding:9px 20px;border-top:1px solid rgba(255,255,255,0.06);font-size:10px;color:rgba(255,255,255,0.28);display:flex;justify-content:space-between;margin-top:4px">
    <span>Auto-generated from registered commands</span>
    <span>UmaKraft</span>
  </div>
</div></body></html>`;

  return renderHtml(html, 680);
}

// ── Convenience ───────────────────────────────────────────────────────────────

export function bufferToAttachment(buffer, filename = 'report.png') {
  return new AttachmentBuilder(buffer, { name: filename });
}
