/**
 * Playwright-based screenshot utility for uma.moe trainer profiles.
 *
 * Captures the full trainer result card including the inheritance tree and
 * complete skills list — not just a fixed-height viewport crop.
 *
 * Screenshots are cached to data/screenshots/{trainerId}.png so leaderboard
 * rebuilds don't re-scrape every trainer. Cache lifetime: 6 hours.
 *
 * Overlay strategy: after page load, ALL known overlay/dialog elements are
 * force-removed from the DOM via JS before the screenshot is taken. Up to
 * MAX_RETRIES attempts are made if the result is too small.
 */

import { chromium } from 'playwright-core';
import { execSync } from 'node:child_process';
import fs from 'node:fs/promises';
import path from 'node:path';
import { config } from '../core/config.js';
import { log } from '../core/log.js';

const CACHE_DIR = path.join(config.dataDir, 'screenshots');
const CACHE_MAX_MS = 6 * 60 * 60 * 1000; // 6 hours
const MAX_RETRIES = 3;

// ── Concurrency limiter (max 3 Playwright pages at once) ──────────────────────
let _activeConcurrent = 0;
const MAX_CONCURRENT = 3;
const _concurrentQueue = [];

function acquireConcurrentSlot() {
  return new Promise(resolve => {
    if (_activeConcurrent < MAX_CONCURRENT) {
      _activeConcurrent++;
      resolve();
    } else {
      _concurrentQueue.push(resolve);
    }
  });
}

function releaseConcurrentSlot() {
  if (_concurrentQueue.length > 0) {
    _concurrentQueue.shift()();
  } else {
    _activeConcurrent--;
  }
}

const BROWSER_ARGS = [
  '--no-sandbox',
  '--disable-setuid-sandbox',
  '--disable-dev-shm-usage',
  '--disable-gpu',
];

function resolveChromiumPath() {
  try {
    return execSync('which chromium', { stdio: ['ignore', 'pipe', 'ignore'] })
      .toString()
      .trim();
  } catch {
    return undefined;
  }
}

const SYSTEM_CHROMIUM = resolveChromiumPath();

let _browser = null;

async function getBrowser() {
  if (_browser) {
    try {
      // Actually open a context to verify the browser process is still alive
      const ctx = await _browser.newContext();
      await ctx.close();
      return _browser;
    } catch {
      _browser = null;
    }
  }
  _browser = await chromium.launch({
    headless: true,
    args: BROWSER_ARGS,
    ...(SYSTEM_CHROMIUM ? { executablePath: SYSTEM_CHROMIUM } : {}),
  });
  return _browser;
}

async function ensureCacheDir() {
  await fs.mkdir(CACHE_DIR, { recursive: true });
}

function cachePath(trainerId) {
  return path.join(CACHE_DIR, `${trainerId}.png`);
}

async function readCached(trainerId) {
  const p = cachePath(trainerId);
  try {
    const stat = await fs.stat(p);
    if (Date.now() - stat.mtimeMs < CACHE_MAX_MS) {
      return await fs.readFile(p);
    }
  } catch {
    /* not cached */
  }
  return null;
}

async function writeCache(trainerId, buffer) {
  await ensureCacheDir();
  await fs.writeFile(cachePath(trainerId), buffer);
}

/**
 * Pre-accept cookies via localStorage injection so the consent banner
 * hopefully never mounts. Called via addInitScript so it runs before any
 * page JS executes.
 */
async function preAcceptCookies(page) {
  await page.addInitScript(() => {
    try {
      localStorage.setItem('cookie_consent', 'true');
      localStorage.setItem('cookieConsent', 'true');
      localStorage.setItem('cookies_accepted', 'true');
      localStorage.setItem('uma-cookie-consent', 'true');
      localStorage.setItem('consent', 'true');
      localStorage.setItem(
        'CookieConsent',
        JSON.stringify({
          stamp: '',
          necessary: true,
          preferences: true,
          statistics: true,
          marketing: true,
          ver: 1,
        })
      );
    } catch {}
  });
}

/**
 * Aggressively remove every overlay, dialog, and cookie banner from the DOM.
 *
 * Strategy (in order):
 *  1. Click "Accept"/"Reject" buttons by visible text
 *  2. Press Escape
 *  3. Click any matching CSS selector buttons
 *  4. Force-remove the entire element from the DOM (not just hide) so it
 *     cannot possibly cover the card in the screenshot
 */
async function nukeOverlays(page) {
  // 1. Try clicking consent buttons by label
  const labels = [
    'Accept All',
    'Accept all',
    'Accept',
    'Reject All',
    'Reject all',
    'OK',
    'Agree',
    'Close',
    'Got it',
    'Customize',
  ];
  for (const label of labels) {
    try {
      const btn = page.getByRole('button', { name: label, exact: true });
      if (await btn.isVisible({ timeout: 300 })) {
        await btn.click();
        await page.waitForTimeout(400);
        break;
      }
    } catch {}
  }

  // 2. Escape key
  try {
    await page.keyboard.press('Escape');
    await page.waitForTimeout(200);
  } catch {}

  // 3. CSS selector button clicks
  const selectorBtns = [
    'button[aria-label="Close"]',
    'button[aria-label="close"]',
    'mat-dialog-actions button',
    '[class*="cookie"] button',
    '[class*="consent"] button',
    '[class*="banner"] button',
    'mat-dialog-container button',
    '.cdk-overlay-container button',
  ];
  for (const sel of selectorBtns) {
    try {
      const el = page.locator(sel).first();
      if (await el.isVisible({ timeout: 200 })) {
        await el.click();
        await page.waitForTimeout(250);
      }
    } catch {}
  }

  // 4. Force-remove all overlay/dialog elements from the DOM entirely.
  //    We remove rather than hide so they cannot intercept pointer events
  //    or appear in the screenshot.
  await page
    .evaluate(() => {
      const targets = [
        // Angular CDK overlay & dialogs
        'mat-dialog-container',
        '.cdk-overlay-pane',
        '.cdk-overlay-backdrop',
        '.cdk-overlay-container',
        // Cookie / consent banners
        '[class*="cookie"]',
        '[class*="consent"]',
        '[class*="CookieConsent"]',
        '[class*="cookie-banner"]',
        '[class*="cookie-law"]',
        // Generic overlays / modals / popups
        '[class*="modal"]',
        '[class*="dialog"]',
        '[class*="overlay"]',
        '[class*="popup"]',
        '[class*="banner"]',
        // IDs
        '[id*="cookie"]',
        '[id*="consent"]',
        '[id*="modal"]',
      ];
      for (const sel of targets) {
        document.querySelectorAll(sel).forEach(el => {
          try {
            el.remove();
          } catch {}
        });
      }
      // Also ensure the body/html can scroll normally and has no fixed overlays
      try {
        document.body.style.overflow = 'auto';
        document.documentElement.style.overflow = 'auto';
      } catch {}
    })
    .catch(() => {});
}

/**
 * Find the first result card element on the page using multiple strategies.
 * Returns a Playwright ElementHandle or null.
 */
async function findCardElement(page) {
  // Strategy 1: mat-card (Angular Material) with real content height
  try {
    const handle = await page.evaluateHandle(() => {
      const cards = Array.from(document.querySelectorAll('mat-card'));
      const sorted = cards
        .map(c => ({ c, r: c.getBoundingClientRect() }))
        .filter(({ r }) => r.height > 150 && r.top > 50 && r.width > 300)
        .sort((a, b) => a.r.top - b.r.top);
      return sorted.length ? sorted[0].c : null;
    });
    if (handle && (await handle.jsonValue()) !== null) return handle;
  } catch {}

  // Strategy 2: first wide, tall, visible element below the header
  try {
    const handle = await page.evaluateHandle(() => {
      for (const el of document.querySelectorAll('*')) {
        const r = el.getBoundingClientRect();
        const cs = window.getComputedStyle(el);
        const bg = cs.backgroundColor;
        if (
          r.width > 500 &&
          r.height > 150 &&
          r.top > 50 &&
          bg !== 'rgba(0, 0, 0, 0)' &&
          bg !== 'transparent'
        ) {
          return el;
        }
      }
      return null;
    });
    if (handle && (await handle.jsonValue()) !== null) return handle;
  } catch {}

  return null;
}

/**
 * Take a screenshot of the uma.moe database card for the given trainer.
 *
 * Flow per attempt:
 *  1. Nuke all overlays from the DOM
 *  2. Try element screenshot of the result card (full height, any card size)
 *  3. Fall back to a clipped full-page screenshot if no card element found
 *
 * Retries up to MAX_RETRIES times if the buffer is too small.
 * Returns a PNG Buffer or null.
 */
export async function screenshotTrainer(
  trainerId,
  { forceRefresh = false, timeout = 35_000 } = {}
) {
  const id = String(trainerId);

  if (!forceRefresh) {
    const cached = await readCached(id);
    if (cached) return cached;
  }

  await acquireConcurrentSlot();
  let page;
  try {
    const browser = await getBrowser();
    page = await browser.newPage();

    // Wide desktop viewport — forces the full card to render in one column
    await page.setViewportSize({ width: 1280, height: 960 });

    // Pre-accept cookies via localStorage before any page JS runs
    await preAcceptCookies(page);

    // Skip heavy media assets
    await page.route('**/*.{mp4,webm,ogg,mp3,wav,woff,woff2,ttf,otf}', r => r.abort());

    const url =
      `https://uma.moe/database?trainer_id=${id}` +
      `&page=0&limit=1&search_type=inheritance&sort_by=affinity_score&sort_order=desc`;

    await page.goto(url, { waitUntil: 'networkidle', timeout });

    // Wait for result data to appear
    await page
      .waitForFunction(() => /\d+\s+records?\s+found/i.test(document.body.innerText), {
        timeout: 15_000,
      })
      .catch(() => {});

    // Give Angular time to finish rendering
    await page.waitForTimeout(800);

    // ── Retry loop ────────────────────────────────────────────────────────────
    let buffer = null;

    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
      // Nuke every overlay/dialog from the DOM before each attempt
      await nukeOverlays(page);
      await page.waitForTimeout(300);

      // ── Primary: element screenshot ──────────────────────────────────────
      const cardEl = await findCardElement(page);
      if (cardEl) {
        try {
          await cardEl.scrollIntoViewIfNeeded();
          await page.waitForTimeout(300);
          const elBuf = await cardEl.screenshot({ type: 'png' });
          if (elBuf && elBuf.length > 10_000) {
            buffer = elBuf;
            log.info(
              `screenshotter: element capture ${id} attempt ${attempt} (${Math.round(elBuf.length / 1024)} KB)`
            );
            break;
          }
        } catch (err) {
          log.warn(
            `screenshotter: element screenshot failed attempt ${attempt} for ${id}: ${err.message}`
          );
        }
      }

      // ── Fallback: clipped full-page screenshot ───────────────────────────
      log.info(`screenshotter: full-page fallback for ${id} attempt ${attempt}`);
      const totalHeight = await page.evaluate(() => document.body.scrollHeight);
      const clipHeight = Math.max(600, Math.min(totalHeight, 2400) - 290);
      const fallbackBuf = await page.screenshot({
        type: 'png',
        clip: { x: 0, y: 290, width: 1280, height: clipHeight },
      });

      if (fallbackBuf && fallbackBuf.length > 5_000) {
        buffer = fallbackBuf;
        log.info(
          `screenshotter: fallback capture ${id} attempt ${attempt} (${Math.round(fallbackBuf.length / 1024)} KB)`
        );
        break;
      }

      log.warn(`screenshotter: attempt ${attempt} produced empty buffer for ${id}, retrying`);
      await page.waitForTimeout(500);
    }

    if (buffer && buffer.length > 5_000) {
      await writeCache(id, buffer);
      log.info(`screenshotter: saved ${id} (${Math.round(buffer.length / 1024)} KB)`);
    }

    return buffer?.length > 5_000 ? buffer : null;
  } catch (err) {
    log.warn(`screenshotter(${id}): ${err.message}`);
    return null;
  } finally {
    await page?.close().catch(() => {});
    releaseConcurrentSlot();
  }
}

/** Delete a cached screenshot so the next call re-scrapes. */
export async function invalidateCache(trainerId) {
  try {
    await fs.unlink(cachePath(String(trainerId)));
  } catch {
    /* not cached */
  }
}
